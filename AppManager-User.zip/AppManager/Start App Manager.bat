@echo off
rem Starts App Manager without a console window. Double-click this file.
cd /d "%~dp0"

rem 1) Python from the new Python install manager
if exist "%LOCALAPPDATA%\Python\pythoncore-3.14-64\pythonw.exe" (
  start "" "%LOCALAPPDATA%\Python\pythoncore-3.14-64\pythonw.exe" app_manager.py
  exit /b
)
rem 2) The "py" launcher (windowless variant first)
where pyw >nul 2>nul && (
  start "" pyw -3 app_manager.py
  exit /b
)
rem 3) Any pythonw on the PATH
where pythonw >nul 2>nul && (
  start "" pythonw app_manager.py
  exit /b
)

echo Python was not found on this PC.
echo Install it from https://www.python.org/downloads/ (tick "Add python.exe to PATH"),
echo then double-click this file again.
pause
