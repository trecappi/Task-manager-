'use strict';
/* App Manager front end. Plain JavaScript, no libraries. */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const fmtBytes = b => {
  if (b == null) return '—';
  const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return (i < 2 ? Math.round(b) : b.toFixed(1)) + ' ' + u[i];
};
const fmtKB = kb => kb == null ? '—' : fmtBytes(kb * 1024);
const fmtUptime = s => {
  if (s == null) return '—';
  const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
  return (d ? d + ' d ' : '') + (h || d ? h + ' h ' : '') + m + ' min';
};
const yearsOld = d => d ? (Date.now() - new Date(d)) / 31557600000 : 0;

/* ---------- state ---------- */
const TABS = [['overview', 'Overview'], ['programs', 'Programs'], ['myapps', 'My apps'],
  ['startup', 'Startup'], ['updates', 'Updates'], ['install', 'Install'], ['tweaks', 'Tweaks'], ['security', 'Security'],
  ['monitor', 'Monitor'], ['tools', 'Tools'], ['profiles', 'Profiles'], ['hub', 'Hub'], ['backup', 'Backup'], ['devices', 'Devices'], ['activity', 'Activity'], ['settings', 'Settings']];
let META = {}, tab = 'overview';
let ME = {username: null, admin: true, open: true, access: {}};
const canSee = k => k === 'settings' || ME.admin || !!ME.access?.[k];
const seg = {myapps: 'managed', devices: 'hardware', updates: 'programs', tools: 'cleanup'};
const D = {};                      // data from the server, by name
const F = {                        // filters and sorting
  programs: {q: '', source: 'all', fav: false, sort: 'name', dir: 1},
  apps: {q: ''}, running: {q: '', sys: false},
  startup: {q: ''}, tree: {q: '', problems: false, absent: false},
  drivers: {q: '', sort: 'device', dir: 1}
};
const SEL = new Set();             // selected program ids

/* ---------- sign-in ---------- */
function showLogin(msg) {
  document.body.classList.add('locked');
  const L = $('#login'); L.hidden = false;
  L.innerHTML = `<form class="logincard"><h2>App Manager</h2><div class="path">Sign in with your technician account.</div>
   <input type="text" id="lgU" placeholder="Username" autocomplete="username"><input type="password" id="lgP" placeholder="Password" autocomplete="current-password">
   <div class="lgerr" id="lgE">${esc(msg || '')}</div><button class="btn primary" type="submit">Sign in</button></form>`;
  $('#lgU').focus();
  L.querySelector('form').onsubmit = async e => {
    e.preventDefault();
    try { await api('/api/login', {username: $('#lgU').value, password: $('#lgP').value}); location.reload(); }
    catch (er) { $('#lgE').textContent = er.message; $('#lgP').value = ''; $('#lgP').focus(); }
  };
}

/* ---------- plumbing ---------- */
function toast(m) {
  const t = $('#toast'); t.textContent = m; t.classList.add('show');
  clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove('show'), 3800);
}
async function api(path, body) {
  const o = body === undefined ? {} : {method: 'POST', headers: {'X-AppMgr': '1', 'Content-Type': 'application/json'}, body: JSON.stringify(body)};
  const r = await fetch(path, o);
  let j = {}; try { j = await r.json(); } catch (e) {}
  if (r.status === 401 && path !== '/api/login') { if ($('#login').hidden) showLogin('Your session ended. Please sign in again.'); throw new Error('Please sign in.'); }
  if (!r.ok) { const e = new Error(j.error || (r.status === 404 ? 'This part is missing because an older App Manager is still running. Press Quit, then start App Manager again.' : 'Request failed')); e.confirm = j.confirm; throw e; }
  return j;
}
/* Load a list that the server may still be reading; poll until it is ready. */
async function load(key, path, refresh = false) {
  try {
    const r = await api(path + (refresh ? (path.includes('?') ? '&' : '?') + 'refresh=1' : ''));
    D[key] = r;
    if (r.loading) setTimeout(() => load(key, path), 1500);
  } catch (e) { D[key] = {error: e.message, items: [], loading: false}; }
  dataChanged(key);
  return D[key];
}
function askText(title, label, value = '', type = 'text') {
  return new Promise(res => {
    const m = $('#modal'); m.hidden = false;
    m.innerHTML = `<div class="dialog" role="dialog"><h2>${esc(title)}</h2><div class="body"><input id="askT" type="${type}" style="width:100%" placeholder="${esc(label)}" value="${esc(value)}" autocomplete="off"></div>
      <div class="btns"><button class="btn" data-d="cancel">Cancel</button><button class="btn primary" data-d="ok">OK</button></div></div>`;
    const done = v => { m.hidden = true; m.innerHTML = ''; m.onclick = null; m.onkeydown = null; res(v); };
    m.onclick = e => { const b = e.target.closest('[data-d]'); if (b) done(b.dataset.d === 'ok' ? $('#askT').value : null); else if (e.target === m) done(null); };
    m.onkeydown = e => { if (e.key === 'Enter') done($('#askT').value); if (e.key === 'Escape') done(null); };
    setTimeout(() => $('#askT')?.focus(), 30);
  });
}
function dialog({title, body = '', checks = [], ok = 'OK', cancel = 'Cancel', danger = false, hideCancel = false}) {
  return new Promise(res => {
    const m = $('#modal'); m.hidden = false;
    m.innerHTML = `<div class="dialog" role="dialog"><h2>${esc(title)}</h2><div class="body">${body}</div>
      <div class="checks">${checks.map(c => `<label><input type="checkbox" data-ck="${c.id}" ${c.checked ? 'checked' : ''}><span>${c.label}</span></label>`).join('')}</div>
      <div class="btns">${hideCancel ? '' : `<button class="btn" data-d="cancel">${esc(cancel)}</button>`}
      <button class="btn ${danger ? 'dangerfill' : 'primary'}" data-d="ok">${esc(ok)}</button></div></div>`;
    const done = v => { m.hidden = true; m.innerHTML = ''; m.onclick = null; res(v); };
    m.onclick = e => {
      const b = e.target.closest('[data-d]');
      if (b) { if (b.dataset.d === 'ok') { const out = {}; $$('[data-ck]', m).forEach(c => out[c.dataset.ck] = c.checked); done(out); } else done(null); }
      else if (e.target === m) done(null);
    };
  });
}
async function post(path, body, okMsg) {
  try { const j = await api(path, body); if (okMsg) toast(okMsg); if (j.warning) toast(j.warning); return j; }
  catch (e) { toast(e.message); return null; }
}
const setPath = (path, val) => { const p = path.split('.'); let o = F; while (p.length > 1) o = o[p.shift()]; o[p[0]] = val; };

/* ---------- small pieces ---------- */
const avatar = n => `<div class="av">${esc((n || '?').trim()[0]?.toUpperCase() || '?')}</div>`;
const netBtn = o => `<button class="net ${o.blocked ? 'blocked' : ''}" data-a="net" data-exe="${esc(o.exe)}" data-name="${esc(o.name)}" data-blocked="${o.blocked ? 1 : 0}" title="Click to ${o.blocked ? 'allow' : 'block'} internet access">${o.blocked ? 'Internet: Blocked' : 'Internet: Allowed'}</button>`;
const loadingBox = what => `<div class="empty"><span class="spin"></span><br><br>${esc(what)}</div>`;
const errBox = e => e ? `<div class="banner err">Could not read this: ${esc(e)}</div>` : '';
const search = (path, val, ph = 'Search…') => `<input type="search" data-f="${path}" placeholder="${esc(ph)}" value="${esc(val)}">`;
const segCtl = (name, opts) => `<div class="seg">${opts.map(([k, l]) => `<button data-seg="${name}:${k}" class="${seg[name] === k ? 'on' : ''}">${esc(l)}</button>`).join('')}</div>`;
const match = (o, q) => !q || Object.values(o).join(' ').toLowerCase().includes(q);

/* ---------- OVERVIEW ---------- */
function vOverview() {
  const h = D.hardware?.data;
  if (!h) return D.hardware?.error ? errBox(D.hardware.error) : loadingBox('Reading your hardware…');
  const s = h.system || {}, cpu = (h.cpu || [])[0] || {};
  const probs = (D.devices?.items || []).filter(d => d.problem);
  const attn = [];
  (h.volumes || []).forEach(v => { if (v.size && v.free / v.size < 0.15) attn.push([`Drive ${v.drive} ${v.label ? '(' + v.label + ') ' : ''}is almost full: only ${fmtBytes(v.free)} free.`, 'Storage', 'devices:hardware']); });
  (h.disks || []).forEach(d => { if (d.health && !/^healthy$/i.test(d.health) && d.health !== 'Unknown') attn.push([`${d.name} reports its health as "${d.health}". Back up important files.`, 'Details', 'devices:hardware']); });
  if (probs.length) attn.push([`${probs.length} device${probs.length > 1 ? 's' : ''} reported a problem.`, 'Show', 'devices:tree']);
  if (D.updates?.items?.length) attn.push([`${D.updates.items.length} program update${D.updates.items.length > 1 ? 's are' : ' is'} available.`, 'Update', 'updates']);
  if (META.windows && !META.admin) attn.push(['App Manager does not have administrator permission, so some actions will fail.', '', '']);
  const mine = D.apps?.apps || [];
  return `<div class="attn">${attn.length ? attn.map(([t, l, go]) => `<div class="item">${esc(t)}${l ? `<a data-go="${go}">${esc(l)}</a>` : ''}</div>`).join('') : '<div class="item good">Nothing needs your attention right now.</div>'}</div>
  <div class="grid">
   <div class="card"><h3>This PC</h3><div class="big">${esc([s.manufacturer, s.model].filter(Boolean).join(' ') || s.name || 'Unknown')}</div>
     <dl class="kv"><dt>System</dt><dd>${esc(s.os || '—')}</dd><dt>Version</dt><dd>${esc([s.version, s.build && 'build ' + s.build, s.arch].filter(Boolean).join(' · ') || '—')}</dd>
     <dt>Running for</dt><dd>${fmtUptime(s.uptime)}</dd>${h.secureboot == null ? '' : `<dt>Secure Boot</dt><dd>${h.secureboot ? 'On' : 'Off'}</dd>`}</dl></div>
   <div class="card"><h3>Processor</h3><div class="big">${esc(cpu.name || '—')}</div>
     <dl class="kv"><dt>Cores</dt><dd>${cpu.cores || '—'} cores, ${cpu.threads || '—'} threads</dd>${cpu.mhz ? `<dt>Speed</dt><dd>${(cpu.mhz / 1000).toFixed(2)} GHz</dd>` : ''}</dl></div>
   <div class="card"><h3>Memory</h3><div class="big">${fmtBytes(h.ram?.total)}</div>
     <dl class="kv"><dt>Modules</dt><dd>${(h.ram?.modules || []).length ? (h.ram.modules.length + ' × ' + h.ram.modules.map(m => fmtBytes(m.size)).join(' + ') + (h.ram.modules[0].speed ? ' @ ' + h.ram.modules[0].speed + ' MHz' : '')) : '—'}</dd></dl></div>
   <div class="card"><h3>Graphics</h3>${(h.gpu || []).map(g => `<div class="name">${esc(g.name)}</div><div class="path">${g.vram ? fmtBytes(g.vram) + ' · ' : ''}driver ${esc(g.driver || '—')}${g.date ? ' (' + esc(g.date) + ')' : ''}</div>`).join('') || '—'}</div>
   <div class="card"><h3>Storage</h3>${(h.volumes || []).map(v => { const used = v.size ? 100 - v.free / v.size * 100 : 0; return `<div class="name">${esc(v.drive)} ${esc(v.label || '')}</div><div class="bar"><i class="${used > 85 ? 'low' : ''}" style="width:${used.toFixed(0)}%"></i></div><div class="path">${fmtBytes(v.free)} free of ${fmtBytes(v.size)}</div>`; }).join('') || '—'}</div>
   <div class="card"><h3>Software</h3><dl class="kv"><dt>Programs</dt><dd>${D.programs?.items ? D.programs.items.length : '…'} installed</dd>
     <dt>Startup items</dt><dd>${D.startup?.items ? D.startup.items.filter(i => i.enabled).length + ' on, ' + D.startup.items.filter(i => !i.enabled).length + ' off' : '…'}</dd>
     <dt>My apps</dt><dd>${mine.length} (${mine.filter(a => a.running).length} running)</dd></dl></div>
  </div>`;
}

/* ---------- PROGRAMS ---------- */
function progList() {
  const f = F.programs;
  const a = (D.programs?.items || []).filter(p => (f.source === 'all' || p.kind === f.source) && (!f.fav || p.favorite) &&
    match({n: p.name, p: p.publisher, v: p.version, l: p.location}, f.q.toLowerCase()));
  a.sort((x, y) => {
    const r = f.sort === 'size' ? (x.size_kb || 0) - (y.size_kb || 0)
      : String(x[f.sort] || '').localeCompare(String(y[f.sort] || ''), undefined, {sensitivity: 'base', numeric: true});
    return (r * f.dir) || x.name.localeCompare(y.name);
  });
  return a;
}
const th = (key, label, cls = '', ns = 'programs', st = F.programs) =>
  `<th class="${cls}" data-sort="${ns}:${key}">${label}${st.sort === key ? (st.dir > 0 ? ' ▲' : ' ▼') : ''}</th>`;
function vPrograms() {
  const P = D.programs;
  if (!P || (!P.ready && P.loading)) return loadingBox('Reading your installed programs…');
  const a = progList();
  const all = a.length && a.every(p => SEL.has(p.id));
  return `${errBox(P.error)}<div class="count">${a.length} of ${P.items.length} programs${P.loading ? ' · refreshing…' : ''}</div>
  <div class="tablewrap"><table><thead><tr><th class="nosort"><input type="checkbox" data-a="selall" ${all ? 'checked' : ''} title="Select all shown"></th><th class="nosort"></th>
   ${th('name', 'Name')}${th('version', 'Version')}${th('publisher', 'Publisher')}${th('installed', 'Installed')}${th('size', 'Size', 'num')}</tr></thead><tbody>
   ${a.map(p => `<tr class="click" data-pid="${p.id}"><td><input type="checkbox" data-a="sel" data-id="${p.id}" ${SEL.has(p.id) ? 'checked' : ''}></td>
    <td><button class="star ${p.favorite ? 'on' : ''}" data-a="fav" data-id="${p.id}" title="Favorite">${p.favorite ? '★' : '☆'}</button></td>
    <td><b>${esc(p.name)}</b> ${p.kind === 'store' ? '<span class="tag">Store</span>' : ''}</td><td class="mute">${esc(p.version)}</td>
    <td class="mute">${esc(p.publisher)}</td><td class="mute">${esc(p.installed)}</td><td class="num mute">${fmtKB(p.size_kb)}</td></tr>`).join('') ||
    '<tr><td colspan="7" class="empty">Nothing matches.</td></tr>'}</tbody></table></div>`;
}
function toolsPrograms() {
  const f = F.programs;
  return `${search('programs.q', f.q, 'Search name, publisher, version…')}
  <select data-f="programs.source"><option value="all">All sources</option><option value="desktop" ${f.source === 'desktop' ? 'selected' : ''}>Desktop programs</option><option value="store" ${f.source === 'store' ? 'selected' : ''}>Microsoft Store apps</option></select>
  <label class="check"><input type="checkbox" data-f="programs.fav" ${f.fav ? 'checked' : ''}> Favorites</label>
  <button class="btn" data-a="reload-programs">Refresh</button>
  <a class="btn" href="/api/programs/export?format=csv" download>Export CSV</a><a class="btn" href="/api/programs/export?format=html" download>Export HTML</a>
  <button class="btn dangerfill" id="unBtn" data-a="uninstall-sel" ${SEL.size ? '' : 'disabled'}>Uninstall selected (${SEL.size})</button>`;
}
function updateSelBtn() { const b = $('#unBtn'); if (b) { b.disabled = !SEL.size; b.textContent = `Uninstall selected (${SEL.size})`; } }

async function openProgram(id) {
  const dr = $('#drawer'); dr.hidden = false; dr.innerHTML = loadingBox('Loading…');
  try { drawer(await api('/api/programs/' + id)); } catch (e) { dr.hidden = true; toast(e.message); }
}
function drawer(d) {
  D.drawer = d;
  const kv = (k, v) => `<dt>${k}</dt><dd>${v}</dd>`;
  $('#drawer').innerHTML = `<button class="btn small close" data-a="close-drawer">Close</button>
   <h2>${esc(d.name)}</h2><div class="path">${esc(d.publisher || 'Unknown publisher')}</div>
   <dl class="kv">${kv('Version', esc(d.version || '—'))}${kv('Installed', esc(d.installed || '—'))}
   ${kv('Size', `<span id="psize">${fmtKB(d.size_kb)}</span> ${d.location_exists ? `<button class="btn small" data-a="p-size" data-id="${d.id}">Measure folder</button>` : ''}`)}
   ${kv('Source', d.kind === 'store' ? 'Microsoft Store' : 'Desktop program' + (d.arch ? ' (' + esc(d.arch) + ')' : ''))}
   ${kv('Installed for', d.scope === 'user' ? 'Only you' : 'Everyone on this PC')}
   ${kv('Folder', esc(d.location || 'Unknown'))}${d.kind === 'desktop' ? kv('Program file', esc(d.exe || 'Not found')) : ''}
   ${d.uninstall ? kv('Uninstaller', `<span class="path">${esc(d.uninstall)}</span>`) : ''}</dl>
   <div class="acts">
    ${d.can_uninstall ? `<button class="btn dangerfill" data-a="p-uninstall" data-id="${d.id}">Uninstall</button>` : ''}
    ${d.exe && META.firewall && !d.system ? netBtn({exe: d.exe, name: d.name, blocked: d.blocked}).replace('data-a="net"', 'data-a="p-block" data-id="' + d.id + '"') : ''}
    ${d.exe ? (d.managed ? '<span class="tag">In My apps</span>' : `<button class="btn" data-a="p-manage" data-id="${d.id}">Add to My apps</button>`) : ''}
    ${d.location_exists ? `<button class="btn" data-a="p-open" data-id="${d.id}">Open folder</button>` : ''}
    <button class="btn" data-a="fav" data-id="${d.id}">${d.favorite ? '★ Favorite' : '☆ Add to favorites'}</button></div>`;
}
async function uninstall(ids) {
  const items = (D.programs?.items || []).filter(p => ids.includes(p.id));
  const bad = items.filter(p => !p.can_uninstall);
  if (bad.length) { toast(`${bad[0].name} can't be uninstalled from here.`); return; }
  const list = items.slice(0, 8).map(p => `<li>${esc(p.name)}</li>`).join('') + (items.length > 8 ? `<li>…and ${items.length - 8} more</li>` : '');
  const r = await dialog({title: items.length === 1 ? `Uninstall ${items[0].name}?` : `Uninstall ${items.length} programs?`,
    body: `<ul>${list}</ul>This removes the program from your PC. Your own files are usually kept, but some programs may delete their data.`,
    checks: [...(META.windows ? [{id: 'restore_point', label: 'Create a restore point first (safer; takes a moment)', checked: true}] : []),
      {id: 'silent', label: 'Uninstall quietly without asking questions, when the program supports it', checked: items.length > 1}],
    ok: 'Uninstall', danger: true});
  if (!r) return;
  const j = await post('/api/programs/uninstall', {ids, silent: !!r.silent, restore_point: !!r.restore_point, confirm: true});
  if (j) { ids.forEach(i => SEL.delete(i)); $('#drawer').hidden = true; openTasks(); pollJobs(); }
}

/* ---------- MY APPS ---------- */
function vMyApps() {
  const s = seg.myapps;
  if (s === 'running') {
    const a = (D.running?.items || []).filter(o => match(o, F.running.q.toLowerCase()));
    if (!D.running) return loadingBox('Looking at what is running…');
    return a.map(o => `<div class="row">${avatar(o.name)}<div class="info"><div class="name">${esc(o.name)} ${o.count > 1 ? `<span class="tag">${o.count} running</span>` : ''}</div><div class="path">${esc(o.exe)}</div></div>
      <div class="acts">${META.firewall && !o.system ? netBtn(o) : ''}${o.managed ? '<span class="tag">In My apps</span>' : (o.system ? '' : `<button class="btn" data-a="add" data-exe="${esc(o.exe)}" data-name="${esc(o.name)}">Add to My apps</button>`)}
      ${o.system ? '' : `<button class="btn danger" data-a="kill" data-exe="${esc(o.exe)}" data-name="${esc(o.name)}">Stop</button>`}</div></div>`).join('') || '<div class="empty">Nothing to show.</div>';
  }
  const A = D.apps; if (!A) return loadingBox('Loading…');
  if (s === 'blocked') {
    const a = A.blocked.filter(o => match(o, F.apps.q.toLowerCase()));
    return A.blocked.length ? a.map(o => `<div class="row">${avatar(o.name)}<div class="info"><div class="name">${esc(o.name)}${o.exists ? '' : ' <span class="tag">file missing</span>'}</div><div class="path">${esc(o.exe)}</div></div>
      <div class="acts">${netBtn({...o, blocked: true})}</div></div>`).join('') : '<div class="empty"><b>Nothing is blocked.</b><br>Every program is allowed to use the internet.</div>';
  }
  const a = A.apps.filter(o => match(o, F.apps.q.toLowerCase()));
  if (!A.apps.length) return `<div class="empty"><b>No apps here yet.</b><br>Add one from the <a href="#" data-go="programs">Programs</a> list (open a program and choose "Add to My apps"), from "Running now", or with "Add a program…".<br><br>My apps are programs App Manager can start, stop and keep running for you.</div>`;
  return a.map(o => `<div class="row">${avatar(o.name)}<div class="info"><div class="name">${esc(o.name)}${o.exists ? '' : ' <span class="tag">file missing</span>'}</div><div class="path">${esc(o.exe)}</div></div>
   <div class="state"><span class="dot ${o.running ? 'on' : ''}"></span>${o.running ? 'Running' : 'Stopped'}</div>
   <div class="acts">${o.running ? `<button class="btn" data-a="restart" data-id="${o.id}">Restart</button><button class="btn" data-a="stop" data-id="${o.id}">Stop</button>` : `<button class="btn primary" data-a="start" data-id="${o.id}">Start</button>`}
    ${META.firewall ? netBtn(o) : ''}<button class="btn danger" data-a="remove" data-id="${o.id}" title="Remove from My apps">Remove</button></div>
   <div class="opts"><label><input type="checkbox" data-a="flag" data-id="${o.id}" data-k="autostart" ${o.autostart ? 'checked' : ''}> Start with Windows</label>
    <label><input type="checkbox" data-a="flag" data-id="${o.id}" data-k="keep_running" ${o.keep_running ? 'checked' : ''}> Keep running (restart it if it closes)</label></div>
   ${o.note ? `<div class="note">${esc(o.note)}</div>` : ''}</div>`).join('');
}
const toolsMyApps = () => `${segCtl('myapps', [['managed', 'My apps'], ['running', 'Running now'], ['blocked', 'Blocked from internet']])}
  ${search(seg.myapps === 'running' ? 'running.q' : 'apps.q', seg.myapps === 'running' ? F.running.q : F.apps.q)}
  ${seg.myapps === 'running' ? `<label class="check sys"><input type="checkbox" data-a="sys" ${F.running.sys ? 'checked' : ''}> Show Windows system programs</label>` : ''}
  ${seg.myapps === 'managed' ? '<button class="btn primary" data-a="browse">Add a program…</button>' : ''}`;
async function refreshApps() {
  try { D.apps = await api('/api/apps'); if (seg.myapps === 'running') D.running = await api('/api/running' + (F.running.sys ? '?system=1' : '')); } catch (e) {}
  dataChanged('apps');
}

/* ---------- STARTUP ---------- */
function vStartup() {
  const S = D.startup;
  if (!S || (!S.ready && S.loading)) return loadingBox('Reading startup items…');
  const a = S.items.filter(o => match({n: o.name, c: o.command, w: o.where}, F.startup.q.toLowerCase()));
  return `${errBox(S.error)}<div class="count">${a.length} startup items. Turning one off doesn't delete it, and you can turn it back on any time.</div>
  <div class="tablewrap"><table><thead><tr><th class="nosort">Name</th><th class="nosort">Where it starts from</th><th class="nosort">On at startup</th></tr></thead><tbody>
  ${a.map(o => `<tr><td><b>${esc(o.name)}</b> ${o.ours ? '<span class="tag ok">App Manager</span>' : ''}<div class="sub">${esc(o.command)}</div></td><td class="mute">${esc(o.where)}</td>
   <td><label class="sw"><input type="checkbox" data-a="startup" data-id="${o.id}" ${o.enabled ? 'checked' : ''}><span></span></label></td></tr>`).join('') || '<tr><td colspan="3" class="empty">Nothing starts automatically.</td></tr>'}</tbody></table></div>`;
}
const toolsStartup = () => `${search('startup.q', F.startup.q)}<button class="btn" data-a="reload-startup">Refresh</button>`;

/* ---------- UPDATES ---------- */
function vProgUpdates() {
  const U = D.updates;
  if (!META.winget) return '<div class="banner">Windows Package Manager (winget) was not found. It comes with Windows 11 and current Windows 10 as <b>App Installer</b> in the Microsoft Store.</div>';
  if (!U || (!U.ready && U.loading)) return loadingBox('Checking for updates… this can take up to a minute.');
  const items = U.items;
  if (!items.length) return `${errBox(U.error)}<div class="empty"><b>Everything is up to date.</b><br>Updates come from Windows Package Manager, so programs it doesn't know about are not checked.</div>`;
  return `${errBox(U.error)}<div class="count">${items.length} update${items.length > 1 ? 's' : ''} available${U.loading ? ' · checking again…' : ''}</div><div class="list">
  ${items.map(u => `<div class="row">${avatar(u.name)}<div class="info"><div class="name">${esc(u.name)}</div><div class="path">${esc(u.id)} · ${esc(u.version)} → <b>${esc(u.available)}</b></div></div>
   <div class="acts">${u.explicit ? '<span class="tag warn" title="This one is pinned or needs to be updated by itself">Update separately</span>' : ''}<button class="btn" data-a="upd" data-id="${esc(u.id)}" data-name="${esc(u.name)}">Update</button></div></div>`).join('')}</div>`;
}
const toolsProgUpdates = () => `<button class="btn" data-a="reload-updates">Check again</button>
  <button class="btn primary" data-a="upd-all" ${D.updates?.items?.some(u => !u.explicit) ? '' : 'disabled'}>Update everything</button>`;
const vUpdates = () => seg.updates === 'drivers' ? vDriverCheck() : vProgUpdates();
const toolsUpdates = () => segCtl('updates', [['programs', 'Programs'], ['drivers', 'Drivers']]) + (seg.updates === 'drivers' ? '' : toolsProgUpdates());

/* ---------- DEVICES ---------- */
const kvl = rows => `<dl class="kv">${rows.filter(r => r[1] !== undefined && r[1] !== '' && r[1] !== null).map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>`;
function vHardware() {
  const h = D.hardware?.data;
  if (!h) return D.hardware?.error ? errBox(D.hardware.error) : loadingBox('Reading your hardware…');
  const s = h.system, b = h.board, bi = h.bios;
  return `<div class="grid">
   <div class="card"><h3>System</h3>${kvl([['Computer', esc(s.name)], ['Maker', esc(s.manufacturer)], ['Model', esc(s.model)], ['Windows', esc(s.os)], ['Version', esc([s.version, s.build && 'build ' + s.build].filter(Boolean).join(' '))], ['Architecture', esc(s.arch)], ['Windows installed', esc(s.installed)], ['Running for', fmtUptime(s.uptime)]])}</div>
   <div class="card"><h3>Motherboard and BIOS</h3>${kvl([['Board', esc([b.maker, b.product].filter(Boolean).join(' '))], ['BIOS maker', esc(bi.vendor)], ['BIOS version', esc(bi.version)], ['BIOS date', esc(bi.date)], ['Secure Boot', h.secureboot == null ? 'Unknown' : (h.secureboot ? 'On' : 'Off')]])}</div>
   ${h.cpu.map(c => `<div class="card"><h3>Processor</h3>${kvl([['Name', esc(c.name)], ['Cores', c.cores], ['Threads', c.threads], ['Speed', c.mhz ? (c.mhz / 1000).toFixed(2) + ' GHz' : '']])}</div>`).join('')}
   <div class="card"><h3>Memory</h3>${kvl([['Total', fmtBytes(h.ram.total)]])}${(h.ram.modules || []).map(m => `<div class="path" style="margin-top:6px">${esc(m.slot)}: ${fmtBytes(m.size)}${m.speed ? ' @ ' + m.speed + ' MHz' : ''} · ${esc([m.maker, m.part].filter(Boolean).join(' '))}</div>`).join('')}</div>
   ${h.gpu.map(g => `<div class="card"><h3>Graphics</h3>${kvl([['Name', esc(g.name)], ['Video memory', g.vram ? fmtBytes(g.vram) : ''], ['Driver', esc(g.driver)], ['Driver date', esc(g.date)]])}</div>`).join('')}
   <div class="card"><h3>Drives</h3>${(h.disks || []).map(d => `<div class="name">${esc(d.name)} ${/^healthy$/i.test(d.health) ? '<span class="tag ok">Healthy</span>' : (d.health && d.health !== 'Unknown' ? `<span class="tag warn">${esc(d.health)}</span>` : '')}</div><div class="path">${esc([d.type, d.bus, fmtBytes(d.size)].filter(x => x && x !== 'Unspecified').join(' · '))}</div>`).join('') || '—'}</div>
   <div class="card"><h3>Volumes</h3>${(h.volumes || []).map(v => { const used = v.size ? 100 - v.free / v.size * 100 : 0; return `<div class="name">${esc(v.drive)} ${esc(v.label || '')} <span class="tag">${esc(v.fs)}</span></div><div class="bar"><i class="${used > 85 ? 'low' : ''}" style="width:${used.toFixed(0)}%"></i></div><div class="path">${fmtBytes(v.free)} free of ${fmtBytes(v.size)}</div>`; }).join('') || '—'}</div></div>`;
}
function vTree() {
  const T = D.devices;
  if (!T || (!T.ready && T.loading)) return loadingBox('Reading your devices…');
  const f = F.tree, q = f.q.toLowerCase();
  const items = T.items.filter(d => (f.absent || d.present) && (!f.problems || d.problem) && match({n: d.name, m: d.maker, c: d.cls}, q));
  const groups = {}; items.forEach(d => (groups[d.cls] = groups[d.cls] || []).push(d));
  const probs = T.items.filter(d => d.problem).length;
  return `${errBox(T.error)}<div class="count">${items.length} devices${probs ? ` · <b style="color:var(--bad)">${probs} with problems</b>` : ' · no problems reported'}</div>
  ${Object.keys(groups).sort((a, b) => a.localeCompare(b)).map(g => { const bad = groups[g].filter(d => d.problem).length;
    return `<details class="grp" ${(bad || f.q || f.problems || groups[g].some(d => d.disabled && d.present)) ? 'open' : ''}><summary>${esc(g)} <span class="tag">${groups[g].length}</span>${bad ? `<span class="tag bad">${bad} problem${bad > 1 ? 's' : ''}</span>` : ''}</summary>
    ${groups[g].map(d => `<div class="dev"><div class="grow"><div>${esc(d.name)}</div><div class="sub">${esc(d.maker)}</div></div>${d.problem ? `<span class="tag bad">${esc(d.problem)}</span>` : ''}${d.disabled ? '<span class="tag warn">Turned off</span>' : ''}${d.present ? '' : '<span class="tag">Not connected</span>'}
      ${d.problem && d.present ? `<button class="btn small primary" data-a="dev-fix" data-id="${esc(d.id)}" data-name="${esc(d.name)}">Diagnose &amp; fix</button><button class="btn small" data-a="dev-fix" data-level="reinstall" data-id="${esc(d.id)}" data-name="${esc(d.name)}">Reinstall…</button>` : ''}
      ${d.disabled && d.present ? `<button class="btn small" data-a="dev-fix" data-id="${esc(d.id)}" data-name="${esc(d.name)}">Turn on</button>` : ''}</div>`).join('')}</details>`; }).join('') || '<div class="empty">Nothing matches.</div>'}`;
}
function vDrivers() {
  const R = D.drivers;
  if (!R || (!R.ready && R.loading)) return loadingBox('Reading driver information… this can take a little while.');
  const f = F.drivers;
  const a = R.items.filter(d => match({a: d.device, b: d.cls, c: d.provider, d: d.version}, f.q.toLowerCase()));
  a.sort((x, y) => (String(x[f.sort] || '').localeCompare(String(y[f.sort] || ''), undefined, {sensitivity: 'base', numeric: true}) * f.dir));
  const h = (k, l) => th(k, l, '', 'drivers', f);
  return `${errBox(R.error)}<div class="count">${a.length} drivers. This list is information only; it doesn't download or change drivers.</div>
  <div class="tablewrap"><table><thead><tr>${h('device', 'Device')}${h('cls', 'Type')}${h('provider', 'Provider')}${h('version', 'Version')}${h('date', 'Date')}</tr></thead><tbody>
  ${a.map(d => `<tr><td><b>${esc(d.device)}</b></td><td class="mute">${esc(d.cls)}</td><td class="mute">${esc(d.provider)}</td><td class="mute">${esc(d.version)}</td>
   <td class="mute">${esc(d.date)} ${yearsOld(d.date) > 3 ? '<span class="tag warn">3+ years old</span>' : ''}${d.signed ? '' : ' <span class="tag bad">unsigned</span>'}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">Nothing matches.</td></tr>'}</tbody></table></div>`;
}
const vDevices = () => ({hardware: vHardware, tree: vTree, drivers: vDrivers}[seg.devices])();
function toolsDevices() {
  const s = seg.devices;
  return segCtl('devices', [['hardware', 'Hardware'], ['tree', 'Device tree'], ['drivers', 'Drivers']]) +
    (s === 'tree' ? `${search('tree.q', F.tree.q)}<label class="check"><input type="checkbox" data-f="tree.problems" ${F.tree.problems ? 'checked' : ''}> Only problems</label>
      <label class="check"><input type="checkbox" data-f="tree.absent" ${F.tree.absent ? 'checked' : ''}> Include unplugged devices</label>
      <button class="btn primary" data-a="dev-fixall" ${(D.devices?.items || []).some(x => x.problem && x.present) ? '' : 'disabled'}>Fix all problems</button>` : '') +
    (s === 'drivers' ? search('drivers.q', F.drivers.q) : '') +
    `<button class="btn" data-a="reload-devices">Refresh</button>`;
}

/* ---------- INSTALL ---------- */
const INST = new Set();
F.install = {q: ''};
function vInstall() {
  const I = D.install;
  if (!META.winget) return '<div class="banner">Windows Package Manager (winget) was not found. It comes with Windows 11 and current Windows 10 as <b>App Installer</b> in the Microsoft Store.</div>';
  if (I?.error && !I.categories) return errBox(I.error);
  if (!I || !I.categories) return loadingBox('Loading the app list…');
  const q = F.install.q.toLowerCase();
  const cats = I.categories.map(c => ({...c, items: c.items.filter(a => match({n: a.name, d: a.desc, i: a.id, c: c.name}, q))})).filter(c => c.items.length);
  return `${errBox(I.error)}
  <div class="presets"><span class="mute">Quick picks:</span> ${I.presets.map((p, n) => `<button class="btn small" data-a="preset" data-i="${n}" title="${esc(p.desc)}">${esc(p.name)}</button>`).join('')} <button class="btn small" data-a="preset-clear">Clear</button></div>
  ${cats.map(c => `<h2 class="cat">${esc(c.name)}</h2><div class="picks">${c.items.map(a => `<label class="pick ${a.installed ? 'have' : ''}">
    <input type="checkbox" data-a="inst" data-id="${esc(a.id)}" ${a.installed ? 'disabled' : ''} ${INST.has(a.id) ? 'checked' : ''}>
    <span class="grow"><b>${esc(a.name)}</b> ${a.installed ? '<span class="tag ok">Installed</span>' : ''}${a.kind === 'file' ? '<span class="tag">Installer file</span>' : ''}${a.missing ? '<span class="tag bad">File missing</span>' : ''}<br><span class="sub">${esc(a.desc)}</span></span>
    <button class="x" data-a="inst-remove" data-id="${esc(a.id)}" data-name="${esc(a.name)}" title="Remove from this list">✕</button></label>`).join('')}</div>`).join('') || '<div class="empty">Nothing matches.</div>'}
  <p class="foot">Programs come from the official Windows Package Manager (winget) list and install silently with their default settings.${I.loading ? ' Checking what is already installed…' : ''}</p>`;
}
const toolsInstall = () => `${search('install.q', F.install.q, 'Search programs…')}<button class="btn" data-a="add-program">+ Add program</button>${D.install?.hidden ? `<button class="btn" data-a="inst-restore" title="Bring back the programs you removed">Restore removed (${D.install.hidden})</button>` : ''}<button class="btn" data-a="reload-install">Refresh</button>
  <button class="btn primary" id="instBtn" data-a="install-sel" ${INST.size ? '' : 'disabled'}>Install selected (${INST.size})</button>`;
function updateInstBtn() { const b = $('#instBtn'); if (b) { b.disabled = !INST.size; b.textContent = `Install selected (${INST.size})`; } }


function addProgramDialog() {
  const m = $('#modal'); m.hidden = false;
  let mode = 'search', results = [], busy = '', added = new Set();
  const draw = () => {
    m.innerHTML = `<div class="dialog"><h2>Add a program to the list</h2>
     <div class="seg" style="margin-bottom:12px"><button data-x="mode:search" class="${mode === 'search' ? 'on' : ''}">Search the winget catalog</button><button data-x="mode:file" class="${mode === 'file' ? 'on' : ''}">An installer file</button></div>
     ${mode === 'search' ? `<div class="mini add" style="border:0;padding:0"><input type="search" id="addQ" placeholder="Program name, e.g. Krita"><button class="btn primary small" data-x="search">Search</button></div>
       <div id="addRes">${busy ? `<div class="path" style="padding:10px 0">${esc(busy)}</div>` : results.map((r, i) => `<div class="mini"><div class="grow"><div class="name">${esc(r.name)}</div><div class="path">${esc(r.id)} · ${esc(r.version)}</div></div>
          <button class="btn small" data-x="add:${i}" ${added.has(r.id) ? 'disabled' : ''}>${added.has(r.id) ? 'Added' : 'Add'}</button></div>`).join('')}</div>`
      : `<div class="path" style="margin-bottom:8px">Add an installer you downloaded (.exe or .msi). App Manager runs it for you with the switches you give.</div>
       <div class="mini add" style="border:0;padding:0"><input type="search" id="addPath" placeholder="C:\\Users\\you\\Downloads\\setup.exe"><button class="btn small" data-x="browse">Browse…</button></div>
       <div class="mini add" style="border:0"><input type="search" id="addName" placeholder="Name to show (optional)"></div>
       <div class="mini add" style="border:0"><input type="search" id="addArgs" placeholder="Silent switches, e.g. /S or /VERYSILENT (optional)"></div>
       <div class="path">.msi files are always installed quietly. For .exe files the switch depends on the program; leave it empty to see the installer's own window.</div>
       <div class="btns" style="margin-top:8px"><button class="btn primary" data-x="addfile">Add installer</button></div>`}
     <div class="btns"><button class="btn" data-x="close">Done</button></div></div>`;
    $('#addQ')?.addEventListener('keydown', e => { if (e.key === 'Enter') m.querySelector('[data-x="search"]').click(); });
  };
  const close = () => { m.hidden = true; m.innerHTML = ''; m.onclick = null; load('install', '/api/install', true); };
  m.onclick = async e => {
    const x = e.target.closest('[data-x]');
    if (!x) { if (e.target === m) close(); return; }
    const [k, v] = x.dataset.x.split(':');
    if (k === 'close') return close();
    if (k === 'mode') { mode = v; return draw(); }
    if (k === 'search') {
      const q = ($('#addQ').value || '').trim(); busy = 'Searching…'; results = []; draw(); $('#addQ').value = q;
      try { results = (await api('/api/install/search', {q})).items; busy = results.length ? '' : 'Nothing found. Try a shorter name.'; } catch (er) { busy = er.message; }
      draw(); $('#addQ').value = q; return;
    }
    if (k === 'add') {
      const r = results[+v]; const j = await post('/api/install/add', {kind: 'winget', id: r.id, name: r.name, desc: r.id}, `${r.name} added`);
      if (j) { added.add(r.id); const q = $('#addQ').value; draw(); $('#addQ').value = q; } return;
    }
    if (k === 'browse') { const r = await post('/api/pick', {}); if (r && r.path) $('#addPath').value = r.path; return; }
    if (k === 'addfile') {
      const j = await post('/api/install/add', {kind: 'file', path: $('#addPath').value, name: $('#addName').value, args: $('#addArgs').value}, 'Installer added');
      if (j) close(); return;
    }
  };
  draw();
}

/* ---------- TWEAKS ---------- */
const TW = new Set();
const stateTag = s => s === 'on' ? '<span class="tag ok">Applied</span>' : (s === 'partial' ? '<span class="tag warn">Partly applied</span>' : '<span class="tag">Not applied</span>');
function twRow(t) {
  return `<div class="row tw"><input type="checkbox" data-a="tw" data-id="${t.id}" ${t.state === 'on' ? 'disabled' : ''} ${TW.has(t.id) ? 'checked' : ''}>
   <div class="info"><div class="name">${esc(t.name)} ${stateTag(t.state)}${t.restart === 'reboot' ? ' <span class="tag">Needs restart</span>' : ''}</div><div class="path">${esc(t.desc)}</div></div>
   <div class="acts">${t.undo ? `<button class="btn small" data-a="tw-undo" data-id="${t.id}" data-name="${esc(t.name)}">Undo</button>` : ''}</div></div>`;
}
function vTweaks() {
  const T = D.tweaks;
  if (T?.error && !T.items?.length) return errBox(T.error);
  if (!T || !T.items) return loadingBox('Reading your current settings…');
  const safe = T.items.filter(t => t.group === 'safe'), adv = T.items.filter(t => t.group === 'adv');
  return `${errBox(T.error)}<div class="banner info">Every change remembers the old setting, so <b>Undo</b> puts it back. Windows Defender, Windows Update and the firewall are never touched here.</div>
  <h2 class="cat">Recommended <span class="tag ok">Low risk</span></h2><div class="list tight">${safe.map(twRow).join('')}</div>
  <h2 class="cat">Advanced <span class="tag bad">Read before using</span></h2>
  <div class="banner">These turn off parts of Windows. They can free resources, but some features or support tools may stop working. Pick only what you understand.</div>
  <div class="list tight">${adv.map(twRow).join('')}</div>
  <h2 class="cat">One-time tools</h2><div class="list">${T.actions.map(a => `<div class="row"><div class="info"><div class="name">${esc(a.name)}</div><div class="path">${esc(a.desc)}</div></div>
    <div class="acts"><button class="btn" data-a="tw-action" data-id="${a.id}" data-name="${esc(a.name)}">Run</button></div></div>`).join('')}</div>`;
}
const toolsTweaks = () => `<button class="btn" data-a="reload-tweaks">Refresh</button>
  <button class="btn primary" id="twBtn" data-a="tw-apply" ${TW.size ? '' : 'disabled'}>Apply selected (${TW.size})</button>`;
function updateTwBtn() { const b = $('#twBtn'); if (b) { b.disabled = !TW.size; b.textContent = `Apply selected (${TW.size})`; } }

/* ---------- SECURITY ---------- */
const SEC_NOTE = {
  cfa: 'Only trusted programs will be allowed to change files in Documents, Pictures, Videos, Music and Desktop. A program Windows does not trust may be blocked from saving there. It will show up in the “Recently blocked” list below, where you can allow it with one click.',
  smb1: 'Turns off the old SMB1 file-sharing protocol. Only very old devices (such as ancient NAS boxes or scanners) still need it.',
  rdp: 'Nobody will be able to connect to this PC with Remote Desktop.',
  uac: 'Windows will ask before programs make system-wide changes. A restart is needed.',
  fw: 'Turns the Windows Firewall on for every network type.'
};
const secDot = s => `<span class="sdot ${s}" title="${s}"></span>`;
function vSecurity() {
  const S = D.security;
  if (!S || (!S.ready && S.loading)) return loadingBox('Checking your security settings…');
  if (!S.items.length) return errBox(S.error || 'Could not read the security settings.');
  const groups = {}; S.items.forEach(i => (groups[i.group] = groups[i.group] || []).push(i));
  const fixable = S.items.filter(i => i.can_fix && !i.optional && i.status === 'bad');
  return `${errBox(S.error)}<div class="card sum"><div class="big">${S.good} of ${S.total} protections are on</div>
   <div class="bar"><i class="${S.good < S.total / 2 ? 'low' : ''}" style="width:${S.total ? S.good / S.total * 100 : 0}%"></i></div>
   <div class="path">${fixable.length ? `${fixable.length} can be turned on right here. Each one can be undone.` : 'Nothing else can be fixed from here.'}${S.loading ? ' · checking again…' : ''}</div></div>
  ${Object.keys(groups).map(g => `<h2 class="cat">${esc(g)}</h2><div class="list tight">${groups[g].map(secRow).join('')}</div>`).join('')}
  ${vCfa()}`;
}
function secRow(i) {
  return `<div class="row sec">${secDot(i.status)}<div class="info"><div class="name">${esc(i.name)} ${i.optional ? '<span class="tag">Optional</span>' : ''}${i.restart ? ' <span class="tag">Needs restart</span>' : ''}</div>
    <div class="path">${esc(i.desc)}</div><div class="path st-${i.status}">${esc(i.detail)}</div></div>
   <div class="acts">${i.can_fix ? `<button class="btn small primary" data-a="sec-fix" data-id="${i.id}" data-name="${esc(i.name)}">Turn on</button>` : ''}
   ${i.can_audit ? `<button class="btn small" data-a="sec-fix" data-mode="audit" data-id="${i.id}" data-name="${esc(i.name)}" title="Only record what would be blocked">Audit only</button>` : ''}
   ${i.can_restore ? `<button class="btn small" data-a="sec-restore" data-id="${i.id}" data-name="${esc(i.name)}">Restore previous</button>` : ''}</div></div>`;
}
function vCfa() {
  const C = D.cfa;
  if (!C || C.error) return '';
  const row = (p, btn) => `<div class="mini"><span class="path grow">${esc(p)}</span>${btn}</div>`;
  return `<h2 class="cat">Controlled Folder Access: apps and folders</h2>
  <div class="card cfa"><h3>Status</h3><div class="name">${{on: 'On: unknown programs are blocked', audit: 'Audit only: nothing is blocked yet, it is only recorded', off: 'Off'}[C.mode]}</div>
   <h3 style="margin-top:14px">Recently blocked programs</h3>
   ${C.recent.length ? C.recent.map(a => `<div class="mini"><div class="grow"><div class="name">${esc(a.app.split('\\').pop())} <span class="tag ${a.mode === 'blocked' ? 'bad' : 'warn'}">${a.mode === 'blocked' ? 'Blocked' : 'Would be blocked'} ×${a.count}</span></div>
      <div class="path">${esc(a.app)}<br>Last: ${esc(a.last)}${a.file ? ' · ' + esc(a.file) : ''}</div></div>
      <button class="btn small" data-a="cfa-allow" data-path="${esc(a.app)}">Allow this program</button></div>`).join('') : '<div class="path">Nothing has been blocked recently.</div>'}
   <h3 style="margin-top:14px">Allowed programs</h3>
   ${C.allowed.map(p => row(p, `<button class="btn small" data-a="cfa-unallow" data-path="${esc(p)}">Remove</button>`)).join('') || '<div class="path">None added by you. Windows already trusts its own programs.</div>'}
   <div class="mini add"><input type="search" id="cfaApp" placeholder="C:\\Program Files\\App\\app.exe"><button class="btn small" data-a="cfa-browse">Browse…</button><button class="btn small primary" data-a="cfa-allow-typed">Allow</button></div>
   <h3 style="margin-top:14px">Extra protected folders</h3>
   ${C.folders.map(p => row(p, `<button class="btn small" data-a="cfa-unfolder" data-path="${esc(p)}">Remove</button>`)).join('') || '<div class="path">Only the standard folders (Documents, Pictures, Videos, Music, Desktop) are protected.</div>'}
   <div class="mini add"><input type="search" id="cfaDir" placeholder="D:\\Projects"><button class="btn small primary" data-a="cfa-folder">Protect this folder</button></div></div>`;
}
const toolsSecurity = () => `<button class="btn" data-a="reload-security">Check again</button>
  <button class="btn primary" data-a="sec-fixall" ${(D.security?.items || []).some(i => i.can_fix && !i.optional && i.status === 'bad') ? '' : 'disabled'}>Turn on everything recommended</button>`;

/* ---------- DRIVER CHECK (inside Devices) ---------- */
const DC = {cat: true, ven: true};
function vDriverCheck() {
  const X = D.drivercheck;
  if (X?.error && !X.identity) return errBox(X.error);
  if (!X) return loadingBox('Reading this PC\'s details…');
  const id = X.identity, last = X.last;
  const auto = X.vendor_auto;
  const rows = (last?.items || []);
  const newer = rows.filter(r => r.status === 'newer');
  const link = last?.link || X.link;
  return `<div class="grid"><div class="card"><h3>This PC</h3>${kvl([['Maker', esc(id.maker)], ['Model', esc(id.model)], ['Motherboard', esc([id.board_maker, id.board].filter(Boolean).join(' '))], ['Serial number', esc(id.serial) || '<span class="mute">Not stored in the BIOS</span>'], ['BIOS', esc(id.bios)]])}</div>
   <div class="card"><h3>Where to look</h3>
    <label class="check"><input type="checkbox" data-a="dc-cat" ${DC.cat ? 'checked' : ''}> Microsoft Update Catalog (matches each device's hardware ID)</label>
    <label class="check" style="margin-top:6px"><input type="checkbox" data-a="dc-ven" ${DC.ven ? 'checked' : ''}> ${auto ? 'ASUS support site (matches your model)' : esc(id.maker || 'Maker') + ' site (no automatic lookup yet, link only)'}</label>
    <div class="acts" style="margin-top:12px"><button class="btn primary" data-a="dc-run" ${(DC.cat || DC.ven) ? '' : 'disabled'}>Check for driver updates</button>
    <a class="btn" href="${esc(link.url)}" target="_blank" rel="noopener">${esc(link.name)}</a></div></div></div>
  ${last ? `<div class="count">Last checked ${esc(last.when)} · ${newer.length} possible update${newer.length === 1 ? '' : 's'}, ${rows.length} compared</div>
   <div class="tablewrap"><table><thead><tr><th class="nosort">Device</th><th class="nosort">Installed</th><th class="nosort">Available</th><th class="nosort">Source</th><th class="nosort"></th></tr></thead><tbody>
   ${rows.map(r => `<tr><td><b>${esc(r.device)}</b><div class="sub">${esc(r.cls)}</div></td><td class="mute">${esc(r.installed) || '—'}<div class="sub">${esc(r.installed_date)}</div></td>
    <td>${r.status === 'newer' ? `<b>${esc(r.available)}</b> <span class="tag warn">Newer</span>` : (r.status === 'current' ? `${esc(r.available)} <span class="tag ok">Up to date</span>` : `${esc(r.available)} <span class="tag">Can't compare</span>`)}<div class="sub">${esc(r.available_date)}</div></td>
    <td class="mute">${r.source === 'vendor' ? 'Maker' : 'Microsoft Catalog'}</td><td>${r.url ? `<a class="btn small" href="${esc(r.url)}" target="_blank" rel="noopener">${r.source === 'vendor' ? 'Download page' : 'View in Catalog'}</a>` : ''}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">No matching drivers were found.</td></tr>'}</tbody></table></div>
   <p class="foot">These are <b>possible</b> updates. App Manager only compares version numbers and never downloads or installs a driver. Check the notes on the download page, and create a restore point before installing. ${last.notes?.includes('vendor-empty') ? (auto ? 'ASUS had no list for this model; desktop motherboards are not covered by that service, so use the support link above.' : 'This maker has no automatic lookup yet, so use the support link above.') : ''}</p>`
   : '<div class="empty"><b>Not checked yet.</b><br>Press <i>Check for driver updates</i>. It takes a minute or two and changes nothing on this PC.</div>'}`;
}

/* ---------- MONITOR ---------- */
const fmtRate = b => b == null ? '—' : fmtBytes(b) + '/s';
function spark(vals, max, cls = '') {
  const w = 300, h = 60, n = 90;
  const v = vals.slice(-n); if (v.length < 2) return `<svg class="spark ${cls}" viewBox="0 0 ${w} ${h}"></svg>`;
  const m = max || Math.max(1, ...v.filter(x => x != null));
  const pts = v.map((x, i) => `${(i / (n - 1) * w + (w - (v.length - 1) / (n - 1) * w)).toFixed(1)},${(h - (Math.min(x ?? 0, m) / m) * (h - 4) - 2).toFixed(1)}`);
  return `<svg class="spark ${cls}" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><polyline points="${pts.join(' ')}"/></svg>`;
}
function vMonitor() {
  const M = D.monitor;
  if (!M || M.error && !M.samples) return M?.error ? errBox(M.error) : loadingBox('Starting the monitor…');
  const s = M.samples, last = s[s.length - 1];
  if (!last) return loadingBox('Collecting the first readings…');
  const memPct = last.mem_used / last.mem_total * 100;
  const card = (t, big, sub, svg) => `<div class="card"><h3>${t}</h3><div class="big">${big}</div><div class="path">${sub}</div>${svg}</div>`;
  const H = M.health;
  return `<div class="grid">
   ${card('Processor', last.cpu == null ? '—' : last.cpu.toFixed(0) + '%', M.cores + ' logical processors', spark(s.map(x => x.cpu ?? 0), 100))}
   ${card('Memory', memPct.toFixed(0) + '%', fmtBytes(last.mem_used) + ' of ' + fmtBytes(last.mem_total), spark(s.map(x => x.mem_used / x.mem_total * 100), 100, 'sp-mem'))}
   ${card('Network, download', fmtRate(last.rx), 'Data coming in', spark(s.map(x => x.rx ?? 0), 0, 'sp-down'))}
   ${card('Network, upload', fmtRate(last.tx), 'Data going out', spark(s.map(x => x.tx ?? 0), 0, 'sp-up'))}</div>
  <h2 class="cat">Busiest programs</h2>
  <div class="tablewrap" style="margin-bottom:20px"><table><thead><tr><th class="nosort">Program</th><th class="nosort num">Processor</th><th class="nosort num">Memory</th></tr></thead><tbody>
   ${M.procs.map(p => `<tr><td><b>${esc(p.name)}</b>${p.count > 1 ? ` <span class="tag">${p.count} processes</span>` : ''}</td><td class="num">${p.cpu.toFixed(1)}%</td><td class="num mute">${fmtBytes(p.mem)}</td></tr>`).join('') || '<tr><td colspan="3" class="empty">Reading…</td></tr>'}</tbody></table></div>
  <h2 class="cat">Health</h2>${!H ? loadingBox('Reading drive health…') : `<div class="grid">
   ${H.disks.map(d => `<div class="card"><h3>${esc(d.type || 'Drive')}</h3><div class="name">${esc(d.name)} ${d.notes.length ? '<span class="tag warn">Check</span>' : '<span class="tag ok">OK</span>'}</div>
     ${kvl([['Health', esc(d.health)], ['Temperature', d.temp ? d.temp + ' °C' : ''], ['Life used', d.wear != null ? d.wear + '%' : ''], ['Powered on', d.hours ? Math.round(d.hours / 24) + ' days' : ''], ['Errors', (d.rerr || 0) + (d.werr || 0) ? (d.rerr || 0) + (d.werr || 0) : '']])}
     ${d.notes.map(n => `<div class="note">${esc(n)}</div>`).join('')}</div>`).join('')}
   ${(H.temps || []).length ? `<div class="card"><h3>Temperature</h3>${kvl(H.temps.map((t, i) => ['Sensor ' + (i + 1), t + ' °C']))}<div class="path">As reported by the PC's firmware. Many PCs do not report CPU temperature this way.</div></div>` : ''}
   ${H.battery ? `<div class="card"><h3>Battery</h3><div class="big">${H.battery.charge}%</div><div class="path">${H.battery.status === 2 ? 'Plugged in' : 'On battery'}</div></div>` : ''}</div>`}`;
}
let monTimer = null;
function monStart() {
  clearInterval(monTimer);
  const tick = async () => { if (tab !== 'monitor') return clearInterval(monTimer); if (document.hidden) return; try { D.monitor = await api('/api/monitor'); dataChanged('monitor'); } catch (e) { D.monitor = {error: e.message}; dataChanged('monitor'); } };
  tick(); monTimer = setInterval(tick, 2500);
}

/* ---------- TOOLS (cleanup, big files, duplicates, error log, network, repair, report) ---------- */
F.tools = {folder: '', mb: '100', dmb: '1', host: '', port: ''};
const CL = new Set(), TRASH = new Set();
const TOOLSEGS = [['cleanup', 'Cleanup'], ['large', 'Large files'], ['dups', 'Duplicates'], ['events', 'Error log'], ['network', 'Network'], ['repair', 'Repair & Windows'], ['remote', 'Remote support'], ['report', 'Report']];
function vTools() {
  return ({cleanup: vCleanup, large: vLarge, dups: vDups, events: vEvents, network: vNetwork, repair: vRepair, remote: vRemoteTools, report: vReport}[seg.tools])();
}
function vRemoteTools() {
  const R = D.remote; if (!R) return loadingBox('Looking for remote desktop programs…');
  return `<div class="banner info">App Manager does not replace AnyDesk, UltraViewer, AnyViewer or Remote Utilities. It finds them, installs them and lets a hub open them. This page shows the ID of each one on this PC so you can read it out or type it into the hub.</div>
  <div class="list" style="margin-top:14px">${R.items.map(t => `<div class="row"><div class="info"><div class="name">${esc(t.name)} ${t.installed ? '<span class="tag ok">Installed</span>' : '<span class="tag">Not installed</span>'}</div>
    <div class="path">${t.remote_id ? 'ID on this PC: <b>' + esc(t.remote_id) + '</b>' + (t.id_source === 'typed' ? ' (typed in)' : '') : (t.installed ? 'ID not read automatically. Open it and copy the ID, then type it in.' : '')}</div>
    ${t.note ? `<div class="path">${esc(t.note)}</div>` : ''}${!t.verified && !t.installed ? '<div class="path">Install uses winget; this program\'s winget ID has not been checked, so it may fail.</div>' : ''}</div>
    <div class="acts">${t.installed ? `<button class="btn" data-a="rm-open" data-id="${t.id}">Open</button>` : `<button class="btn primary" data-a="rm-install" data-id="${t.id}" data-name="${esc(t.name)}">Install</button>`}
     ${t.installed && !(t.id_source === 'auto') ? `<button class="btn" data-a="rm-id" data-id="${t.id}" data-name="${esc(t.name)}" data-cur="${esc(t.remote_id)}">Type ID</button>` : ''}</div></div>`).join('')}</div>`;
}
function vCleanup() {
  const C = D.cleanup;
  if (!C || (!C.ready && C.loading)) return loadingBox('Measuring what can be cleaned up…');
  const total = C.items.filter(i => CL.has(i.id)).reduce((a, i) => a + i.size, 0);
  return `${errBox(C.error)}<div class="count">${fmtBytes(C.items.reduce((a, i) => a + i.size, 0))} can be cleaned in total${C.loading ? ' · measuring again…' : ''}</div><div class="list">
   ${C.items.map(i => `<label class="row"><input type="checkbox" data-a="cl" data-id="${i.id}" ${CL.has(i.id) ? 'checked' : ''}>
    <div class="info"><div class="name">${esc(i.name)} ${i.admin && !C.admin ? '<span class="tag warn">Needs administrator</span>' : ''}</div><div class="path">${esc(i.desc)}</div></div>
    <div class="num"><b>${i.id === 'recycle' && !i.size ? '—' : fmtBytes(i.size)}</b><div class="path">${i.files ? i.files + ' files' : ''}</div></div></label>`).join('')}</div>
   <p class="foot">Only temporary and cache folders are touched. Files that are in use are skipped. Selected: ${fmtBytes(total)}.</p>`;
}
const toolsCleanup = () => `<button class="btn" data-a="reload-cleanup">Measure again</button><button class="btn primary" id="clBtn" data-a="cl-run" ${CL.size ? '' : 'disabled'}>Clean selected (${CL.size})</button>`;
const folderBox = (kind) => `<input type="search" data-f="tools.folder" placeholder="Folder to look in (leave empty for your user folder)" value="${esc(F.tools.folder)}"><button class="btn" data-a="pick-folder">Browse…</button>`;
function vLarge() {
  const R = D.cleanupres?.large;
  if (!R) return '<div class="empty"><b>Find what is using your space.</b><br>Choose a folder and the smallest size to look for, then press <i>Find</i>.</div>';
  return `<div class="count">Biggest files in ${esc(R.root)} · scanned ${esc(R.when)}</div>${fileTable(R.items.map(i => ({path: i.path, size: i.size, extra: i.modified})))}`;
}
function fileTable(rows) {
  return `<div class="tablewrap"><table><thead><tr><th class="nosort"></th><th class="nosort">File</th><th class="nosort num">Size</th><th class="nosort">Modified</th><th class="nosort"></th></tr></thead><tbody>
   ${rows.map(r => `<tr><td><input type="checkbox" data-a="trash" data-path="${esc(r.path)}" ${TRASH.has(r.path) ? 'checked' : ''}></td><td><b>${esc(r.path.split(/[\\/]/).pop())}</b><div class="sub">${esc(r.path)}</div></td>
    <td class="num">${fmtBytes(r.size)}</td><td class="mute">${esc(r.extra || '')}</td><td><button class="btn small" data-a="reveal" data-path="${esc(r.path)}">Show</button></td></tr>`).join('') || '<tr><td colspan="5" class="empty">Nothing found.</td></tr>'}</tbody></table></div>`;
}
function vDups() {
  const R = D.cleanupres?.dups;
  if (!R) return '<div class="empty"><b>Find identical files.</b><br>Choose a folder, then press <i>Find</i>. Matching is by content, so renamed copies are found too.</div>';
  return `<div class="count">${R.groups.length} groups · ${fmtBytes(R.wasted)} wasted in ${esc(R.root)} · scanned ${esc(R.when)}. Tick the copies to remove; one copy of each is always kept.</div>
   ${R.groups.map(g => `<div class="card dupg"><div class="name">${fmtBytes(g.size)} × ${g.files.length} copies</div>${g.files.map(f => `<label class="mini"><input type="checkbox" data-a="trash" data-path="${esc(f)}" ${TRASH.has(f) ? 'checked' : ''}><span class="path grow">${esc(f)}</span><button class="btn small" data-a="reveal" data-path="${esc(f)}">Show</button></label>`).join('')}</div>`).join('') || '<div class="empty">No duplicates found.</div>'}`;
}
const toolsFinder = kind => folderBox(kind) + `<input type="search" data-f="tools.${kind === 'large' ? 'mb' : 'dmb'}" style="max-width:110px;flex:none" value="${esc(kind === 'large' ? F.tools.mb : F.tools.dmb)}" title="Smallest file size to look for, in MB"><span class="mute">MB or more</span>
  <button class="btn primary" data-a="find-${kind}">Find</button><button class="btn dangerfill" id="trBtn" data-a="trash-run" ${TRASH.size ? '' : 'disabled'}>Move to Recycle Bin (${TRASH.size})</button>`;
function vEvents() {
  const E = D.events;
  if (!E || (!E.ready && E.loading)) return loadingBox('Reading the Windows error log… this can take a minute.');
  return `${errBox(E.error)}<div class="count">Errors and critical events from the last 7 days, grouped. Crashes are listed first.</div>
   <div class="tablewrap"><table><thead><tr><th class="nosort">What</th><th class="nosort">Source</th><th class="nosort num">Times</th><th class="nosort">Last</th></tr></thead><tbody>
   ${E.items.map(g => `<tr><td>${g.crash ? '<span class="tag bad">Crash</span> ' : ''}${esc(g.msg)}<div class="sub">${esc(g.log)} · event ${esc(g.id)} · ${esc(g.lvl)}</div></td><td class="mute">${esc(g.src)}</td><td class="num">${g.count}</td><td class="mute">${esc(g.last)}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">No errors in the last 7 days.</td></tr>'}</tbody></table></div>`;
}
function vNetwork() {
  const N = D.network;
  const res = D.netout ? `<pre class="log" style="max-height:260px">${esc(D.netout)}</pre>` : '';
  return `<div class="card" style="margin-bottom:12px"><h3>Test a connection</h3><div class="mini add" style="border:0;padding-top:0">
    <input type="search" data-f="tools.host" placeholder="example.com or 192.168.1.1" value="${esc(F.tools.host)}">
    <input type="search" data-f="tools.port" style="max-width:100px;flex:none" placeholder="Port" value="${esc(F.tools.port)}"></div>
    <div class="acts"><button class="btn" data-a="net-ping">Ping</button><button class="btn" data-a="net-dns">Look up address</button><button class="btn" data-a="net-port">Check port</button><button class="btn" data-a="net-trace">Trace route</button></div>${res}</div>
   <h2 class="cat">Adapters</h2>${!N ? loadingBox('Reading network adapters…') : `<div class="grid">${N.items.map(a => `<div class="card"><h3>${a.up ? 'Connected' : 'Disconnected'}</h3><div class="name">${esc(a.name)}</div>
     ${kvl([['Adapter', esc(a.desc)], ['IP address', esc(a.ip.join(', '))], ['Gateway', esc(a.gw.join(', '))], ['DNS', esc(a.dns.join(', '))]])}</div>`).join('') || '<div class="empty">No adapters found.</div>'}</div>`}
   <h2 class="cat">Quick fixes</h2><div class="acts">
    <button class="btn" data-a="netfix" data-id="flushdns">Clear DNS cache</button><button class="btn" data-a="netfix" data-id="renew">Renew IP address</button>
    <button class="btn" data-a="netfix" data-id="winsock">Reset Winsock</button><button class="btn" data-a="netfix" data-id="ipreset">Reset TCP/IP</button></div>`;
}
function vRepair() {
  const W = D.wu;
  const rows = [['sfc', 'Check Windows system files (SFC)', 'Scans and repairs damaged Windows files. Takes 5 to 15 minutes.'],
    ['dism', 'Repair the Windows image (DISM)', 'Fixes the source SFC uses. Run it if SFC reports problems it cannot fix. Needs internet and can take a long time.'],
    ['chkdsk', 'Scan the system drive (read-only)', 'Looks for file system errors without changing anything.']];
  const open = [['windowsupdate', 'Windows Update'], ['devmgmt', 'Device Manager'], ['services', 'Services'], ['eventvwr', 'Event Viewer'], ['diskmgmt', 'Disk Management'], ['taskschd', 'Task Scheduler'], ['taskmgr', 'Task Manager'], ['msinfo', 'System Information'], ['network', 'Network Connections']];
  return `<h2 class="cat" style="margin-top:0">Repair</h2><div class="list tight">${rows.map(r => `<div class="row"><div class="info"><div class="name">${r[1]}</div><div class="path">${r[2]}</div></div><div class="acts"><button class="btn" data-a="repair" data-id="${r[0]}" data-name="${esc(r[1])}">Run</button></div></div>`).join('')}</div>
   <h2 class="cat">Windows Update status</h2>${!W || (!W.ready && W.loading) ? loadingBox('Asking Windows what is waiting… this can take a minute.') : `${errBox(W.error)}<div class="list tight">${W.items.map(u => `<div class="row"><div class="info"><div class="name">${esc(u.title)}</div><div class="path">${u.kb ? 'KB' + esc(u.kb) + ' · ' : ''}${fmtBytes(u.size)}${u.reboot ? ' · restart needed' : ''}</div></div></div>`).join('') || '<div class="empty"><b>Nothing is waiting.</b></div>'}</div>
   <div class="acts"><button class="btn" data-a="wu-scan">Ask Windows to check now</button><button class="btn" data-a="open-tool" data-id="windowsupdate">Open Windows Update</button></div>`}
   <h2 class="cat">Open a Windows tool</h2><div class="acts">${open.map(o => `<button class="btn" data-a="open-tool" data-id="${o[0]}">${o[1]}</button>`).join('')}</div>`;
}
const vReport = () => `<div class="card"><h3>PC health report</h3><div class="name">One page you can keep or send</div><div class="path" style="margin:6px 0 12px">System, drives and drive health, security checks, devices with problems, pending program updates, startup items and every installed program. It collects everything fresh, so it can take up to a minute.</div>
  <a class="btn primary" href="/api/tech/report" download>Create report</a></div>`;
const toolsTools = () => segCtl('tools', TOOLSEGS) + ({cleanup: toolsCleanup(), large: toolsFinder('large'), dups: toolsFinder('dups'),
  events: '<button class="btn" data-a="reload-events">Refresh</button>', network: '<button class="btn" data-a="reload-net">Refresh</button>',
  repair: '<button class="btn" data-a="reload-wu">Refresh</button>', remote: '<button class="btn" data-a="reload-remote">Refresh</button>', report: ''}[seg.tools]);

/* ---------- PROFILES ---------- */
const profCounts = p => [[p.tweaks.length, 'tweak'], [p.security.length, 'protection'], [p.install.length, 'program'], [p.startup_off.length, 'startup item'], [p.cleanup.length, 'cleanup']]
  .filter(x => x[0]).map(([n, w]) => `${n} ${w}${n > 1 ? 's' : ''}`).join(' · ') || 'Empty';
function vProfiles() {
  const P = D.profiles;
  if (P?.error && !P.items) return errBox(P.error);
  if (!P || !P.items) return loadingBox('Loading profiles…');
  return `<div class="banner info">A profile is a saved set-up. Applying one turns on its tweaks and protections, installs its programs, switches off its startup items and runs its cleanup, all in one go, after showing you exactly what will change.</div>
  <div class="list" style="margin-top:14px">${P.items.map(p => `<div class="row"><div class="info"><div class="name">${esc(p.name)} ${p.builtin ? '<span class="tag">Built in</span>' : ''}</div>
    <div class="path">${esc(p.desc || '')}</div><div class="path">${esc(profCounts(p))}</div></div>
    <div class="acts">${META.role === 'hub' ? `<button class="btn primary" data-a="prof-send" data-id="${esc(p.id)}">Send to devices…</button>` : `<button class="btn primary" data-a="prof-apply" data-id="${esc(p.id)}" data-name="${esc(p.name)}">Apply…</button>`}
     <button class="btn" data-a="prof-edit" data-id="${esc(p.id)}">${p.builtin ? 'Duplicate and edit' : 'Edit'}</button>
     <a class="btn" href="/api/profiles/export?id=${encodeURIComponent(p.id)}" download>Export</a>
     ${p.builtin ? '' : `<button class="btn danger" data-a="prof-del" data-id="${esc(p.id)}" data-name="${esc(p.name)}">Delete</button>`}</div></div>`).join('')}</div>`;
}
const toolsProfiles = () => `<button class="btn primary" data-a="prof-new">+ New profile</button>${META.role === 'hub' ? '' : '<button class="btn" data-a="prof-capture">Capture from this PC</button>'}
  <button class="btn" data-a="prof-import">Import…</button><input type="file" id="profFile" accept=".json,application/json" hidden>`;
function profileEditor(p0) {
  const O = D.profiles.options, m = $('#modal');
  const blank = {id: null, name: '', desc: '', tweaks: [], security: [], install: [], custom_winget: [], startup_off: [], cleanup: []};
  const p = Object.assign({}, blank, JSON.parse(JSON.stringify(p0 || {})));
  if (!p0 || p0.builtin) p.id = null;
  if (p0?.builtin) p.name = p0.name + ' (copy)';
  const SECS = [['tweaks', 'Tweaks', 'tweaks'], ['security', 'Security', 'security'], ['install', 'Programs', 'install'],
    ['startup_off', 'Startup', 'startup'], ['cleanup', 'Cleanup', 'tools']];
  const editable = a => ME.admin || ME.access?.[a] === 'change';
  const SECAREA = Object.fromEntries(SECS.map(s => [s[0], s[2]]));
  let cur = SECS.find(s => editable(s[2]))?.[0] || 'tweaks', q = '', adding = false, found = [], addMsg = '';
  const low = s => String(s).toLowerCase();
  const hit = s => !q || low(s).includes(low(q));
  const has = (k, v) => p[k].some(x => low(x) === low(v));
  const ck = (k, v, label, extra = '') => `<label class="ck"><input type="checkbox" data-pk="${k}" data-pv="${esc(v)}" ${has(k, v) ? 'checked' : ''}> <span>${label}</span>${extra}</label>`;
  const secId = id => p.security.find(s => s.id === id);
  const names = {}; O.install.forEach(c => c.items.forEach(i => names[i.id] = i.name)); p.custom_winget.forEach(w => names[w.id] = w.name);

  function items() {                      // [{key, v, label, extra}] for the current section, filtered
    if (cur === 'tweaks') return O.tweaks.filter(t => hit(t.name)).map(t => ({k: 'tweaks', v: t.id, label: esc(t.name) + (t.group === 'adv' ? ' <span class="tag bad">Advanced</span>' : '')}));
    if (cur === 'cleanup') return O.cleanup.filter(c => hit(c.name)).map(c => ({k: 'cleanup', v: c.id, label: esc(c.name)}));
    if (cur === 'startup_off') return [...new Set([...O.startup, ...p.startup_off])].sort((a, b) => low(a).localeCompare(low(b))).filter(hit).map(n => ({k: 'startup_off', v: n, label: esc(n)}));
    if (cur === 'security') return O.security.filter(s => hit(s.name)).map(s => ({k: 'security', v: s.id, label: esc(s.name) + (s.optional ? ' <span class="tag">Optional</span>' : ''),
      extra: s.audit ? `<select data-pm="${s.id}"><option value="on">On</option><option value="audit" ${secId(s.id)?.mode === 'audit' ? 'selected' : ''}>Audit only</option></select>` : ''}));
    return [];
  }
  const isOn = (k, v) => k === 'security' ? !!secId(v) : has(k, v);
  const setOn = (k, v, on) => {
    if (k === 'security') { p.security = p.security.filter(s => s.id !== v); if (on) p.security.push({id: v, mode: $(`[data-pm="${v}"]`, m)?.value || 'on'}); return; }
    p[k] = p[k].filter(x => low(x) !== low(v)); if (on) p[k].push(v);
  };
  const count = k => p[k].length;
  const navHtml = () => SECS.map(([k, label, a]) => `<button data-pn="${k}" class="${cur === k ? 'on' : ''}" ${editable(a) ? '' : 'title="Your account cannot change this part"'}><span>${label}${editable(a) ? '' : ' 🔒'}</span><b>${count(k) || ''}</b></button>`).join('');
  function paneHtml() {
    const a = SECAREA[cur];
    if (!editable(a)) return '<div class="empty">Your account can look at this part of the app but not change it, so it cannot be put in a profile you save.</div>';
    if (cur === 'install') {
      const mine = p.custom_winget.filter(w => hit(w.name + w.id));
      return `<div class="mini add" style="border:0;padding:0 0 8px">${adding ? `<input type="search" id="pfAddQ" placeholder="Program name, e.g. Krita"><button class="btn small primary" data-pf="addsearch">Search</button><button class="btn small" data-pf="addclose">Close</button>`
          : '<button class="btn small" data-pf="addopen">+ Find another program…</button>'}</div>
        ${adding ? `<div class="pfres">${addMsg ? `<div class="path">${esc(addMsg)}</div>` : ''}${found.map((r, i) => `<div class="mini"><div class="grow"><div class="name">${esc(r.name)}</div><div class="path">${esc(r.id)}</div></div><button class="btn small" data-pf="addpick:${i}" ${p.install.includes(r.id) ? 'disabled' : ''}>${p.install.includes(r.id) ? 'Added' : 'Add'}</button></div>`).join('')}</div>` : ''}
        ${mine.length ? `<details class="pfd" open><summary>Added by you</summary><div class="cols">${mine.map(w => `<span class="ck">${ck('install', w.id, esc(w.name))}<button class="btn small" data-pf="rmcustom:${esc(w.id)}" title="Remove from this profile">✕</button></span>`).join('')}</div></details>` : ''}
        ${O.install.map(c => { const its = c.items.filter(i => hit(i.name + c.name)); return its.length ? `<details class="pfd" ${q || its.some(i => p.install.includes(i.id)) ? 'open' : ''}><summary>${esc(c.name)} <span class="path">${its.filter(i => p.install.includes(i.id)).length || ''}</span></summary><div class="cols">${its.map(i => ck('install', i.id, esc(i.name))).join('')}</div></details>` : ''; }).join('')}`;
    }
    const its = items();
    const extra = cur === 'startup_off' ? `<div class="mini add" style="border:0;padding:0 0 8px"><input type="search" id="pfSu" placeholder="Add a startup item by name (for other PCs)"><button class="btn small" data-pf="addsu">Add</button></div>` : '';
    return extra + `<div class="cols">${its.map(i => `<label class="ck"><input type="checkbox" data-pk="${i.k}" data-pv="${esc(i.v)}" ${isOn(i.k, i.v) ? 'checked' : ''}> <span>${i.label}</span>${i.extra || ''}</label>`).join('') || '<span class="path">Nothing matches.</span>'}</div>`;
  }
  const UNIT = {tweaks: ['tweak', 'tweaks'], security: ['protection', 'protections'], install: ['program', 'programs'], startup_off: ['startup item', 'startup items'], cleanup: ['cleanup', 'cleanups']};
  const summary = () => SECS.map(([k]) => count(k) ? `${count(k)} ${UNIT[k][count(k) === 1 ? 0 : 1]}` : '').filter(Boolean).join(' · ') || 'Nothing chosen yet';
  const draw = () => { $('#pfNav').innerHTML = navHtml(); $('#pfList').innerHTML = paneHtml(); $('#pfSum').textContent = summary(); $('#pfBulk').hidden = cur === 'install' || !editable(SECAREA[cur]); };
  const startOpts = !p0 ? `<select id="pfFrom"><option value="">Start from a blank profile</option><option value="current">Start from this PC's current settings</option>${D.profiles.items.map(x => `<option value="${esc(x.id)}">Start from a copy of ${esc(x.name)}</option>`).join('')}</select>` : '';
  m.hidden = false;
  m.innerHTML = `<div class="dialog wide"><h2>${p0?.builtin ? 'Duplicate profile' : (p0 ? 'Edit profile' : 'New profile')}</h2>
   <div class="pfhead"><input type="search" id="pfName" placeholder="Profile name" value="${esc(p.name)}"><input type="search" id="pfDesc" placeholder="What it is for (optional)" value="${esc(p.desc || '')}">${startOpts}</div>
   <div class="pfgrid"><div class="pfnav" id="pfNav"></div><div><div class="mini add" style="border:0;padding:0 0 8px"><input type="search" id="pfQ" placeholder="Filter this list…"><span id="pfBulk"><button class="btn small" data-pf="all">Select all shown</button><button class="btn small" data-pf="none">Clear shown</button></span></div><div class="pflist" id="pfList"></div></div></div>
   <div class="pfsum"><span class="path">This profile will set up:</span> <b id="pfSum"></b></div>
   <div class="btns"><button class="btn" data-pf="cancel">Cancel</button><button class="btn primary" data-pf="save">Save profile</button></div></div>`;
  draw();
  const done = () => { m.hidden = true; m.innerHTML = ''; m.onclick = m.onchange = m.oninput = null; };
  const fromDraft = async src => {
    if (!src) { Object.assign(p, blank, {name: p.name, desc: p.desc}); return draw(); }
    try {
      const d = (await api('/api/profiles/draft', {from: src})).profile;
      Object.assign(p, blank, d, {id: null, name: $('#pfName').value || d.name, desc: $('#pfDesc').value || d.desc});
      p.custom_winget.forEach(w => names[w.id] = w.name); draw();
    } catch (e) { toast(e.message); }
  };
  m.oninput = e => { if (e.target.id === 'pfQ') { q = e.target.value; $('#pfList').innerHTML = paneHtml(); } };
  m.onchange = e => {
    const c = e.target;
    if (c.id === 'pfFrom') return fromDraft(c.value);
    if (c.dataset.pk) { setOn(c.dataset.pk, c.dataset.pv, c.checked); $('#pfNav').innerHTML = navHtml(); $('#pfSum').textContent = summary(); }
    if (c.dataset.pm) { const s = secId(c.dataset.pm); if (s) s.mode = c.value; }
  };
  m.onclick = async e => {
    const nv = e.target.closest('[data-pn]');
    if (nv) { cur = nv.dataset.pn; q = ''; $('#pfQ').value = ''; adding = false; return draw(); }
    const b = e.target.closest('[data-pf]');
    if (!b) { if (e.target === m) done(); return; }
    const [k, v] = b.dataset.pf.split(/:(.*)/s);
    if (k === 'cancel') return done();
    if (k === 'all' || k === 'none') { items().forEach(i => setOn(i.k, i.v, k === 'all')); return draw(); }
    if (k === 'addsu') { const n = $('#pfSu').value.trim(); if (n && !has('startup_off', n)) p.startup_off.push(n); return draw(); }
    if (k === 'addopen') { adding = true; addMsg = ''; found = []; $('#pfList').innerHTML = paneHtml(); $('#pfAddQ').focus(); return; }
    if (k === 'addclose') { adding = false; return draw(); }
    if (k === 'addsearch') {
      const s = $('#pfAddQ').value.trim(); addMsg = 'Searching…'; found = []; $('#pfList').innerHTML = paneHtml(); $('#pfAddQ').value = s;
      try { found = (await api('/api/install/search', {q: s})).items; addMsg = found.length ? '' : 'Nothing found. Try a shorter name.'; } catch (er) { addMsg = er.message; }
      $('#pfList').innerHTML = paneHtml(); $('#pfAddQ').value = s; return;
    }
    if (k === 'addpick') {
      const r = found[+v];
      if (!names[r.id]) p.custom_winget.push({id: r.id, name: r.name});
      names[r.id] = r.name; if (!p.install.includes(r.id)) p.install.push(r.id);
      const s = $('#pfAddQ').value; $('#pfList').innerHTML = paneHtml(); $('#pfAddQ').value = s; $('#pfNav').innerHTML = navHtml(); $('#pfSum').textContent = summary(); return;
    }
    if (k === 'rmcustom') { p.custom_winget = p.custom_winget.filter(w => w.id !== v); p.install = p.install.filter(x => x !== v); return draw(); }
    if (k === 'save') {
      const out = Object.assign({}, p, {name: $('#pfName').value, desc: $('#pfDesc').value, id: p.id || undefined});
      const j = await post('/api/profiles/save', {profile: out}, 'Profile saved');
      if (j) { done(); load('profiles', '/api/profiles'); }
    }
  };
}
async function applyProfile(id, name) {
  let pv;
  try { pv = await api('/api/profiles/preview', {id}); } catch (e) { return toast(e.message); }
  const x = pv.preview, sec = (t, a) => a.length ? `<b>${t}</b><ul>${a.map(i => `<li>${esc(i)}</li>`).join('')}</ul>` : '';
  const body = (sec('Tweaks to apply', x.tweaks) + sec('Protections to turn on', x.security) + sec('Programs to install', x.install) + sec('Startup items to switch off', x.startup_off) + sec('Cleanup to run', x.cleanup))
    || 'Nothing needs changing. This PC already matches the profile.';
  const r = await dialog({title: `Apply “${name}”?`, body: body + (x.already ? `<div class="path" style="margin-top:6px">${x.already} item${x.already > 1 ? 's are' : ' is'} already set.</div>` : ''),
    checks: [{id: 'rp', label: 'Create a restore point first (recommended)', checked: true}], ok: 'Apply profile'});
  if (!r) return;
  const j = await post('/api/profiles/apply', {id, confirm: true, restore_point: r.rp});
  if (j) { openTasks(); pollJobs(); }
}

/* ---------- HUB (managing other PCs) ---------- */
F.hub = {port: '8766', name: ''};
const HSEL = new Set();
let hubTimer = null, hubDev = null, hubDevTimer = null;
const ago = t => { if (!t) return 'never'; const s = Math.max(0, Math.round(Date.now() / 1000 - t)); return s < 10 ? 'just now' : s < 90 ? s + ' s ago' : s < 5400 ? Math.round(s / 60) + ' min ago' : s < 129600 ? Math.round(s / 3600) + ' h ago' : Math.round(s / 86400) + ' days ago'; };
const ordTag = s => `<span class="tag ${({done: 'ok', error: 'bad', refused: 'bad', lost: 'bad', running: 'warn', sent: 'warn', queued: '', expired: '', cancelled: ''})[s] || ''}">${esc(({done: 'Done', error: 'Failed', refused: 'Refused by the PC', lost: 'Lost', running: 'Running', sent: 'Sent', queued: 'Waiting', expired: 'Expired', cancelled: 'Cancelled'})[s] || s)}</span>`;
function vHub() {
  const H = D.hub;
  if (H?.error && !H.devices) return errBox(H.error);
  if (!H || !H.devices) return loadingBox('Loading…');
  if (!H.enabled) return `<div class="card"><h3>Manage other PCs from here</h3>
    <div class="path" style="margin:6px 0 12px">Turn this PC into a <b>hub</b>. Other PCs running App Manager enroll with a one-time code, then check in with this PC every few seconds. From here you can see how each one is doing, apply a profile, install or update programs, and run repairs and cleanup on them.<br><br>
    Managed PCs call this PC, so they need no open ports. Messages are signed so they cannot be forged or replayed, but they are <b>not encrypted</b>: use a network you trust, or a VPN. On Windows a firewall rule is added for private and domain networks only.</div>
    <div class="mini add" style="border:0;padding:0"><input type="search" data-f="hub.name" placeholder="Hub name (shown on managed PCs)" value="${esc(F.hub.name)}"><input type="search" data-f="hub.port" style="max-width:110px;flex:none" placeholder="Port" value="${esc(F.hub.port)}"></div>
    <div class="acts" style="margin-top:10px"><button class="btn primary" data-a="hub-on">Turn on hub</button></div></div>`;
  const n = HSEL.size;
  return `<div class="card" style="margin-bottom:14px"><div class="row" style="border:0;padding:0"><div class="info"><div class="name">Hub “${esc(H.name)}” <span class="tag ${H.running ? 'ok' : 'bad'}">${H.running ? 'Listening on port ' + H.port : 'Not listening'}</span></div>
     <div class="path">${H.error ? esc(H.error) + ' · ' : ''}Managed PCs reach this PC at ${H.addresses.slice(0, 3).map(a => esc(a + ':' + H.port)).join(' or ')}</div></div>
     <div class="acts"><button class="btn primary" data-a="hub-add">+ Add a device</button><button class="btn" data-a="hub-off">Turn off</button></div></div>
     ${H.tokens.length ? `<div style="margin-top:10px">${H.tokens.map(t => `<div class="mini"><div class="grow"><span class="name">Waiting for a device to use a code</span> <span class="path">expires ${new Date(t.expires * 1000).toLocaleString()}</span></div><button class="btn small" data-a="hub-tok-del" data-id="${t.id}">Cancel code</button></div>`).join('')}</div>` : ''}</div>
   ${n ? `<div class="banner info" style="margin:0 0 10px;display:flex;align-items:center;gap:10px"><span class="grow">${n} device${n > 1 ? 's' : ''} selected</span><button class="btn primary small" data-a="hub-order-sel">Send an order…</button><button class="btn small" data-a="hub-sel-clear">Clear</button></div>` : ''}
   <div class="list">${H.devices.map(d => `<div class="row"><label class="check"><input type="checkbox" data-a="hub-sel" data-id="${d.id}" ${HSEL.has(d.id) ? 'checked' : ''}></label>
     <div class="info"><div class="name"><span class="sdot ${d.online ? 'ok' : 'bad'}" title="${d.online ? 'Online' : 'Not heard from recently'}"></span> ${esc(d.name)} ${d.admin ? '' : '<span class="tag warn">Not administrator</span>'}
       ${d.last_code ? `<span class="tag bad" title="Reported by the PC in the last hour">${esc(d.last_code)}</span>` : ''}
       ${d.busy ? `<span class="tag warn">${d.busy} order${d.busy > 1 ? 's' : ''}</span>` : ''}</div>
      <div class="path">${esc(d.ip)} · ${esc(d.os)} · App Manager ${esc(d.version)} · seen ${ago(d.last_seen)}</div>
      <div class="path">${d.status_t ? `${d.programs ?? '?'} programs · ${d.updates} update${d.updates === 1 ? '' : 's'} waiting · ` + (d.sec_bad ? `<b style="color:var(--bad)">${d.sec_bad} security issue${d.sec_bad > 1 ? 's' : ''}</b>` : 'security OK') + ` · ` + (d.problems ? `<b style="color:var(--bad)">${d.problems} device problem${d.problems > 1 ? 's' : ''}</b>` : 'no device problems') : 'Waiting for its first report…'}</div></div>
     <div class="acts"><button class="btn" data-a="hub-open" data-id="${d.id}">Open</button></div></div>`).join('') || '<div class="empty"><b>No devices yet.</b><br>Press “Add a device”, then paste the code into App Manager on the other PC.</div>'}</div>`;
}
const toolsHub = () => '<button class="btn" data-a="err-lookup">Look up error code</button>';
function hubPoll() { clearInterval(hubTimer); const go = () => { if (tab === 'hub' && !document.hidden && !document.activeElement?.matches('input')) load('hub', '/api/hub'); }; hubTimer = setInterval(go, 5000); }
function devStatusHtml(st) {
  if (!st) return '<div class="path">No report yet. The PC sends one soon after it checks in.</div>';
  const s = st.hardware?.system || {}, ram = st.hardware?.ram?.total;
  const secTag = x => `<span class="tag ${x === 'ok' ? 'ok' : (x === 'bad' ? 'bad' : (x === 'partial' ? 'warn' : ''))}">${esc(x)}</span>`;
  return `${kvl([['PC', esc([s.manufacturer, s.model].filter(Boolean).join(' '))], ['Windows', esc(s.os || st.os || '')], ['Build', esc(s.build || '')], ['Memory', ram ? fmtBytes(ram) : ''], ['Up for', st.uptime != null ? fmtDur(st.uptime) : ''], ['Report', ago(st.t)]])}
   ${(st.hardware?.volumes || []).length ? `<h3 class="pfh">Drives</h3>${st.hardware.volumes.map(v => `<div class="path">${esc(v.drive)} ${esc(v.label || '')} · ${fmtBytes(v.free)} free of ${fmtBytes(v.size)}</div>`).join('')}` : ''}
   ${st.security ? `<h3 class="pfh">Security</h3><div class="cols">${st.security.map(i => `<div class="path">${secTag(i.status)} ${esc(i.name)}</div>`).join('')}</div>` : ''}
   ${(st.problems || []).length ? `<h3 class="pfh">Devices with problems</h3>${st.problems.map(d => `<div class="path"><span class="tag bad">!</span> ${esc(d.name)}: ${esc(d.problem)}</div>`).join('')}` : ''}
   ${(st.updates || []).length ? `<h3 class="pfh">Updates waiting (${st.updates.length})</h3>${st.updates.slice(0, 12).map(u => `<div class="path">${esc(u.name)} ${esc(u.current)} → ${esc(u.available)}</div>`).join('')}${st.updates.length > 12 ? `<div class="path">…and ${st.updates.length - 12} more</div>` : ''}` : ''}
   ${(st.health?.disks || []).length ? `<h3 class="pfh">Drive health</h3>${st.health.disks.map(d => `<div class="path">${esc(d.name)}: ${esc(d.health || '')}${(d.notes || []).length ? ' · ' + esc(d.notes.join('; ')) : ''}</div>`).join('')}` : ''}
   ${st.programs ? `<details class="pfd" style="margin-top:10px"><summary>${st.programs.count} installed programs</summary><div class="cols">${st.programs.items.map(p => `<div class="path">${esc(p.n)} ${esc(p.v)}</div>`).join('')}</div></details>` : ''}`;
}
const fmtDur = s => { const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return (d ? d + ' d ' : '') + (h || d ? h + ' h ' : '') + m + ' min'; };
async function hubOpen(id) {
  hubDev = id; const m = $('#modal'); m.hidden = false;
  const draw = async () => {
    let r; try { r = await api('/api/hub/device?id=' + id); } catch (e) { toast(e.message); return close(); }
    const s = r.summary;
    let mine = []; try { mine = (await api('/api/remote')).items; } catch (e) {}
    const have = Object.fromEntries(mine.map(t => [t.id, t.installed]));
    m.innerHTML = `<div class="dialog wide"><h2><span class="sdot ${s.online ? 'ok' : 'bad'}"></span> ${esc(s.name)}</h2>
     <div class="path">${esc(s.ip)} · ${esc(s.os)} · App Manager ${esc(s.version)} · seen ${ago(s.last_seen)}${s.admin ? '' : ' · <b>not running as administrator</b>'}</div>
     <div class="path">The PC allows orders for: ${Object.entries(s.policy).filter(([, v]) => v).map(([k]) => k).join(', ') || 'status only'}</div>
     <div class="acts" style="margin:10px 0"><button class="btn primary" data-hx="order">Send an order…</button><button class="btn" data-hx="refresh">Refresh status</button><button class="btn danger" data-hx="remove">Remove from hub</button></div>
     ${(r.errors || []).length ? `<h3 class="pfh">Problems this PC reported</h3>${r.errors.map(e => `<div class="mini" style="align-items:flex-start"><span class="tag bad">${esc(e.code)}</span><div class="grow"><div class="name">${esc(e.title || '')}</div><div class="path">${new Date(e.t * 1000).toLocaleString()}${e.d ? ' · ' + esc(e.d) : ''}</div><div class="path">${esc(e.cause || '')}</div><div class="path"><b>Fix:</b> ${esc(e.fix || '')}</div></div></div>`).join('')}` : ''}
     <h3 class="pfh">Remote desktop</h3><div class="path">Opens the viewer on <b>this</b> PC and connects to ${esc(s.name)}. Passwords are passed to the viewer and never saved.</div>
     ${r.remote.map(t => `<div class="mini" style="align-items:center"><div class="grow"><div class="name">${esc(t.name)} ${t.installed ? '' : '<span class="tag">Not on that PC</span>'}</div>
       <div class="path">${t.id ? 'ID: <b>' + esc(t.id) + '</b>' + (t.typed ? ' (typed in)' : '') : 'No ID known'}</div></div>
       <button class="btn small" data-hx="rid:${t.tool}">Type ID</button>
       ${have[t.tool] ? `<button class="btn small primary" data-hx="rconn:${t.tool}">Connect</button>` : `<span class="path">Not installed on this PC</span>`}</div>`).join('')}
     ${devStatusHtml(r.status)}
     <h3 class="pfh">Orders</h3>${r.commands.map(c => `<div class="mini" style="align-items:flex-start"><div class="grow"><div class="name">${esc(c.summary)} ${ordTag(c.state)}</div>
       <div class="path">${new Date(c.created * 1000).toLocaleString()}${c.by ? ' · by ' + esc(c.by) : ''}${c.progress && c.state === 'running' ? ' · ' + esc(c.progress) : ''}</div>
       ${c.result ? `<div class="path">${esc(c.result)}</div>` : ''}${(c.log || []).length ? `<details><summary class="path">Log</summary><pre class="logbox">${esc(c.log.join('\n'))}</pre></details>` : ''}</div>
       ${c.state === 'queued' ? `<button class="btn small" data-hx="cancel:${c.id}">Cancel</button>` : ''}</div>`).join('') || '<div class="path">No orders yet.</div>'}
     <div class="btns"><button class="btn" data-hx="close">Close</button></div></div>`;
  };
  const close = () => { clearInterval(hubDevTimer); hubDev = null; m.hidden = true; m.innerHTML = ''; m.onclick = null; load('hub', '/api/hub'); };
  m.onclick = async e => {
    const b = e.target.closest('[data-hx]');
    if (!b) { if (e.target === m) close(); return; }
    const [k, v] = b.dataset.hx.split(':');
    if (k === 'close') return close();
    if (k === 'order') { clearInterval(hubDevTimer); const keep = m.innerHTML; await hubOrder([id]); if (hubDev === id) { m.hidden = false; hubOpen(id); } return; }
    if (k === 'refresh') { await post('/api/hub/command', {devices: [id], type: 'refresh_status', confirm: true}, 'Asked the PC for a fresh report'); return draw(); }
    if (k === 'rid') { clearInterval(hubDevTimer); const cur = (await api('/api/hub/device?id=' + id)).remote.find(t => t.tool === v); const x = await askText(`${cur.name} ID (blank = use what the PC reports)`, 'ID', cur.typed); if (x !== null) await post('/api/hub/remote/id', {device: id, tool: v, id: x}, 'Saved'); return hubOpen(id); }
    if (k === 'rconn') {
      clearInterval(hubDevTimer);
      const t = (await api('/api/hub/device?id=' + id)).remote.find(x => x.tool === v);
      const pw = t.connect === 'cli' ? await askText(`Connect with ${t.name}. Password (leave blank to type it in the viewer)`, 'Password', '', 'password') : (await dialog({title: `Connect with ${t.name}?`, body: 'The viewer opens on this PC.', ok: 'Open'}) ? '' : null);
      if (pw !== null) { const j = await post('/api/hub/remote', {device: id, tool: v, password: pw}, null); if (j) toast(j.note || `${j.tool} opened`); }
      return hubOpen(id);
    }
    if (k === 'cancel') { await post('/api/hub/command/cancel', {device: id, id: v}); return draw(); }
    if (k === 'remove') {
      const s = {name: m.querySelector('h2').textContent.trim()};
      clearInterval(hubDevTimer);
      const yes = await dialog({title: `Remove ${s.name}?`, body: 'It stops being managed and must enroll again with a new code.', ok: 'Remove', danger: true});
      if (!yes) return hubOpen(id);
      hubDev = null;
      if (await post('/api/hub/device/remove', {id, confirm: true}, 'Removed')) load('hub', '/api/hub'); else hubOpen(id);
      return;
    }
  };
  await draw();
  hubDevTimer = setInterval(() => { if (hubDev === id && !m.hidden && !m.querySelector('details[open]')) draw(); }, 3000);
}
async function hubOrder(ids, pre) {
  let O, DEV = null; try { O = D.hubopts = await api('/api/hub/options'); } catch (e) { return toast(e.message); }
  if (!ids.length) { try { DEV = (await api('/api/hub')).devices || []; } catch (e) { return toast(e.message); } if (!DEV.length) return toast('No devices are enrolled yet. Add one on the Devices tab first.'); }
  const picked = new Set();
  const m = $('#modal'); m.hidden = false;
  const o = {type: (pre && pre.type) || 'apply_profile', profile_id: (pre && pre.profile_id) || O.profiles[0]?.id, restore: true, ids: new Set(), custom: '', all: true, upd: '', what: O.repairs[0]?.id, clean: new Set()};
  const one = ids.length === 1 ? D.hub.devices.find(d => d.id === ids[0]) : null;
  return new Promise(res => {
    const params = () => ({
      apply_profile: {profile_id: o.profile_id, restore_point: o.restore},
      install: {ids: [...o.ids, ...o.custom.split(/[\s,;]+/).filter(Boolean)]},
      update: o.all ? {all: true} : {ids: o.upd.split(/[\s,;]+/).filter(Boolean)},
      repair: {what: o.what}, cleanup: {ids: [...o.clean]}, fix_devices: {}, restore_point: {}, refresh_status: {}}[o.type]);
    const pane = () => ({
      apply_profile: `<select id="hoProf" style="width:100%">${O.profiles.map(p => `<option value="${esc(p.id)}" ${p.id === o.profile_id ? 'selected' : ''}>${esc(p.name)} (${Object.entries(p.counts).filter(([, n]) => n).map(([k, n]) => n + ' ' + k.replace('_off', '')).join(', ') || 'empty'})</option>`).join('')}</select>
        <label class="ck" style="margin-top:8px"><input type="checkbox" id="hoRp" ${o.restore ? 'checked' : ''}> <span>Create a restore point on the PC first</span></label>`,
      install: `${O.install.map(c => `<details class="pfd"><summary>${esc(c.name)}</summary><div class="cols">${c.items.map(i => `<label class="ck"><input type="checkbox" data-hi="${esc(i.id)}" ${o.ids.has(i.id) ? 'checked' : ''}> <span>${esc(i.name)}</span></label>`).join('')}</div></details>`).join('')}
        <input type="search" id="hoCustom" style="width:100%;margin-top:6px" placeholder="Other winget IDs, separated by spaces (e.g. KDE.Krita)" value="${esc(o.custom)}">`,
      update: `<label class="ck"><input type="radio" name="hoU" value="all" ${o.all ? 'checked' : ''}> <span>Update every program that has an update</span></label>
        <label class="ck"><input type="radio" name="hoU" value="some" ${o.all ? '' : 'checked'}> <span>Only these:</span></label>
        <input type="search" id="hoUpd" style="width:100%;margin-top:4px" placeholder="winget IDs separated by spaces" value="${esc(o.upd)}">`,
      repair: `<select id="hoRep" style="width:100%">${O.repairs.map(r => `<option value="${r.id}" ${r.id === o.what ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}</select><div class="path" style="margin-top:6px">SFC and DISM can take a long time. The PC stays usable.</div>`,
      cleanup: `<div class="cols">${O.cleanup.map(c => `<label class="ck"><input type="checkbox" data-hc="${c.id}" ${o.clean.has(c.id) ? 'checked' : ''}> <span>${esc(c.name)}</span></label>`).join('')}</div>`,
      fix_devices: '<div class="path">The PC tries the safe fixes on every device Windows reports a problem with: turn it on, restart it, rescan.</div>',
      restore_point: '<div class="path">Windows saves a restore point on the PC. It may refuse if it made one in the last 24 hours.</div>',
      refresh_status: '<div class="path">Asks the PC to send a fresh report on its next check-in.</div>'}[o.type]);
    const draw = () => {
      m.innerHTML = `<div class="dialog wide"><h2>Send an order to ${DEV ? 'devices' : ids.length > 1 ? ids.length + ' devices' : esc(one?.name || 'a device')}</h2>
       ${DEV ? `<div class="cols" style="margin-bottom:10px">${DEV.map(d => `<label class="ck"><input type="checkbox" data-hd="${esc(d.id)}" ${picked.has(d.id) ? 'checked' : ''}> <span>${esc(d.name)}</span></label>`).join('')}</div>` : ''}
       <select id="hoType" style="width:100%;margin-bottom:10px">${Object.entries(O.types).map(([k, v]) => `<option value="${k}" ${k === o.type ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select>
       <div id="hoPane">${pane()}</div>
       <div class="path" style="margin-top:10px">Each PC checks the order again and may refuse it if its owner has not allowed that kind of order.</div>
       <div class="btns"><button class="btn" data-ho="cancel">Cancel</button><button class="btn primary" data-ho="send">Send order</button></div></div>`;
    };
    draw();
    const close = v => { m.hidden = true; m.innerHTML = ''; m.onclick = m.onchange = m.oninput = null; res(v); };
    m.onchange = e => {
      const c = e.target;
      if (c.id === 'hoType') { o.type = c.value; return draw(); }
      if (c.id === 'hoProf') o.profile_id = c.value;
      if (c.id === 'hoRp') o.restore = c.checked;
      if (c.id === 'hoRep') o.what = c.value;
      if (c.dataset.hd) c.checked ? picked.add(c.dataset.hd) : picked.delete(c.dataset.hd);
      if (c.dataset.hi) c.checked ? o.ids.add(c.dataset.hi) : o.ids.delete(c.dataset.hi);
      if (c.dataset.hc) c.checked ? o.clean.add(c.dataset.hc) : o.clean.delete(c.dataset.hc);
      if (c.name === 'hoU') o.all = c.value === 'all';
    };
    m.oninput = e => { if (e.target.id === 'hoCustom') o.custom = e.target.value; if (e.target.id === 'hoUpd') { o.upd = e.target.value; o.all = false; } };
    m.onclick = async e => {
      const b = e.target.closest('[data-ho]');
      if (!b) { if (e.target === m) close(null); return; }
      if (b.dataset.ho === 'cancel') return close(null);
      const targets = DEV ? [...picked] : ids;
      if (!targets.length) return toast('Tick at least one device.');
      const j = await post('/api/hub/command', {devices: targets, type: o.type, params: params(), confirm: true}, null);
      if (j) { toast(`Order sent to ${j.queued} device${j.queued > 1 ? 's' : ''}. It runs at the next check-in.`); close(j); load('hub', '/api/hub'); }
    };
  });
}
async function hubAddDialog() {
  const H = D.hub, m = $('#modal'); m.hidden = false;
  let code = '';
  const draw = () => {
    m.innerHTML = `<div class="dialog"><h2>Add a device</h2>
     ${code ? `<div class="path" style="margin-bottom:8px">On the other PC open App Manager (version 0.8 or newer) → <b>Settings</b> → <b>Managed by a hub</b>, paste this code and press Connect. The code works once.</div>
       <textarea id="hoCode" readonly rows="4" style="width:100%;font:12px monospace;padding:8px;border:1px solid var(--line);border-radius:8px;background:var(--bg);color:var(--ink)">${esc(code)}</textarea>
       <div class="btns"><button class="btn" data-hd="copy">Copy</button><button class="btn primary" data-hd="close">Done</button></div>`
      : `<div class="path" style="margin-bottom:8px">Choose the address the other PC will use to reach this one. The first is usually right; if a PC cannot connect, make a new code with the next one.</div>
       <select id="hdHost" style="width:100%;margin-bottom:8px">${H.addresses.map(a => `<option>${esc(a)}</option>`).join('')}</select>
       <div class="path" style="margin-bottom:4px">The code stays valid for</div>
       <select id="hdHours" style="width:100%"><option value="1">1 hour</option><option value="24" selected>1 day</option><option value="168">7 days</option></select>
       <div class="btns"><button class="btn" data-hd="close">Cancel</button><button class="btn primary" data-hd="make">Create code</button></div>`}</div>`;
  };
  draw();
  const close = () => { m.hidden = true; m.innerHTML = ''; m.onclick = null; load('hub', '/api/hub'); };
  m.onclick = async e => {
    const b = e.target.closest('[data-hd]');
    if (!b) { if (e.target === m) close(); return; }
    if (b.dataset.hd === 'close') return close();
    if (b.dataset.hd === 'copy') { $('#hoCode').select(); try { await navigator.clipboard.writeText(code); toast('Copied'); } catch (er) { document.execCommand('copy'); toast('Copied'); } return; }
    const j = await post('/api/hub/token', {host: $('#hdHost').value, hours: +$('#hdHours').value});
    if (j) { code = j.code; draw(); }
  };
}
function vAgent() {
  const A = D.agent;
  if (!A) return loadingBox('Loading…');
  if (!A.enrolled) return `<div class="card"><div class="path" style="margin-bottom:8px">Let another PC running App Manager (a <b>hub</b>) see how this PC is doing and send it orders such as installing programs or running repairs. This PC calls the hub, so nothing here is opened to the network. You choose which kinds of order it may accept.</div>
    <div class="mini add" style="border:0;padding:0"><input type="search" id="agName" placeholder="Name for this PC" value="${esc(A.default_name)}"></div>
    <div class="mini add" style="border:0"><input type="search" id="agCode" placeholder="Paste the enrollment code from the hub"></div>
    <div class="acts"><button class="btn primary" data-a="ag-enroll">Connect to the hub</button><button class="btn" data-a="ag-test">Test connection</button></div></div>`;
  const pol = [['profiles', 'Apply profiles'], ['install', 'Install and update programs'], ['repair', 'Run repairs, fix devices, make restore points'], ['cleanup', 'Clean up disk space']];
  return `<div class="card"><div class="name">Managed by “${esc(A.hub_name || A.hub)}” <span class="tag ${A.error ? 'bad' : (A.last_ok ? 'ok' : 'warn')}">${A.error ? 'Problem' : (A.last_ok ? 'Connected' : 'Connecting…')}</span></div>
    <div class="path">${esc(A.hub)} · named “${esc(A.name)}” · last check-in ${ago(A.last_ok)}${A.error ? '<br><b style="color:var(--bad)">' + (A.error_code ? '<span class="tag bad">' + esc(A.error_code) + '</span> ' : '') + esc(A.error) + '</b>' : ''}</div>
    ${A.error_code && A.errors?.length ? `<div class="path" style="margin-top:6px"><b>What to do:</b> ${esc(A.errors[0].fix || '')}<br>Give this code to your technician: <b>${esc(A.error_code)}</b>. It also reaches the hub by itself as soon as a connection works.</div>` : ''}
    ${A.errors?.length > 1 ? `<details class="pfd"><summary>Recent problems (${A.errors.length})</summary>${A.errors.map(e => `<div class="path"><span class="tag">${esc(e.code)}</span> ${esc(e.title || '')} · ${new Date(e.t * 1000).toLocaleString()}</div>`).join('')}</details>` : ''}
    ${A.running.length ? `<div style="margin-top:8px">${A.running.map(r => `<div class="path"><span class="spin"></span> ${esc(r.title)}: ${esc(r.line)}</div>`).join('')}</div>` : ''}
    <h3 class="pfh">The hub may</h3><div class="path">Always: read this PC's status.</div>
    ${pol.map(([k, l]) => `<label class="ck" style="margin-top:4px"><input type="checkbox" data-a="ag-pol" data-k="${k}" ${A.policy[k] ? 'checked' : ''}> <span>${l}</span></label>`).join('')}
    <div class="acts" style="margin-top:12px"><button class="btn danger" data-a="ag-leave">Stop being managed</button></div></div>`;
}

/* ---------- BACKUP ---------- */
F.backup = {folder: '', target: '', inc: [], unc: ''};
function vBackup() {
  const B = D.backup;
  if (B?.error && !B.restore) return errBox(B.error);
  if (!B || !B.restore) return loadingBox('Loading…');
  const ch = B.changes, n = ch.tweaks.length + ch.security.length;
  const rp = B.restore;
  return `<div class="grid2">
   <div class="card"><h3>Restore points</h3><div class="path" style="margin-bottom:8px">Windows can roll the whole system back to one of these.</div>
    ${rp.loading && !rp.ready ? loadingBox('Asking Windows…') : errBox(rp.error)}${rp.items.map(r => `<div class="mini"><div class="grow"><div class="name">${esc(r.desc)}</div><div class="path">${esc(r.t)}</div></div></div>`).join('') || (rp.ready ? '<div class="path">No restore points found. System Protection may be off.</div>' : '')}
    <div class="acts" style="margin-top:12px"><button class="btn primary" data-a="bk-rp">Create restore point</button><button class="btn" data-a="bk-sysrestore">Open System Restore</button></div></div>
   <div class="card"><h3>Undo everything App Manager changed</h3><div class="path" style="margin-bottom:8px">Puts every tweak and security setting that App Manager changed back to what it was.</div>
    ${n ? `<ul class="plain">${ch.tweaks.map(t => `<li>${esc(t.name)} <span class="path">${esc(t.when)}</span></li>`).join('')}${ch.security.map(t => `<li>${esc(t.name)} <span class="path">${esc(t.when)}</span></li>`).join('')}</ul>` : '<div class="path">Nothing has been changed yet.</div>'}
    <div class="acts" style="margin-top:12px"><button class="btn dangerfill" data-a="bk-undoall" ${n ? '' : 'disabled'}>Undo all ${n || ''}</button></div></div>
   <div class="card"><h3>App Manager settings</h3><div class="path" style="margin-bottom:8px">Your profiles, install list, favorites, My apps list and look settings, in one file. Use it to move to a new PC.</div>
    <div class="acts"><a class="btn primary" href="/api/backup/export" download>Export settings</a><button class="btn" data-a="bk-import">Import settings…</button><input type="file" id="bkFile" accept=".zip" hidden></div></div>
   <div class="card"><h3>Driver backup</h3><div class="path" style="margin-bottom:8px">Saves the drivers that came with this PC's hardware, so they can be reinstalled without internet.</div>
    <div class="mini add" style="border:0;padding:0"><input type="search" data-f="backup.folder" placeholder="${esc(B.driver_dir)}" value="${esc(F.backup.folder)}"></div>
    <div class="acts" style="margin-top:8px"><button class="btn primary" data-a="bk-drivers">Back up drivers</button></div></div>
   ${imageCard(B)}</div>`;
}
function imageCard(B) {
  const I = B.image, f = F.backup;
  if (I.loading) return `<div class="card wide2"><h3>Full system image</h3>${loadingBox('Looking at your drives…')}</div>`;
  const vols = I.volumes, sys = vols.find(v => v.system), others = vols.filter(v => !v.system);
  const GB = n => (n / 2 ** 30 >= 100 ? Math.round(n / 2 ** 30) : (n / 2 ** 30).toFixed(1)) + ' GB';
  const copyable = others.filter(v => v.type === 'Fixed');
  const used = v => v.size - v.free;
  const need = (sys ? used(sys) : 0) + copyable.filter(v => f.inc.includes(v.letter)).reduce((a, v) => a + used(v), 0);
  const tgt = vols.find(v => v.letter === f.target);
  const unc = f.target === '__unc';
  const ready = I.wbadmin && I.admin && !I.running && (unc ? f.unc.trim().length > 4 : (tgt && !(tgt.letter === sys?.letter) && tgt.free >= need && tgt.fs === 'NTFS'));
  const why = !I.wbadmin ? 'This edition of Windows does not include the wbadmin tool.' : !I.admin ? 'A system image needs administrator permission. Close App Manager and open it again, choosing Yes.'
    : (tgt && tgt.fs !== 'NTFS') ? `Drive ${tgt.letter}: is ${tgt.fs}; Windows needs NTFS.` : (tgt && tgt.free < need) ? `Drive ${tgt.letter}: has only ${GB(tgt.free)} free.` : '';
  const cand = others.filter(v => !f.inc.includes(v.letter));
  return `<div class="card wide2"><h3>Full system image</h3>
   <div class="path" style="margin-bottom:10px">A complete copy of Windows, your programs, settings and files, made with Windows' own backup tool. If the PC will not start or the drive dies, you can bring everything back exactly as it was by starting from Windows setup media.</div>
   ${errBox(I.error)}
   <b>1. What to copy</b>
   <div class="mini"><div class="grow"><div class="name">${sys ? esc(sys.letter + ': ' + (sys.label || 'Windows')) : 'Windows drive'} <span class="tag ok">Always included</span></div><div class="path">${sys ? GB(used(sys)) + ' used' : ''}</div></div></div>
   ${copyable.map(v => `<label class="mini ck"><input type="checkbox" data-a="img-inc" data-v="${v.letter}" ${f.inc.includes(v.letter) ? 'checked' : ''}><span class="grow"><span class="name">${esc(v.letter + ': ' + (v.label || 'Drive'))}</span> <span class="path">${GB(used(v))} used</span></span></label>`).join('') || '<div class="path">No other internal drives.</div>'}
   <div class="path" style="margin:6px 0 12px">About <b>${GB(need)}</b> will be saved (a little less once Windows compresses it).</div>
   <b>2. Where to save it</b>
   ${others.filter(v => !f.inc.includes(v.letter)).map(v => {
     const same = sys && v.disk != null && v.disk === sys.disk;
     return `<label class="mini ck"><input type="radio" name="imgt" data-a="img-target" data-v="${v.letter}" ${f.target === v.letter ? 'checked' : ''}><span class="grow"><span class="name">${esc(v.letter + ': ' + (v.label || 'Drive'))}</span> <span class="path">${esc(v.type)} · ${esc(v.fs || '?')} · ${GB(v.free)} free of ${GB(v.size)}</span>
       ${v.free < need ? '<span class="tag bad">Not enough space</span>' : ''}${v.fs && v.fs !== 'NTFS' ? '<span class="tag bad">Not NTFS</span>' : ''}${same ? '<span class="tag warn">Same physical disk as Windows</span>' : ''}
       ${(v.images || []).length ? `<div class="path">Existing images: ${v.images.map(i => esc(i.pc + ' · ' + i.t)).join(', ')}</div>` : ''}</span></label>`; }).join('')}
   <label class="mini ck"><input type="radio" name="imgt" data-a="img-target" data-v="__unc" ${unc ? 'checked' : ''}><span class="grow"><span class="name">A network folder</span> <span class="path">uses the Windows account you are signed in with</span></span></label>
   ${unc ? `<div class="mini add" style="border:0"><input type="search" data-f="backup.unc" placeholder="\\\\server\\share" value="${esc(f.unc)}"></div>` : ''}
   ${cand.length ? '' : ''}${others.some(v => sys && v.disk === sys.disk && f.target === v.letter) ? '<div class="banner" style="margin-top:6px">That drive is on the same physical disk as Windows, so it will not protect you if that disk fails. Use an external or second drive when you can.</div>' : ''}
   <div class="acts" style="margin-top:12px">${I.running ? '<button class="btn dangerfill" data-a="img-stop">Stop the image</button><span class="path">An image is being made now. Open Tasks to watch.</span>'
     : `<button class="btn primary" data-a="img-start" ${ready ? '' : 'disabled'}>Create system image</button><button class="btn" data-a="reload-backup">Refresh drives</button>`}</div>
   ${why && !I.running ? `<div class="path" style="margin-top:6px;color:var(--bad)">${esc(why)}</div>` : ''}
   <details class="pfd" style="margin-top:12px"><summary>How to restore an image</summary><div class="path" style="margin-top:6px">
     1. Plug in the drive that holds the image.<br>2. Start the PC from a Windows setup USB (press the boot menu key at power-on; often F12, F8 or Esc).<br>
     3. Choose your language, then <b>Repair your computer</b> → <b>Troubleshoot</b> → <b>System Image Recovery</b>.<br>4. Pick the newest image and follow the steps. Everything on the drives being restored is replaced.</div></details></div>`;
}
const toolsBackup = () => '<button class="btn" data-a="reload-backup">Refresh</button>';

/* ---------- SETTINGS (look and customization) ---------- */
let UIS = {theme: 'auto', mode: 'technician', order: [], hidden: [], simple_hidden: []};
const TABLABEL = Object.fromEntries(TABS);
function applyRole() {
  if (META.role === 'client') { TABS.splice(0, TABS.length, ['remote', 'Remote support'], ['link', 'Hub link']); TABLABEL.remote = 'Remote support'; TABLABEL.link = 'Hub link'; }
  else if (META.role === 'hub') { TABS.splice(0, TABS.length, ['hub', 'Devices'], ['profiles', 'Profiles'], ['activity', 'Activity'], ['settings', 'Settings']); TABLABEL.hub = 'Devices'; }
  else { const i = TABS.findIndex(t => t[0] === 'hub'); if (i >= 0) TABS.splice(i, 1); }
  if (META.product) { document.title = META.product; const h = document.querySelector('h1'); if (h) h.textContent = META.product; }
  if (!TABS.some(t => t[0] === tab)) tab = TABS[0][0];
  if (!canSee(tab)) tab = TABS.map(t => t[0]).find(canSee) || 'settings';
}
function applyTheme() {
  const r = document.documentElement;
  if (UIS.theme === 'auto') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', UIS.theme);
  try { localStorage.setItem('am-theme', UIS.theme); } catch (e) {}
}
const tabVisible = k => k === 'settings' || canSee(k) && ( (!UIS.hidden.includes(k) && !(UIS.mode === 'simple' && UIS.simple_hidden.includes(k))) || FORCE.has(k) || k === tab);
const FORCE = new Set();
async function saveUi(patch) { UIS = await api('/api/ui', patch); applyTheme(); render(); }
function techLevelText(t) {
  if (t.admin) return 'Administrator: everything';
  const v = Object.values(t.access || {}), c = v.filter(x => x === 'change').length, w = v.filter(x => x === 'view').length;
  return (c ? `${c} tab${c > 1 ? 's' : ''} to change` : '') + (c && w ? ' · ' : '') + (w ? `${w} view only` : '') || 'No access to any tab';
}
function vTechs() {
  const T = D.techs;
  if (!T) return loadingBox('Loading accounts…');
  if (T.error) return errBox(T.error);
  if (T.open) return `<div class="banner">Sign-in is <b>off</b>: anyone who opens App Manager on this PC has full control. Create an administrator account to turn sign-in on. You can then add technicians who each get their own username, password and limited access.</div>
    <div class="acts" style="margin-top:12px"><button class="btn primary" data-a="tech-new">Create the administrator account</button></div>`;
  return `<div class="list">${T.items.map(t => `<div class="row"><div class="info"><div class="name">${esc(t.username)} ${t.admin ? '<span class="tag ok">Administrator</span>' : ''} ${t.disabled ? '<span class="tag bad">Switched off</span>' : ''}</div>
    <div class="path">${esc(techLevelText(t))}${t.last_login ? ' · last signed in ' + esc(t.last_login) : ' · never signed in'}</div></div>
    <div class="acts"><button class="btn" data-a="tech-edit" data-id="${esc(t.username)}">Edit</button><button class="btn danger" data-a="tech-del" data-id="${esc(t.username)}">Delete</button></div></div>`).join('')}</div>
    <div class="acts" style="margin-top:12px"><button class="btn primary" data-a="tech-new">+ Add technician</button></div>`;
}
function techEditor(t0, first) {
  const T = D.techs, m = $('#modal');
  const t = Object.assign({username: '', admin: !!first, access: {}, disabled: false}, t0 ? JSON.parse(JSON.stringify(t0)) : {});
  const row = ([id, label]) => `<tr><td>${esc(label)}</td><td><select data-ac="${id}"><option value="">No access</option><option value="view" ${t.access[id] === 'view' ? 'selected' : ''}>View only</option>${id === 'overview' ? '' : `<option value="change" ${t.access[id] === 'change' ? 'selected' : ''}>View and change</option>`}</select></td></tr>`;
  m.hidden = false;
  m.innerHTML = `<div class="dialog wide"><h2>${t0 ? 'Edit ' + esc(t0.username) : (first ? 'Create the administrator' : 'Add a technician')}</h2>
   ${first ? '<div class="path" style="margin-bottom:10px">This account can do everything and manage the others. After you save, App Manager asks for this username and password every time it is opened.</div>' : ''}
   <div class="pfhead"><input type="search" id="tcUser" placeholder="Username" value="${esc(t.username)}" autocomplete="off">
    <input type="password" id="tcPass" placeholder="${t0 ? 'New password (leave empty to keep the current one)' : 'Password (at least 8 characters)'}" autocomplete="new-password"></div>
   ${first ? '' : `<label class="ck" style="margin:10px 0"><input type="checkbox" id="tcAdmin" ${t.admin ? 'checked' : ''}> <span><b>Administrator</b>: full access, and can manage accounts and settings</span></label>
   <div id="tcAcc" ${t.admin ? 'hidden' : ''}><div class="acts" style="margin-bottom:8px"><span class="path">Start from:</span>
    <button class="btn small" data-tp="viewer">View only</button><button class="btn small" data-tp="helpdesk">Help desk</button><button class="btn small" data-tp="technician">Technician</button><button class="btn small" data-tp="full">Everything</button><button class="btn small" data-tp="none">Nothing</button></div>
    <table class="actbl"><tbody>${T.areas.map(row).join('')}</tbody></table>
    <div class="path" style="margin-top:6px"><b>View only</b> shows a tab but blocks every button that changes something. Settings (look, accounts) is for administrators only.</div></div>
   ${t0 ? `<label class="ck" style="margin-top:10px"><input type="checkbox" id="tcOff" ${t.disabled ? 'checked' : ''}> <span>Switch this account off (it cannot sign in, but is kept)</span></label>` : ''}`}
   <div class="btns"><button class="btn" data-tc="cancel">Cancel</button><button class="btn primary" data-tc="save">${t0 ? 'Save' : 'Create'}</button></div></div>`;
  const done = () => { m.hidden = true; m.innerHTML = ''; m.onclick = m.onchange = null; };
  m.onchange = e => { if (e.target.id === 'tcAdmin') $('#tcAcc').hidden = e.target.checked; };
  m.onclick = async e => {
    const pr = e.target.closest('[data-tp]');
    if (pr) { const set = pr.dataset.tp === 'none' ? {} : T.presets[pr.dataset.tp]; $$('[data-ac]', m).forEach(s => s.value = set[s.dataset.ac] || ''); return; }
    const b = e.target.closest('[data-tc]');
    if (!b) { if (e.target === m) done(); return; }
    if (b.dataset.tc === 'cancel') return done();
    const access = {}; $$('[data-ac]', m).forEach(s => { if (s.value) access[s.dataset.ac] = s.value; });
    const j = await post('/api/techs/save', {original: t0?.username, username: $('#tcUser').value, password: $('#tcPass').value,
      admin: first ? true : $('#tcAdmin').checked, access, disabled: $('#tcOff')?.checked || false}, t0 ? 'Saved' : 'Account created');
    if (!j) return;
    done();
    if (j.first) return location.reload();
    load('techs', '/api/techs');
  };
}
function vSettings() {
  const opt = (k, v, l) => `<button data-a="ui-set" data-k="${k}" data-v="${v}" class="${UIS[k] === v ? 'on' : ''}">${l}</button>`;
  const order = UIS.order.length ? UIS.order : TABS.map(t => t[0]);
  const mine = ME.username ? `<h2 class="cat">My account</h2><div class="card"><div class="name">Signed in as ${esc(ME.username)}${ME.admin ? ' (administrator)' : ''}</div>
    <div class="mini add" style="border:0"><input type="password" id="pwCur" placeholder="Current password" autocomplete="current-password"><input type="password" id="pwNew" placeholder="New password (8+ characters)" autocomplete="new-password"><input type="password" id="pwNew2" placeholder="New password again" autocomplete="new-password"></div>
    <div class="acts"><button class="btn primary" data-a="me-pw">Change password</button><button class="btn" data-a="logout">Sign out</button></div></div>` : '';
  const look = `<div class="grid2"><div class="card"><h3>Theme</h3><div class="seg">${opt('theme', 'auto', 'Match Windows')}${opt('theme', 'light', 'Light')}${opt('theme', 'dark', 'Dark')}</div>
     ${ME.admin ? '' : '<div class="path" style="margin-top:8px">Applies to this browser only.</div>'}</div>
   ${ME.admin ? `<div class="card"><h3>Mode</h3><div class="seg">${opt('mode', 'simple', 'Simple')}${opt('mode', 'technician', 'Technician')}</div>
    <div class="path" style="margin-top:8px"><b>Simple</b> hides ${UIS.simple_hidden.map(k => TABLABEL[k]).join(', ')} so only everyday tabs show. <b>Technician</b> shows everything.</div></div>` : ''}</div>`;
  const tabs = !ME.admin ? '' : `<h2 class="cat">Tabs</h2><div class="path" style="margin-bottom:8px">Choose which tabs to show and the order they appear in.</div>
   <div class="list tight">${order.map((k, i) => `<div class="row"><label class="check grow"><input type="checkbox" data-a="ui-tab" data-id="${k}" ${k === 'settings' ? 'disabled checked' : (UIS.hidden.includes(k) ? '' : 'checked')}> <b>${esc(TABLABEL[k] || k)}</b></label>
     <button class="btn small" data-a="ui-move" data-id="${k}" data-dir="-1" ${i === 0 ? 'disabled' : ''}>↑</button><button class="btn small" data-a="ui-move" data-id="${k}" data-dir="1" ${i === order.length - 1 ? 'disabled' : ''}>↓</button></div>`).join('')}</div>
   <div class="acts"><button class="btn" data-a="ui-reset">Reset tabs</button></div>`;
  return `${mine}${ME.admin ? `<h2 class="cat" ${ME.username ? '' : 'style="margin-top:0"'}>Technicians</h2>${vTechs()}` : ''}
   ${ME.admin && META.role !== 'hub' ? `<h2 class="cat">Managed by a hub</h2>${vAgent()}` : ''}
   <h2 class="cat">Look</h2>${look}${tabs}
   <h2 class="cat">About</h2><div class="card"><div class="path">${esc(META.product || 'App Manager')} ${esc(META.version || '')} · settings are saved in ${esc(META.windows ? '%APPDATA%\\appmgr' : 'the App Manager data folder')}${ME.admin ? '<br>Lost the administrator password? Start App Manager once with <b>--reset-logins</b> to turn sign-in off again.' : ''}</div></div>`;
}

/* ---------- GLOBAL SEARCH ---------- */
let gsTimer = null;
function gsRun(q) {
  clearTimeout(gsTimer);
  const box = $('#gsr');
  if (q.trim().length < 2) { box.hidden = true; return; }
  gsTimer = setTimeout(async () => {
    try {
      const r = (await api('/api/search?q=' + encodeURIComponent(q))).items;
      box.innerHTML = r.length ? r.map(i => `<button data-gs="${esc(i.go)}"><span class="tag">${esc(i.kind)}</span> <b>${esc(i.title)}</b>${i.sub ? `<span class="sub">${esc(i.sub.slice(0, 90))}</span>` : ''}</button>`).join('') : '<div class="path" style="padding:10px">Nothing found in the lists already loaded.</div>';
      box.hidden = false;
    } catch (e) {}
  }, 180);
}

/* ---------- ACTIVITY ---------- */
function vActivity() {
  const A = D.activity; if (!A) return loadingBox('Loading…');
  return `<div class="count">What App Manager has done on this PC, newest first.</div><div class="tablewrap"><table><thead><tr><th class="nosort">When</th><th class="nosort">By</th><th class="nosort">Action</th><th class="nosort">What</th><th class="nosort">Result</th></tr></thead><tbody>
  ${A.items.map(r => `<tr><td class="mute" style="white-space:nowrap">${esc(r.t)}</td><td class="mute">${esc(r.by || '')}</td><td>${esc(r.action)}</td><td>${esc(r.target)}</td><td><span class="tag ${r.result === 'ok' ? 'ok' : (r.result === 'failed' ? 'bad' : 'warn')}">${esc(r.result)}</span>${r.detail ? ` <span class="sub">${esc(r.detail)}</span>` : ''}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">Nothing yet.</td></tr>'}</tbody></table></div>`;
}

/* ---------- tasks (background jobs) ---------- */
let JOBS = [], tasksOpen = false, seenDone = new Set(), pollingJobs = false;
async function pollJobs() {
  if (pollingJobs) return; pollingJobs = true;
  try {
    for (;;) {
      JOBS = (await api('/api/jobs')).items;
      const running = JOBS.filter(j => j.status === 'running').length;
      const b = $('#taskBadge'); b.hidden = !running; b.textContent = running;
      JOBS.filter(j => j.status !== 'running' && !seenDone.has(j.id)).forEach(j => {
        seenDone.add(j.id); if (!firstJobPoll) { toast(`${j.title}: ${j.result}`); jobFinished(j); }
      });
      firstJobPoll = false;
      if (tasksOpen) renderTasks();
      if (!running && !tasksOpen) break;
      await new Promise(r => setTimeout(r, 1500));
    }
  } catch (e) {}
  pollingJobs = false;
}
let firstJobPoll = true;
function jobFinished(j) {
  const t = j.title;
  if (/^uninstall/i.test(t)) return load('programs', '/api/programs');
  if (/restore point$/i.test(t) || /^undo everything|^back up drivers|system image/i.test(t)) { load('backup', '/api/backup', true); if (/^undo/i.test(t)) { load('tweaks', '/api/tweaks'); load('security', '/api/security', true); } return; }
  if (/^apply profile/i.test(t)) { load('tweaks', '/api/tweaks'); load('install', '/api/install', true); return; }
  if (/^fix /i.test(t)) return load('devices', '/api/devices', true);
  if (/^install (anydesk|remote utilities|ultraviewer|anyviewer)/i.test(t)) return load('remote', '/api/remote', true);
  if (/^install \d/i.test(t)) { INST.clear(); return load('install', '/api/install', true); }
  if (/tweak|restore point|temporary/i.test(t)) { TW.clear(); return load('tweaks', '/api/tweaks'); }
  if (/clean up disk/i.test(t)) { CL.clear(); return load('cleanup', '/api/cleanup', true); }
  if (/find (large|duplicate)/i.test(t)) return api('/api/cleanup/results').then(r => { D.cleanupres = r; dataChanged('cleanupres'); });
  if (/driver check/i.test(t)) return load('drivercheck', '/api/drivercheck');
  return load('updates', '/api/updates');
}
function renderTasks() {
  const m = $('#modal');
  m.innerHTML = `<div class="dialog"><h2>Tasks</h2><div class="body">${JOBS.length ? '' : 'Nothing running. Uninstalls and updates show up here.'}</div>
   ${JOBS.map(j => `<div class="job"><div class="head">${j.status === 'running' ? '<span class="spin"></span>' : `<span class="tag ${j.status === 'done' ? 'ok' : 'bad'}">${j.status === 'done' ? 'Done' : 'Problem'}</span>`}<b>${esc(j.title)}</b></div>
   ${j.result ? `<div class="path">${esc(j.result)}</div>` : ''}${j.log.length ? `<pre class="log">${esc(j.log.join('\n'))}</pre>` : ''}</div>`).join('')}
   <div class="btns"><button class="btn primary" data-d="close">Close</button></div></div>`;
  $$('pre.log', m).forEach(p => p.scrollTop = p.scrollHeight);
}
function openTasks() {
  tasksOpen = true; $('#modal').hidden = false; renderTasks();
  $('#modal').onclick = e => { if (e.target.closest('[data-d]') || e.target === $('#modal')) { tasksOpen = false; $('#modal').hidden = true; $('#modal').innerHTML = ''; $('#modal').onclick = null; } };
  pollJobs();
}

/* ---------- views, tabs, rendering ---------- */
const VIEWS = {remote: () => vRemoteTools(), link: () => `<div class="banner info">Let a technician's App Manager Hub manage this PC. Nothing here opens a port on this PC: it calls the hub. You decide which kinds of order it accepts and can leave at any time.</div>${vAgent()}`, overview: vOverview, programs: vPrograms, myapps: vMyApps, startup: vStartup, updates: vUpdates, install: vInstall, tweaks: vTweaks, security: vSecurity, monitor: vMonitor, tools: vTools, profiles: vProfiles, hub: vHub, backup: vBackup, settings: vSettings, devices: vDevices, activity: vActivity};
const TOOLS = {remote: () => '<button class="btn" data-a="reload-remote">Refresh</button>', link: () => '', programs: toolsPrograms, myapps: toolsMyApps, startup: toolsStartup, updates: toolsUpdates, install: toolsInstall, tweaks: toolsTweaks, security: toolsSecurity, monitor: () => '', tools: toolsTools, profiles: toolsProfiles, hub: toolsHub, backup: toolsBackup, settings: () => '', devices: toolsDevices,
  overview: () => '', activity: () => '<button class="btn" data-a="reload-activity">Refresh</button>'};
function renderTabs() {
  const order = UIS.order.length ? UIS.order : TABS.map(t => t[0]);
  $('#tabs').innerHTML = order.filter(tabVisible).map(k => `<button data-tab="${k}" class="${tab === k ? 'on' : ''}">${TABLABEL[k]}</button>`).join('');
}
function renderTools() { $('#tools').innerHTML = TOOLS[tab](); }
function renderView() {
  const y = document.scrollingElement.scrollTop;
  $('#view').innerHTML = VIEWS[tab]();
  document.scrollingElement.scrollTop = y;
  const who = $('#who'); who.hidden = !ME.username; who.innerHTML = ME.username ? `${esc(ME.username)}${ME.admin ? ' · admin' : ''}` : '';
  $('#signout').hidden = !ME.username;
  const adm = $('#adm');
  adm.textContent = !META.windows ? 'Test mode' : (META.admin ? 'Full control' : 'Limited: not administrator');
  adm.className = 'pill' + (META.windows && META.admin ? '' : ' bad');
  $('#banner').innerHTML = !META.windows ? '<div class="banner">Test mode: you are not on Windows, so this shows sample data and does not change anything on your system.</div>'
    : (META.admin ? '' : '<div class="banner">Windows has not given App Manager administrator permission, so blocking, uninstalling and some startup changes will not work. Close it and open it again, and choose <b>Yes</b> when Windows asks.</div>');
}
function render() { renderTabs(); renderTools(); renderView(); }
function dataChanged(key) {
  const rel = {overview: ['hardware', 'devices', 'programs', 'startup', 'apps', 'updates'], programs: ['programs'], myapps: ['apps', 'running'],
    startup: ['startup'], updates: ['updates', 'drivercheck'], install: ['install'], tweaks: ['tweaks'], security: ['security', 'cfa'], monitor: ['monitor'], profiles: ['profiles'], backup: ['backup'], hub: ['hub'], remote: ['remote'], link: ['agent'], settings: ['techs', 'agent'], tools: ['cleanup', 'cleanupres', 'events', 'network', 'wu', 'netout', 'remote'],
    devices: ['hardware', 'devices', 'drivers'], activity: ['activity']}[tab];
  if (rel.includes(key)) { renderView(); if (['updates', 'security', 'devices', 'install'].includes(key)) renderTools(); }
}
function enter() {
  if (tab === 'overview') { load('hardware', '/api/hardware'); load('devices', '/api/devices'); load('programs', '/api/programs'); load('startup', '/api/startup'); refreshApps(); }
  if (tab === 'programs') load('programs', '/api/programs');
  if (tab === 'myapps') refreshApps();
  if (tab === 'startup') load('startup', '/api/startup');
  if (tab === 'updates') { if (seg.updates === 'drivers') load('drivercheck', '/api/drivercheck'); else load('updates', '/api/updates'); }
  if (tab === 'devices') { if (seg.devices === 'hardware') load('hardware', '/api/hardware'); if (seg.devices === 'tree') load('devices', '/api/devices'); if (seg.devices === 'drivers') load('drivers', '/api/drivers'); }
  if (tab === 'monitor') monStart(); else clearInterval(monTimer);
  if (tab === 'tools') {
    if (seg.tools === 'cleanup') load('cleanup', '/api/cleanup');
    if (seg.tools === 'large' || seg.tools === 'dups') api('/api/cleanup/results').then(r => { D.cleanupres = r; dataChanged('cleanupres'); });
    if (seg.tools === 'events') load('events', '/api/events');
    if (seg.tools === 'network') api('/api/tech/network').then(r => { D.network = r; dataChanged('network'); }).catch(e => { D.network = {items: []}; toast(e.message); dataChanged('network'); });
    if (seg.tools === 'repair') load('wu', '/api/tech/wu');
    if (seg.tools === 'remote') load('remote', '/api/remote');
  }
  if (tab === 'remote') load('remote', '/api/remote');
  if (tab === 'link') load('agent', '/api/agent');
  if (tab === 'settings' && ME.admin) { load('techs', '/api/techs'); load('agent', '/api/agent'); }
  if (tab === 'hub') { load('hub', '/api/hub'); hubPoll(); } else clearInterval(hubTimer);
  if (tab === 'profiles') load('profiles', '/api/profiles');
  if (tab === 'backup') load('backup', '/api/backup');
  if (tab === 'install') load('install', '/api/install');
  if (tab === 'tweaks') load('tweaks', '/api/tweaks');
  if (tab === 'security') { load('security', '/api/security'); load('cfa', '/api/security/cfa'); }
  if (tab === 'activity') api('/api/activity').then(r => { D.activity = r; dataChanged('activity'); });
}
function setTab(t, s) { if (!canSee(t)) return toast('Your account does not have access to that tab.'); if (!tabVisible(t)) FORCE.add(t); tab = t; if (s) seg[t] = s; $('#drawer').hidden = true; render(); enter(); }

/* ---------- events ---------- */
document.addEventListener('click', async ev => {
  const t = ev.target;
  const gsb = t.closest('[data-gs]'); if (gsb) { const [a2, b2] = gsb.dataset.gs.split(':'); $('#gsr').hidden = true; $('#gs').value = ''; return setTab(a2, b2); }
  if (!t.closest('.gsearch')) $('#gsr').hidden = true;
  const tb = t.closest('[data-tab]'); if (tb) return setTab(tb.dataset.tab);
  const go = t.closest('[data-go]'); if (go) { ev.preventDefault(); const [a, b] = go.dataset.go.split(':'); return setTab(a, b); }
  const sg = t.closest('[data-seg]'); if (sg) { const [n, k] = sg.dataset.seg.split(':'); seg[n] = k; render(); return enter(); }
  const so = t.closest('[data-sort]'); if (so) { const [ns, k] = so.dataset.sort.split(':'); const st = F[ns]; st.dir = st.sort === k ? -st.dir : 1; st.sort = k; return renderView(); }
  const row = t.closest('tr[data-pid]');
  const b = t.closest('[data-a]');
  if (!b || b.tagName === 'INPUT') { if (row && !t.closest('input,button')) openProgram(row.dataset.pid); return; }
  const a = b.dataset.a, d = b.dataset;
  const act = async (p, body, msg) => { const j = await post(p, body, msg); await refreshApps(); return j; };
  switch (a) {
    case 'close-drawer': $('#drawer').hidden = true; return;
    case 'tasks': return openTasks();
    case 'start': return act(`/api/app/${d.id}/start`, {}, 'Started');
    case 'stop': return act(`/api/app/${d.id}/stop`, {}, 'Stopped');
    case 'restart': return act(`/api/app/${d.id}/restart`, {}, 'Restarted');
    case 'remove': { if (await dialog({title: 'Remove from My apps?', body: 'This only removes it from this list. It does not uninstall the program.', ok: 'Remove', danger: true})) return act(`/api/app/${d.id}/remove`, {}, 'Removed'); return; }
    case 'add': return act('/api/app/add', {exe: d.exe, name: d.name}, 'Added to My apps');
    case 'kill': { if (await dialog({title: `Stop ${d.name}?`, body: 'Unsaved work in it may be lost.', ok: 'Stop it', danger: true})) return act('/api/kill', {exe: d.exe}, 'Stopped'); return; }
    case 'browse': { toast('Choose a program in the window that opens…'); const r = await post('/api/pick', {}); if (r && r.path) return act('/api/app/add', {exe: r.path}, 'Added to My apps'); return; }
    case 'shortcut': return post('/api/shortcut', {}, 'Shortcut added to your desktop');
    case 'quit': { if (await dialog({title: 'Close App Manager?', body: 'Your programs keep running, but "Keep running" stops working until you open App Manager again.', ok: 'Close it', danger: true})) { try { await api('/api/quit', {}); } catch (e) {} document.body.innerHTML = '<p style="font:16px system-ui;margin:4rem auto;max-width:30rem">App Manager has closed. You can close this tab.</p>'; } return; }
    case 'net': case 'p-block': {
      const want = d.blocked !== '1';
      const url = a === 'net' ? '/api/block' : `/api/programs/${d.id}/block`;
      const send = async force => {
        try { await api(url, {exe: d.exe, name: d.name, blocked: want, force}); toast(want ? 'Internet blocked' : 'Internet allowed'); }
        catch (e) { if (e.confirm) { if (await dialog({title: 'Are you sure?', body: esc(e.confirm), ok: 'Block it', danger: true})) return send(true); } else toast(e.message); }
        await refreshApps(); if (a === 'p-block') drawer(await api('/api/programs/' + d.id));
      };
      return send(false);
    }
    case 'fav': { const j = await post(`/api/programs/${d.id}/favorite`, {}); if (j) { const p = D.programs.items.find(x => x.id === d.id); if (p) p.favorite = j.favorite; if (D.drawer?.id === d.id) { D.drawer.favorite = j.favorite; drawer(D.drawer); } renderView(); } return; }
    case 'uninstall-sel': return uninstall([...SEL]);
    case 'p-uninstall': return uninstall([d.id]);
    case 'p-open': return post(`/api/programs/${d.id}/open`, {});
    case 'p-manage': { const j = await post(`/api/programs/${d.id}/manage`, {}, 'Added to My apps'); if (j) drawer(await api('/api/programs/' + d.id)); return; }
    case 'p-size': { $('#psize').textContent = 'Measuring…'; const r = await api(`/api/programs/${d.id}/size`); $('#psize').textContent = r.bytes == null ? '—' : fmtBytes(r.bytes) + (r.complete ? '' : ' or more'); return; }
    case 'reload-programs': return load('programs', '/api/programs', true);
    case 'reload-startup': return load('startup', '/api/startup', true);
    case 'reload-updates': return load('updates', '/api/updates', true);
    case 'reload-activity': return enter();
    case 'reload-devices': { const k = {hardware: ['hardware', '/api/hardware'], tree: ['devices', '/api/devices'], drivers: ['drivers', '/api/drivers']}[seg.devices]; return load(k[0], k[1], true); }
    case 'reload-install': return load('install', '/api/install', true);
    case 'reload-tweaks': return load('tweaks', '/api/tweaks', true);
    case 'reload-security': { load('security', '/api/security', true); return load('cfa', '/api/security/cfa'); }
    case 'preset': { const p = D.install.presets[+d.i]; const have = new Set(D.install.categories.flatMap(c => c.items.filter(a => a.installed).map(a => a.id))); p.ids.forEach(i => { if (!have.has(i)) INST.add(i); }); renderView(); return updateInstBtn(); }
    case 'preset-clear': INST.clear(); renderView(); return updateInstBtn();
    case 'install-sel': {
      const names = D.install.categories.flatMap(c => c.items).filter(a => INST.has(a.id));
      if (!await dialog({title: `Install ${names.length} program${names.length > 1 ? 's' : ''}?`, body: `<ul>${names.map(a => `<li>${esc(a.name)}</li>`).join('')}</ul>They install quietly in the background. Windows may ask for permission for some of them.`, ok: 'Install'})) return;
      const j = await post('/api/install/run', {ids: [...INST], confirm: true});
      if (j) { openTasks(); pollJobs(); }
      return;
    }
    case 'tw-apply': {
      const sel = D.tweaks.items.filter(t => TW.has(t.id)), adv = sel.filter(t => t.group === 'adv');
      const r = await dialog({title: `Apply ${sel.length} tweak${sel.length > 1 ? 's' : ''}?`,
        body: `<ul>${sel.map(t => `<li>${esc(t.name)}${t.group === 'adv' ? ' <span class="tag bad">Advanced</span>' : ''}</li>`).join('')}</ul>${adv.length ? '<b>Some of these turn off Windows features.</b> ' : ''}You can undo each one afterwards.${sel.some(t => t.restart === 'explorer') ? ' File Explorer will restart briefly.' : ''}`,
        checks: [{id: 'rp', label: 'Create a restore point first (recommended)', checked: true}], ok: 'Apply', danger: adv.length > 0});
      if (!r) return;
      const j = await post('/api/tweaks/apply', {ids: [...TW], confirm: true, restore_point: r.rp});
      if (j) { openTasks(); pollJobs(); }
      return;
    }
    case 'tw-undo': {
      if (!await dialog({title: `Undo “${d.name}”?`, body: 'The setting goes back to what it was before App Manager changed it.', ok: 'Undo'})) return;
      const j = await post('/api/tweaks/undo', {ids: [d.id], confirm: true});
      if (j) { openTasks(); pollJobs(); }
      return;
    }
    case 'tw-action': {
      if (!await dialog({title: d.name + '?', body: 'This is a one-time action.', ok: 'Run'})) return;
      const j = await post('/api/tweaks/action', {id: d.id, confirm: true});
      if (j) { openTasks(); pollJobs(); }
      return;
    }
    case 'sec-fix': {
      const audit = d.mode === 'audit';
      if (!await dialog({title: audit ? `Audit ${d.name}?` : `Turn on ${d.name}?`, body: audit ? 'Windows will only record what it would block, and block nothing. Good for testing before turning it fully on.' : esc(SEC_NOTE[d.id] || 'This changes a Windows security setting. You can restore the previous value afterwards.'), ok: audit ? 'Start auditing' : 'Turn on'})) return;
      const j = await post('/api/security/fix', {id: d.id, mode: d.mode, confirm: true}, audit ? 'Audit mode on' : 'Turned on');
      if (j) { load('security', '/api/security', true); load('cfa', '/api/security/cfa'); }
      return;
    }
    case 'sec-restore': {
      if (!await dialog({title: `Restore previous setting for ${d.name}?`, body: 'The setting goes back to the value it had before App Manager changed it.', ok: 'Restore'})) return;
      const j = await post('/api/security/restore', {id: d.id}, 'Restored');
      if (j) { load('security', '/api/security', true); load('cfa', '/api/security/cfa'); }
      return;
    }
    case 'sec-fixall': {
      const todo = D.security.items.filter(i => i.can_fix && !i.optional && i.status === 'bad');
      if (!todo.length) return;
      if (!await dialog({title: `Turn on ${todo.length} protection${todo.length > 1 ? 's' : ''}?`, body: `<ul>${todo.map(i => `<li>${esc(i.name)}</li>`).join('')}</ul>Each one can be restored to its previous value afterwards. Optional items such as Remote Desktop are left alone.`, ok: 'Turn them on'})) return;
      const j = await post('/api/security/fixall', {ids: todo.map(i => i.id), confirm: true});
      if (j) { toast(`${j.done} turned on` + (j.failed.length ? `. Problem: ${j.failed[0]}` : '')); load('security', '/api/security', true); load('cfa', '/api/security/cfa'); }
      return;
    }
    case 'cfa-allow': case 'cfa-allow-typed': {
      const path = a === 'cfa-allow' ? d.path : ($('#cfaApp').value || '').trim();
      if (!path) return toast('Type or browse for a program first.');
      if (a === 'cfa-allow' && !await dialog({title: 'Allow this program?', body: `${esc(path)}<br><br>It will be able to change your protected folders. Only allow programs you trust.`, ok: 'Allow'})) return;
      if (await post('/api/security/cfa/app', {path, allow: true}, 'Allowed')) load('cfa', '/api/security/cfa');
      return;
    }
    case 'cfa-unallow': if (await post('/api/security/cfa/app', {path: d.path, allow: false}, 'Removed')) load('cfa', '/api/security/cfa'); return;
    case 'cfa-browse': { const r = await post('/api/pick', {}); if (r && r.path) $('#cfaApp').value = r.path; return; }
    case 'cfa-folder': { const path = ($('#cfaDir').value || '').trim(); if (!path) return toast('Type a folder path first.'); if (await post('/api/security/cfa/folder', {path, add: true}, 'Folder protected')) load('cfa', '/api/security/cfa'); return; }
    case 'cfa-unfolder': if (await post('/api/security/cfa/folder', {path: d.path, add: false}, 'Removed')) load('cfa', '/api/security/cfa'); return;
    case 'dc-run': {
      const j = await post('/api/drivercheck/run', {catalog: DC.cat, vendor: DC.ven});
      if (j) { openTasks(); pollJobs(); }
      return;
    }
    case 'reload-cleanup': return load('cleanup', '/api/cleanup', true);
    case 'reload-events': return load('events', '/api/events', true);
    case 'reload-wu': return load('wu', '/api/tech/wu', true);
    case 'reload-net': return enter();
    case 'cl-run': {
      const sel = D.cleanup.items.filter(i => CL.has(i.id));
      if (!await dialog({title: 'Clean up these?', body: `<ul>${sel.map(i => `<li>${esc(i.name)} (${fmtBytes(i.size)})</li>`).join('')}</ul>${sel.some(i => i.id === 'recycle') ? '<b>The Recycle Bin cannot be restored afterwards.</b> ' : ''}Files in use are skipped.`, ok: 'Clean up'})) return;
      const j = await post('/api/cleanup/run', {ids: [...CL], confirm: true});
      if (j) { openTasks(); pollJobs(); }
      return;
    }
    case 'pick-folder': { const r = await post('/api/pickfolder', {}); if (r && r.path) { F.tools.folder = r.path; renderTools(); } return; }
    case 'find-large': case 'find-dups': {
      const j = await post(a === 'find-large' ? '/api/cleanup/large' : '/api/cleanup/dups', {folder: F.tools.folder, min_mb: a === 'find-large' ? F.tools.mb : F.tools.dmb});
      if (j) { TRASH.clear(); openTasks(); pollJobs(); }
      return;
    }
    case 'reveal': return post('/api/cleanup/reveal', {path: d.path});
    case 'trash-run': {
      if (!await dialog({title: `Move ${TRASH.size} file${TRASH.size > 1 ? 's' : ''} to the Recycle Bin?`, body: 'You can still restore them from the Recycle Bin until it is emptied.', ok: 'Move them', danger: true})) return;
      const j = await post('/api/cleanup/trash', {paths: [...TRASH], confirm: true});
      if (j) { toast(`${j.moved} moved to the Recycle Bin`); TRASH.clear(); D.cleanupres = await api('/api/cleanup/results'); renderTools(); renderView(); }
      return;
    }
    case 'net-ping': case 'net-dns': case 'net-port': {
      const p = {host: F.tools.host.trim(), port: F.tools.port.trim()};
      D.netout = 'Working…'; renderView();
      try {
        const r = await api('/api/tech/' + a.slice(4), p);
        D.netout = a === 'net-ping' ? r.output : a === 'net-dns' ? `${p.host} is at:\n${r.addresses.join('\n')}` : `Port ${p.port} on ${p.host} is ${r.open ? 'OPEN' : 'closed or blocked'} (${r.ms} ms)`;
      } catch (e) { D.netout = e.message; }
      return renderView();
    }
    case 'net-trace': { const j = await post('/api/tech/trace', {host: F.tools.host.trim()}); if (j) { openTasks(); pollJobs(); } return; }
    case 'netfix': {
      if (!await dialog({title: 'Run this fix?', body: {flushdns: 'Clears the saved website addresses.', renew: 'Your connection will drop for a few seconds.', winsock: 'Needs a restart afterwards.', ipreset: 'Needs a restart afterwards.'}[d.id], ok: 'Run'})) return;
      const r = await post('/api/tech/netfix', {action: d.id, confirm: true}); if (r) { D.netout = r.output + (r.reboot ? '\n\nRestart the PC to finish.' : ''); renderView(); }
      return;
    }
    case 'repair': {
      if (!await dialog({title: d.name + '?', body: 'It runs in the background and can take a while. Keep the PC on.', ok: 'Start'})) return;
      const j = await post('/api/tech/repair', {id: d.id, confirm: true}); if (j) { openTasks(); pollJobs(); } return;
    }
    case 'wu-scan': if (await post('/api/tech/wu/scan', {}, 'Windows is checking')) load('wu', '/api/tech/wu', true); return;
    case 'open-tool': return post('/api/tech/open', {what: d.id});
    case 'add-program': return addProgramDialog();
    case 'inst-remove': {
      ev.preventDefault();
      if (!await dialog({title: `Remove ${d.name} from the list?`, body: 'This only removes it from this list. Nothing is uninstalled. Built-in programs can be brought back with “Restore removed”.', ok: 'Remove', danger: true})) return;
      INST.delete(d.id);
      if (await post('/api/install/remove', {id: d.id}, 'Removed')) load('install', '/api/install', true);
      return;
    }
    case 'inst-restore': if (await post('/api/install/restore', {}, 'Restored')) load('install', '/api/install', true); return;
    case 'dev-fix': {
      const re = d.level === 'reinstall';
      if (!await dialog({title: re ? `Reinstall ${d.name}?` : `Diagnose and fix ${d.name}?`,
        body: re ? 'Windows removes the device and detects it again, which reinstalls its driver. A restore point is created first. Use this when the simple fix did not work.'
          : 'App Manager checks the device and driver, then tries the safe fixes: turn it on, restart it and rescan for hardware changes. Nothing is downloaded.', ok: re ? 'Reinstall' : 'Start', danger: re})) return;
      const j = await post('/api/devices/fix', {id: d.id, level: re ? 'reinstall' : 'safe', confirm: true});
      if (j) { openTasks(); pollJobs(); }
      return;
    }
    case 'dev-fixall': {
      const n = (D.devices?.items || []).filter(x => x.problem && x.present).length;
      if (!await dialog({title: `Try to fix ${n} device${n > 1 ? 's' : ''}?`, body: 'Each one is checked, then restarted and rescanned. Nothing is removed or downloaded.', ok: 'Start'})) return;
      const j = await post('/api/devices/fixall', {confirm: true});
      if (j) { openTasks(); pollJobs(); }
      return;
    }
    case 'ui-set': if (!ME.admin) { UIS[d.k] = d.v; applyTheme(); return render(); } return saveUi({[d.k]: d.v});
    case 'hub-on': {
      const port = parseInt(F.hub.port, 10);
      if (!await dialog({title: 'Turn on the hub?', body: `This PC starts listening on port ${port} for managed PCs.${META.windows ? ' A Windows Firewall rule is added for private and domain networks.' : ''} Messages are signed but not encrypted, so use a network you trust.`, ok: 'Turn on'})) return;
      if (await post('/api/hub/enable', {enable: true, port, name: F.hub.name || undefined})) load('hub', '/api/hub'); return;
    }
    case 'hub-off': { if (await dialog({title: 'Turn off the hub?', body: 'Managed PCs can no longer check in until you turn it on again. They stay enrolled.', ok: 'Turn off'}) && await post('/api/hub/enable', {enable: false})) load('hub', '/api/hub'); return; }
    case 'hub-add': return hubAddDialog();
    case 'hub-tok-del': await post('/api/hub/token/delete', {id: d.id}); return load('hub', '/api/hub');
    case 'hub-open': return hubOpen(d.id);
    case 'hub-sel-clear': HSEL.clear(); return renderView();
    case 'hub-order-sel': return hubOrder([...HSEL]);
    case 'ag-test': { const r = await post('/api/agent/test', {code: $('#agCode').value}, null); if (r) await dialog({title: r.ok ? 'Hub reachable' : 'Cannot reach the hub', body: esc(r.message), ok: 'OK', hideCancel: true}); return; }
    case 'ag-enroll': {
      const j = await post('/api/agent/enroll', {code: $('#agCode').value, name: $('#agName').value}, 'Connected to the hub');
      if (j) load('agent', '/api/agent'); return;
    }
    case 'ag-leave': { if (await dialog({title: 'Stop being managed?', body: 'This PC forgets the hub. Remove it from the hub\'s list too, or it will show as offline.', ok: 'Stop', danger: true}) && await post('/api/agent/leave', {confirm: true}, 'Done')) load('agent', '/api/agent'); return; }
    case 'err-lookup': {
      const q = await askText('Look up an error code', 'e.g. AM-N104'); if (!q) return;
      try {
        const r = await api('/api/errors?code=' + encodeURIComponent(q.trim()));
        await dialog({title: r.item.code + ': ' + r.item.title, body: `<div class="path"><b>Why:</b> ${esc(r.item.cause)}</div><div class="path" style="margin-top:6px"><b>Fix:</b> ${esc(r.item.fix)}</div>`, ok: 'OK', hideCancel: true});
      } catch (e) { toast(e.message); }
      return;
    }
    case 'reload-remote': return load('remote', '/api/remote', true);
    case 'rm-open': await post('/api/remote/open', {tool: d.id}, 'Opened'); return;
    case 'rm-install': { if (await dialog({title: `Install ${d.name}?`, body: 'Installs it with Windows Package Manager (winget).', ok: 'Install'})) { const j = await post('/api/remote/install', {tool: d.id, confirm: true}, null); if (j) toast('Installing… see the Tasks list for progress.'); } return; }
    case 'rm-id': { const v = await askText(`${d.name} ID on this PC`, 'ID', d.cur || ''); if (v === null) return; if (await post('/api/remote/id', {tool: d.id, id: v}, 'Saved')) load('remote', '/api/remote', true); return; }
    case 'tech-new': return techEditor(null, D.techs?.open);
    case 'tech-edit': return techEditor(D.techs.items.find(t => t.username === d.id));
    case 'tech-del': { if (await dialog({title: `Delete ${d.id}?`, body: 'The account is removed and signed out. This cannot be undone.', ok: 'Delete', danger: true})) { const j = await post('/api/techs/delete', {username: d.id}, 'Deleted'); if (j) { if (j.open) return location.reload(); load('techs', '/api/techs'); } } return; }
    case 'me-pw': {
      if ($('#pwNew').value !== $('#pwNew2').value) return toast('The two new passwords are different.');
      if (await post('/api/me/password', {current: $('#pwCur').value, new: $('#pwNew').value}, 'Password changed')) $$('#pwCur,#pwNew,#pwNew2').forEach(i => i.value = '');
      return;
    }
    case 'logout': await post('/api/logout', {}); return location.reload();
    case 'img-start': {
      const f = F.backup, tgt = f.target === '__unc' ? f.unc.trim() : f.target + ':';
      if (!await dialog({title: 'Create a full system image?', body: `Everything on ${['C', ...f.inc].map(l => l + ':').join(', ')} is copied to <b>${esc(tgt)}</b>. It can take an hour or more and slows the PC while it runs. Anything already saved there by Windows Backup is kept up to date automatically.`, ok: 'Start'})) return;
      const j = await post('/api/backup/image', {target: tgt, include: f.inc, confirm: true});
      if (j) { openTasks(); pollJobs(); load('backup', '/api/backup'); }
      return;
    }
    case 'img-stop': { if (await dialog({title: 'Stop the system image?', body: 'The partly made image is discarded by Windows.', ok: 'Stop it', danger: true}) && await post('/api/backup/image/stop', {}, 'Stopping…')) load('backup', '/api/backup'); return; }
    case 'ui-move': { const o = [...UIS.order], i = o.indexOf(d.id), j = i + (+d.dir); if (j < 0 || j >= o.length) return; [o[i], o[j]] = [o[j], o[i]]; return saveUi({order: o}); }
    case 'ui-reset': return saveUi({order: TABS.map(t => t[0]), hidden: []});
    case 'prof-new': return profileEditor(null);
    case 'prof-edit': return profileEditor(D.profiles.items.find(p => p.id === d.id));
    case 'prof-apply': return applyProfile(d.id, d.name);
    case 'prof-send': return void hubOrder([], {type: 'apply_profile', profile_id: d.id});
    case 'prof-del': { if (await dialog({title: `Delete “${d.name}”?`, body: 'The profile is removed. Nothing on this PC changes.', ok: 'Delete', danger: true}) && await post('/api/profiles/delete', {id: d.id}, 'Deleted')) load('profiles', '/api/profiles'); return; }
    case 'prof-capture': { if (await dialog({title: 'Capture this PC as a profile?', body: 'Saves the tweaks that are applied, the security protections that are on and the startup items that are off, as a new profile you can apply to other PCs.', ok: 'Capture'}) && await post('/api/profiles/capture', {name: 'Captured ' + new Date().toISOString().slice(0, 10)}, 'Profile created')) load('profiles', '/api/profiles'); return; }
    case 'prof-import': { const f = $('#profFile'); f.value = ''; f.onchange = async () => { try { const data = JSON.parse(await f.files[0].text()); if (await post('/api/profiles/import', {data}, 'Profile imported')) load('profiles', '/api/profiles'); } catch (e) { toast('That file could not be read as a profile.'); } }; f.click(); return; }
    case 'reload-backup': return load('backup', '/api/backup', true);
    case 'bk-rp': { if (!await dialog({title: 'Create a restore point?', body: 'Windows saves the state of system files and settings so you can roll back later.', ok: 'Create'})) return; const j = await post('/api/backup/restorepoint', {confirm: true}); if (j) { openTasks(); pollJobs(); } return; }
    case 'bk-sysrestore': return post('/api/backup/opensysrestore', {});
    case 'bk-undoall': { if (!await dialog({title: 'Undo everything App Manager changed?', body: 'Every tweak and security setting App Manager changed goes back to its previous value.', ok: 'Undo all', danger: true})) return; const j = await post('/api/backup/undoall', {confirm: true}); if (j) { openTasks(); pollJobs(); } return; }
    case 'bk-drivers': { if (!await dialog({title: 'Back up drivers?', body: 'This can take several minutes and uses some disk space.', ok: 'Back up'})) return; const j = await post('/api/backup/drivers', {folder: F.backup.folder, confirm: true}); if (j) { openTasks(); pollJobs(); } return; }
    case 'bk-import': {
      const f = $('#bkFile'); f.value = '';
      f.onchange = async () => {
        const buf = new Uint8Array(await f.files[0].arrayBuffer()); let bin = ''; buf.forEach(c => bin += String.fromCharCode(c));
        if (!await dialog({title: 'Import these settings?', body: 'Your current settings are copied to a safe folder first, then replaced.', ok: 'Import'})) return;
        const r = await post('/api/backup/import', {data: btoa(bin), confirm: true});
        if (r) { await dialog({title: 'Settings imported', body: `Restored: ${esc(r.restored.join(', '))}.<br>Your old files were kept in ${esc(r.kept_old_in)}.`, hideCancel: true}); UIS = await api('/api/ui'); applyTheme(); render(); enter(); }
      };
      f.click(); return;
    }
    case 'upd': case 'upd-all': {
      const all = a === 'upd-all';
      const r = await dialog({title: all ? 'Install all updates?' : `Update ${d.name}?`, body: 'The program may close while it updates, so save your work first.', ok: 'Update', danger: false});
      if (!r) return;
      const j = await post('/api/updates/install', all ? {all: true, confirm: true} : {ids: [d.id], confirm: true});
      if (j) { openTasks(); pollJobs(); }
      return;
    }
  }
});
document.addEventListener('change', async ev => {
  const c = ev.target;
  if (c.dataset.f) { setPath(c.dataset.f, c.type === 'checkbox' ? c.checked : c.value); if (/^(tools|backup|hub)\./.test(c.dataset.f)) return; return renderView(); }
  if (c.dataset.a === 'sel') { c.checked ? SEL.add(c.dataset.id) : SEL.delete(c.dataset.id); return updateSelBtn(); }
  if (c.dataset.a === 'selall') { const shown = progList(); shown.forEach(p => c.checked ? SEL.add(p.id) : SEL.delete(p.id)); renderView(); return updateSelBtn(); }
  if (c.dataset.a === 'inst') { c.checked ? INST.add(c.dataset.id) : INST.delete(c.dataset.id); return updateInstBtn(); }
  if (c.dataset.a === 'tw') { c.checked ? TW.add(c.dataset.id) : TW.delete(c.dataset.id); return updateTwBtn(); }
  if (c.dataset.a === 'dc-cat' || c.dataset.a === 'dc-ven') { DC[c.dataset.a === 'dc-cat' ? 'cat' : 'ven'] = c.checked; return renderView(); }
  if (c.dataset.a === 'cl') { c.checked ? CL.add(c.dataset.id) : CL.delete(c.dataset.id); const b = $('#clBtn'); if (b) { b.disabled = !CL.size; b.textContent = `Clean selected (${CL.size})`; } return; }
  if (c.dataset.a === 'trash') { c.checked ? TRASH.add(c.dataset.path) : TRASH.delete(c.dataset.path); const b = $('#trBtn'); if (b) { b.disabled = !TRASH.size; b.textContent = `Move to Recycle Bin (${TRASH.size})`; } return; }
  if (c.dataset.a === 'hub-sel') { c.checked ? HSEL.add(c.dataset.id) : HSEL.delete(c.dataset.id); return renderView(); }
  if (c.dataset.a === 'ag-pol') { const body = {}; $$('[data-a="ag-pol"]').forEach(x => body[x.dataset.k] = x.checked); await post('/api/agent/policy', body, 'Saved'); return load('agent', '/api/agent'); }
  if (c.dataset.a === 'img-inc') { const l = c.dataset.v, inc = new Set(F.backup.inc); c.checked ? inc.add(l) : inc.delete(l); F.backup.inc = [...inc]; if (inc.has(F.backup.target)) F.backup.target = ''; return renderView(); }
  if (c.dataset.a === 'img-target') { F.backup.target = c.dataset.v; return renderView(); }
  if (c.dataset.a === 'ui-tab') { const h = new Set(UIS.hidden); c.checked ? h.delete(c.dataset.id) : h.add(c.dataset.id); return saveUi({hidden: [...h]}); }
  if (c.dataset.a === 'sys') { F.running.sys = c.checked; return refreshApps(); }
  if (c.dataset.a === 'flag') { await post(`/api/app/${c.dataset.id}/set`, {[c.dataset.k]: c.checked}); return refreshApps(); }
  if (c.dataset.a === 'startup') {
    const j = await post(`/api/startup/${c.dataset.id}/toggle`, {enabled: c.checked});
    if (!j) c.checked = !c.checked; else { const e = D.startup.items.find(x => x.id === c.dataset.id); if (e) e.enabled = c.checked; toast(c.checked ? 'Will start with Windows' : 'Won\'t start with Windows'); }
  }
});
document.addEventListener('input', ev => {
  const c = ev.target;
  if (c.id === 'gs') return gsRun(c.value);
  if (c.dataset.f && c.type === 'search') { setPath(c.dataset.f, c.value); if (!/^(tools|backup|hub)\./.test(c.dataset.f)) renderView(); }
});
document.addEventListener('keydown', ev => { if (ev.key === 'Escape') $('#drawer').hidden = true; });

/* ---------- start ---------- */
(async function init() {
  let S = null;
  try { S = await api('/api/session'); } catch (e) {}
  if (S && !S.user) return showLogin();
  if (S) ME = Object.assign({username: null, admin: false, open: false, access: {}}, S.user);
  try { META = await api('/api/meta'); } catch (e) {}
  applyRole();
  try { UIS = await api('/api/ui'); applyTheme(); } catch (e) {}
  render(); enter(); pollJobs();
  setInterval(() => { if (!document.hidden && (tab === 'settings' || tab === 'link') && ME.admin && D.agent?.enrolled && !document.activeElement?.matches('input')) load('agent', '/api/agent'); }, 6000);
  setInterval(() => { if (!document.hidden && tab === 'myapps' && !document.activeElement?.matches('input[type=search]')) refreshApps(); }, 3000);
})();
