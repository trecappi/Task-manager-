#!/usr/bin/env python3
"""
App Manager (the User app)
==========================
A local dashboard for managing the programs and hardware of this PC.
Double-click this file (or "Start App Manager.bat") to run it.

Standard library only (Python 3.8+). Windows first; other systems get a limited
test mode so the program can be developed anywhere.

  * Runs a small web server on this computer only (127.0.0.1) and opens it in
    your browser. Nothing is reachable from the network.
  * Windows Firewall, uninstalling and startup changes need Administrator
    rights, so the app asks Windows for permission once when it starts.
  * Can optionally be managed by an App Manager Hub (Settings, "Managed by a hub").

Options (all optional)
  --port N        change the port (default 8765)
  --no-browser    do not open the browser
  --background    start quietly (used by "Start with Windows")
  --no-elevate    do not ask for Administrator rights
  --reset-logins  switch technician sign-in off again (use if the administrator password is lost)
"""

import os
import sys
from pathlib import Path

os.environ["APPMGR_ROLE"] = "user"
sys.path.insert(0, str(Path(__file__).resolve().parent))

# pythonw has no console: make stray prints harmless.
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

from am import launcher                                       # noqa: E402

if __name__ == "__main__":
    launcher.main()
