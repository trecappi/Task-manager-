"""Look and feel settings (theme, simple/technician mode, tab order) and global search."""

import json

from . import accounts, core
from .core import ApiError, route

FILE = core.HOME / "ui.json"
ALL_TABS = ["overview", "programs", "myapps", "startup", "updates", "install", "tweaks", "security", "monitor",
            "tools", "profiles", "hub", "backup", "devices", "activity", "settings"]
HUB_TABS = ["hub", "profiles", "activity", "settings"]                 # the Hub app has only these
CLIENT_TABS = ["remote", "link"]                                       # the Client app has only these
TABS = HUB_TABS if core.ROLE == "hub" else CLIENT_TABS if core.ROLE == "client" else [t for t in ALL_TABS if t != "hub"]
DEFAULT = {"theme": "auto", "mode": "technician", "order": TABS, "hidden": []}
SIMPLE_HIDDEN = [] if core.ROLE != "user" else ["monitor", "tools", "profiles", "backup", "activity"]


def load():
    try:
        d = json.loads(FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        d = {}
    out = dict(DEFAULT, **{k: v for k, v in d.items() if k in DEFAULT})
    order = [t for t in out["order"] if t in TABS]
    out["order"] = order + [t for t in TABS if t not in order]       # new tabs appear automatically
    out["hidden"] = [t for t in out["hidden"] if t in TABS and t != "settings"]
    if out["theme"] not in ("auto", "light", "dark"):
        out["theme"] = "auto"
    if out["mode"] not in ("simple", "technician"):
        out["mode"] = "technician"
    return out


@route("GET", r"/api/ui")
def r_get(req):
    return dict(load(), simple_hidden=SIMPLE_HIDDEN)


@route("POST", r"/api/ui")
def r_set(req):
    cur = load()
    b = req.body
    if b.get("theme") in ("auto", "light", "dark"):
        cur["theme"] = b["theme"]
    if b.get("mode") in ("simple", "technician"):
        cur["mode"] = b["mode"]
    if "order" in b and isinstance(b["order"], list):
        cur["order"] = [t for t in b["order"] if t in TABS]
    if "hidden" in b and isinstance(b["hidden"], list):
        cur["hidden"] = [t for t in b["hidden"] if t in TABS]
    if "hidden" in b or "order" in b or "mode" in b:
        cur["hidden"] = [t for t in cur["hidden"] if t != "settings"]
    FILE.write_text(json.dumps(cur), encoding="utf-8")
    return dict(load(), simple_hidden=SIMPLE_HIDDEN)


# --------------------------------------------------------------------------
# Global search: looks only at data that is already loaded or static, so it is instant
# --------------------------------------------------------------------------

_TOOLS = [("Cleanup", "tools:cleanup"), ("Large files", "tools:large"), ("Duplicate files", "tools:dups"),
          ("Error log", "tools:events"), ("Network tools: ping, DNS, port", "tools:network"),
          ("Repair Windows: SFC, DISM", "tools:repair"), ("PC health report", "tools:report"),
          ("Remote support: AnyDesk, UltraViewer, AnyViewer, Remote Utilities", "tools:remote"),
          ("Driver check", "updates:drivers"), ("Restore points", "backup"), ("Export settings", "backup"),
          ("Theme: dark or light", "settings")]


@route("GET", r"/api/search")
def r_search(req):
    q = (req.query.get("q") or "").strip().lower()
    if len(q) < 2:
        return {"items": []}
    out = []
    user = core.CTX.user                      # None only for internal calls; the server always sets it
    restrict = user is not None and not user.get("admin")

    def add(kind, title, sub, go):
        if q in (title + " " + sub).lower() and len(out) < 40 and (
                not restrict or go.split(":")[0] == "settings" or accounts.can(user, go.split(":")[0])):
            out.append({"kind": kind, "title": title, "sub": sub, "go": go})
    if core.ROLE == "hub":
        from . import hub, profiles
        for p in profiles.all_profiles():
            add("Profile", p["name"], p.get("desc", ""), "profiles")
        for d in hub.DB["devices"].values():
            add("Device", d["name"], d.get("ip", ""), "hub")
        add("Settings", "Theme: dark or light", "", "settings")
        add("Settings", "Technician accounts", "sign-in access", "settings")
        return {"items": out}
    from . import hardware, installer, programs, security, startup, tweaks
    for t in tweaks.TWEAKS:
        add("Tweak", t["name"], t["desc"], "tweaks")
    for i in security.ITEMS:
        add("Security", i["name"], i["desc"], "security")
    for c, items in installer.CATALOG.items():
        for pid, name, desc in items:
            add("Install", name, desc, "install")
    for n, go in _TOOLS:
        add("Tool", n, "", go)
    for e in (startup.STARTUP.peek() or []):
        add("Startup", e["name"], e["command"], "startup")
    for p in (programs.INVENTORY.peek() or []):
        add("Program", p["name"], p.get("publisher") or "", "programs")
    for d in (hardware.DEVICES.peek() or []):
        add("Device", d["name"], d["cls"], "devices:tree")
    return {"items": out}
