"""Device doctor: for a device Windows reports a problem with, run diagnostics, try the
safe fixes, and say plainly what worked.

Level "safe": enable if turned off, restart the device, rescan for hardware changes.
Level "reinstall": the above, plus remove the device and let Windows detect and install it
again (a restore point is created first). Drivers are never downloaded here; if nothing
works, the log links to the Microsoft Update Catalog and the Driver check.
"""

import re
import time
import urllib.parse

from . import core, hardware
from .core import IS_WIN, ApiError, activity, route

_HINTS = {
    1: "Windows could not finish setting it up. Usually a driver problem.",
    3: "Often a damaged driver or low memory. Restarting the device or the PC usually clears it.",
    10: "The device could not start. The driver may be the wrong one or the hardware may be unplugged or faulty.",
    12: "Two devices are fighting over the same resources. Rare on modern PCs.",
    14: "Windows needs a restart before this device works.",
    18: "The drivers need to be reinstalled.",
    19: "Windows' settings for this device are damaged. Reinstalling the device usually fixes it.",
    24: "The device is not present or not working. Check the cable or plug.",
    28: "No driver is installed. Windows could not find one by itself.",
    31: "Windows cannot load a working driver for it.",
    32: "The driver is turned off.",
    37: "The driver failed to start.",
    39: "The driver is damaged or missing.",
    43: "Windows stopped the device because it reported a problem. Often a hardware or power issue.",
    52: "The driver is not digitally signed, so Windows refuses it.",
}
FAKE_FIXES = {"safe": {22, 10, 43, 37, 3, 1}, "reinstall": {28, 39, 18, 31, 19, 32, 52}}


def _devices():
    snap = hardware.DEVICES.get()
    return snap["data"] or []


def _find(dev_id):
    for d in _devices():
        if d["id"] == dev_id:
            return d
    raise ApiError("That device is no longer in the list. Refresh and try again.")


def _read_code(dev):
    """Current problem code of the device (re-read from Windows)."""
    if not IS_WIN:
        from . import fake
        return 0 if dev["id"] in fake.FIXED else dev["code"]
    rows = core.ps_json("Get-CimInstance Win32_PnPEntity | Where-Object { $_.DeviceID -eq "
                        + core.ps_quote(dev["id"]) + " } | ForEach-Object { [pscustomobject]@{ code=[int]$_.ConfigManagerErrorCode } }"
                        " | ConvertTo-Json -Compress", timeout=60)
    return int(rows[0]["code"]) if rows else -1       # -1: the device vanished (normal after a removal)


def _pnputil(job, *args):
    r = core.run(["pnputil", *args], timeout=120)
    out = (r.stdout or r.stderr or "").strip().splitlines()
    if out:
        job.log("   " + out[-1][:140])
    return r.returncode == 0


def _step_enable(job, dev):
    job.log("Step: turning the device on…")
    if not IS_WIN:
        return True
    if _pnputil(job, "/enable-device", dev["id"]):
        return True
    try:
        core.ps("Enable-PnpDevice -InstanceId " + core.ps_quote(dev["id"]) + " -Confirm:$false -ErrorAction Stop")
        return True
    except Exception as e:
        job.log(f"   could not enable it: {str(e)[:100]}")
        return False


def _step_restart(job, dev):
    job.log("Step: restarting the device…")
    if not IS_WIN:
        time.sleep(0.6)
        return True
    if _pnputil(job, "/restart-device", dev["id"]):
        return True
    try:                                                  # older Windows 10 has no /restart-device
        core.ps("$i=" + core.ps_quote(dev["id"]) + "; Disable-PnpDevice -InstanceId $i -Confirm:$false -ErrorAction Stop; "
                "Start-Sleep 2; Enable-PnpDevice -InstanceId $i -Confirm:$false -ErrorAction Stop", timeout=90)
        return True
    except Exception as e:
        job.log(f"   could not restart it: {str(e)[:100]}")
        return False


def _step_rescan(job):
    job.log("Step: asking Windows to look for hardware changes…")
    if not IS_WIN:
        time.sleep(0.6)
        return
    _pnputil(job, "/scan-devices")
    time.sleep(3)


def _step_reinstall(job, dev):
    job.log("Step: removing the device so Windows can set it up again…")
    if not IS_WIN:
        time.sleep(0.8)
        return True
    ok = _pnputil(job, "/remove-device", dev["id"])
    time.sleep(2)
    _step_rescan(job)
    time.sleep(4)
    return ok


def diagnose_and_fix(job, dev, level):
    from . import fake
    job.log(f"=== {dev['name']} ===")
    code = _read_code(dev)
    drv = next((d for d in (hardware.DRIVERS.get()["data"] or []) if d["id"] == dev["id"]), None)
    job.log(f"Problem: {dev['problem'] or 'turned off'} (code {dev['code']})")
    if drv:
        job.log(f"Driver: {drv['provider'] or 'unknown'} {drv['version']} from {drv['date'] or 'unknown date'}"
                f"{'' if drv['signed'] else ', NOT signed'}")
    else:
        job.log("Driver: none is installed for this device.")
    if dev["code"] in _HINTS:
        job.log(f"Meaning: {_HINTS[dev['code']]}")
    if code == 0:
        job.log("Result: it is working now. Nothing to do.")
        return "fixed"
    if code in (24, 45) or not dev["present"]:
        job.log("Result: the device is not connected. Plug it in and check the cable; software cannot fix this.")
        return "unplugged"
    if code == 14:
        job.log("Result: Windows needs a restart for this device. Restart the PC.")
        return "restart"

    attempts = [("safe", lambda: (_step_enable(job, dev) if code == 22 else True) and _step_restart(job, dev) and (_step_rescan(job) or True))]
    if level == "reinstall":
        if not core.is_admin() and IS_WIN:
            raise ApiError("Reinstalling needs administrator permission. Close App Manager and open it again, choosing Yes.")
        job.log("Creating a restore point first…")
        from . import winsys
        job.log("Restore point created." if winsys.restore_point(f"Before reinstalling {dev['name'][:40]}")
                else "Windows would not make a restore point (it may be switched off). Continuing.")
        attempts.append(("reinstall", lambda: _step_reinstall(job, dev)))
    for name, fn in attempts:
        try:
            fn()
        except Exception as e:
            job.log(f"   step failed: {str(e)[:120]}")
        if not IS_WIN and dev["code"] in FAKE_FIXES[name]:
            fake.FIXED.add(dev["id"])
        after = _read_code(dev)
        if after == 0:
            job.log(f"Result: FIXED. The device is working ({'restart' if name == 'safe' else 'reinstall'} did it).")
            activity("device fix", dev["name"], "ok", name)
            return "fixed"
        job.log(f"Still not working after the {name} steps (code {after}).")
    ids = ""
    try:
        from . import drivercheck
        ids = next((h for dd in drivercheck.local_drivers() if dd["name"] == dev["name"] for h in dd["hwids"]), "")
    except Exception:
        pass
    q = urllib.parse.quote(ids or dev["name"])
    job.log("Result: not fixed automatically.")
    job.log("Next: look for a driver in the Microsoft Update Catalog:")
    job.log(f"   https://www.catalog.update.microsoft.com/Search.aspx?q={q}")
    job.log("or use Updates → Drivers → Check, or the PC maker's support page." +
            ("" if level == "reinstall" else " You can also try 'Fix and reinstall'."))
    activity("device fix", dev["name"], "failed", level)
    return "failed"


def _job(job, dev_ids, level):
    results = []
    for did in dev_ids:
        try:
            results.append(diagnose_and_fix(job, _find(did), level))
        except ApiError as e:
            job.log(f"{e.msg}")
            results.append("failed")
    hardware.DEVICES.get(force=True)
    fixed = results.count("fixed")
    return f"{fixed} of {len(results)} fixed" + ("; restart the PC for the rest" if "restart" in results else "")


@route("POST", r"/api/devices/fix")
def r_fix(req):
    b = req.body
    if b.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    dev = _find(str(b.get("id", "")))
    level = "reinstall" if b.get("level") == "reinstall" else "safe"
    return {"job": core.start_job(f"Fix device: {dev['name'][:40]}", _job, [dev["id"]], level).id}


@route("POST", r"/api/devices/fixall")
def r_fixall(req):
    if req.body.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    ids = [d["id"] for d in _devices() if d["problem"] and d["present"]][:15]
    if not ids:
        raise ApiError("No devices have problems.")
    return {"job": core.start_job(f"Fix {len(ids)} devices", _job, ids, "safe").id}
