"""Backup and recovery: restore points, settings export/import, driver backup, and a
one-click "undo everything App Manager changed"."""

import base64
import io
import json
import os
import re
import shutil
import subprocess
import time
import zipfile

from . import core, security, tweaks, winsys
from .core import IS_WIN, ApiError, Lazy, activity, route

# Files that make up "my App Manager setup". Undo snapshots are machine-specific, so they are not exported.
SETTINGS_FILES = ["gui.json", "ui.json", "install_custom.json", "profiles.json"]
MAX_IMPORT = 5_000_000


# --------------------------------------------------------------------------
# Restore points
# --------------------------------------------------------------------------

_RP_PS = ("Get-ComputerRestorePoint | ForEach-Object { [pscustomobject]@{ seq=$_.SequenceNumber; desc=$_.Description; "
          "t=$_.ConvertToDateTime($_.CreationTime).ToString('yyyy-MM-dd HH:mm'); type=[int]$_.RestorePointType } } "
          "| ConvertTo-Json -Compress")


def _restore_points():
    if IS_WIN:
        rows = core.ps_json(_RP_PS, timeout=60)
    else:
        rows = [{"seq": 3, "desc": "App Manager restore point", "t": "2026-10-22 18:00", "type": 12},
                {"seq": 2, "desc": "Windows Update", "t": "2026-10-15 03:10", "type": 0}]
    return sorted(rows, key=lambda r: r["t"], reverse=True)


RESTORE = Lazy(_restore_points, ttl=120)


def _changes():
    snap = tweaks._snapshot()
    sec = security._undo_load()
    return {"tweaks": [{"id": t, "name": tweaks.BY_ID[t]["name"], "when": r.get("when", "")}
                       for t, r in snap.items() if t in tweaks.BY_ID],
            "security": [{"id": i, "name": security.BY_ID[i]["name"], "when": r.get("when", "")}
                         for i, r in sec.items() if i in security.BY_ID]}


@route("GET", r"/api/backup")
def r_state(req):
    rp = RESTORE.get(force="refresh" in req.query)
    if "refresh" in req.query:
        VOLUMES.get(force=True)
    img = _image_state()
    files = [{"name": n, "exists": (core.HOME / n).exists()} for n in SETTINGS_FILES]
    return {"loading": rp["loading"] or img["loading"], "restore": {"loading": rp["loading"], "ready": rp["ready"], "error": rp["error"], "items": rp["data"] or []},
            "changes": _changes(), "files": files, "driver_dir": str(core.HOME / "driver_backup"),
            "image": img}


def _rp_job(job):
    job.log("Asking Windows for a restore point…")
    if not winsys.restore_point("App Manager restore point"):
        raise ApiError("Windows would not create one. System Protection may be off for the system drive, "
                       "or Windows already made one in the last 24 hours (it limits how often).")
    RESTORE.get(force=True)
    activity("restore point", "", "ok")
    return "Restore point created"


@route("POST", r"/api/backup/restorepoint")
def r_rp(req):
    if req.body.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    return {"job": core.start_job("Create restore point", _rp_job).id}


@route("POST", r"/api/backup/opensysrestore")
def r_open_sr(req):
    if not IS_WIN:
        return {"ok": True}
    os.startfile("rstrui.exe")                                  # noqa: S606
    return {"ok": True}


# --------------------------------------------------------------------------
# Undo everything App Manager changed
# --------------------------------------------------------------------------

def _undo_job(job):
    ch = _changes()
    n = 0
    if ch["tweaks"]:
        job.log(f"=== Tweaks ({len(ch['tweaks'])}) ===")
        job.log(tweaks._job_undo(job, [t["id"] for t in ch["tweaks"]]))
        n += len(ch["tweaks"])
    for s in ch["security"]:
        job.log(f"Restoring: {s['name']}")
        try:
            security.restore(s["id"])
            n += 1
        except ApiError as e:
            job.log(f"   {e.msg}")
    activity("undo everything", "", "ok", f"{n} items")
    return f"{n} settings put back" if n else "Nothing to undo"


@route("POST", r"/api/backup/undoall")
def r_undoall(req):
    if req.body.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    ch = _changes()
    if not ch["tweaks"] and not ch["security"]:
        raise ApiError("App Manager has not changed any settings, so there is nothing to undo.")
    return {"job": core.start_job("Undo everything App Manager changed", _undo_job).id}


# --------------------------------------------------------------------------
# Settings export / import
# --------------------------------------------------------------------------

@route("GET", r"/api/backup/export")
def r_export(req):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps({"app": "appmanager-settings", "version": core.VERSION,
                                                "created": time.strftime("%Y-%m-%d %H:%M")}))
        for name in SETTINGS_FILES:
            p = core.HOME / name
            if p.exists():
                z.write(p, name)
    activity("export settings")
    return core.Raw(buf.getvalue(), "application/zip",
                    {"Content-Disposition": f'attachment; filename="appmanager-settings-{time.strftime("%Y%m%d")}.zip"'})


@route("POST", r"/api/backup/import")
def r_import(req):
    if req.body.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    try:
        raw = base64.b64decode(str(req.body.get("data", "")), validate=True)
    except Exception:
        raise ApiError("That file could not be read.")
    if len(raw) > MAX_IMPORT:
        raise ApiError("That file is too large to be an App Manager backup.")
    try:
        z = zipfile.ZipFile(io.BytesIO(raw))
        man = json.loads(z.read("manifest.json"))
    except Exception:
        raise ApiError("That is not an App Manager settings backup.")
    if man.get("app") != "appmanager-settings":
        raise ApiError("That is not an App Manager settings backup.")
    incoming = {}
    for name in SETTINGS_FILES:                                 # only known files, only valid JSON
        if name in z.namelist():
            info = z.getinfo(name)
            if info.file_size > MAX_IMPORT:
                raise ApiError(f"{name} in the backup is too large.")
            try:
                incoming[name] = json.loads(z.read(name))
            except ValueError:
                raise ApiError(f"{name} in the backup is damaged.")
    if not incoming:
        raise ApiError("That backup has no settings in it.")
    keep = core.HOME / ("before_import_" + time.strftime("%Y%m%d_%H%M%S"))
    keep.mkdir(exist_ok=True)
    for name, data in incoming.items():
        src = core.HOME / name
        if src.exists():
            shutil.copy2(src, keep / name)
        src.write_text(json.dumps(data, indent=1), encoding="utf-8")
    activity("import settings", ", ".join(incoming))
    return {"restored": sorted(incoming), "kept_old_in": str(keep)}


# --------------------------------------------------------------------------
# Driver backup
# --------------------------------------------------------------------------

def _drivers_job(job, folder):
    folder = os.path.abspath(folder)
    os.makedirs(folder, exist_ok=True)
    job.log(f"Saving third-party drivers to {folder} …")
    if not IS_WIN:
        time.sleep(0.8)
        with open(os.path.join(folder, "demo-driver.inf"), "w") as f:
            f.write("; test mode")
        job.log("Test mode: wrote a sample file only.")
        return "Saved 1 driver package (test mode)"
    r = core.run(["pnputil", "/export-driver", "*", folder], timeout=900)
    for line in (r.stdout or r.stderr or "").splitlines()[-8:]:
        job.log(line)
    if r.returncode != 0:
        raise ApiError("Windows could not export the drivers. This needs administrator permission.")
    n = sum(1 for d in os.listdir(folder) if os.path.isdir(os.path.join(folder, d)))
    size = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(folder) for f in fs)
    activity("driver backup", folder, "ok", f"{n} packages")
    return f"Saved {n} driver packages ({size / 1048576:.0f} MB)"


@route("POST", r"/api/backup/drivers")
def r_drivers(req):
    if req.body.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    folder = str(req.body.get("folder", "")).strip() or str(core.HOME / "driver_backup" / time.strftime("%Y%m%d"))
    if not os.path.isabs(folder) or re.search(r'[<>"|?*]', folder):
        raise ApiError("Type a full folder path such as D:\\DriverBackup.")
    if IS_WIN and not core.is_admin():
        raise ApiError("Exporting drivers needs administrator permission. Close App Manager and open it again, choosing Yes.")
    return {"job": core.start_job("Back up drivers", _drivers_job, folder).id}


# --------------------------------------------------------------------------
# Full system image (Windows' own wbadmin tool: the whole drive, bootable recovery)
# --------------------------------------------------------------------------

_VOL_PS = r"""
$sys=$env:SystemDrive.TrimEnd(':')
$r=@()
foreach($v in (Get-Volume | Where-Object { $_.DriveLetter })){
  $disk=$null; try{ $disk=(Get-Partition -DriveLetter $v.DriveLetter).DiskNumber }catch{}
  $img=@()
  $root=($v.DriveLetter+':\WindowsImageBackup')
  if(Test-Path $root){ Get-ChildItem $root -Directory -ErrorAction SilentlyContinue | ForEach-Object { $pc=$_.Name
    Get-ChildItem $_.FullName -Directory -Filter 'Backup *' -ErrorAction SilentlyContinue | ForEach-Object { $img += @{ pc=$pc; name=$_.Name; t=$_.LastWriteTime.ToString('yyyy-MM-dd HH:mm') } } } }
  $r += @{ letter=[string]$v.DriveLetter; label=$v.FileSystemLabel; fs=$v.FileSystem; type=[string]$v.DriveType;
           size=[int64]$v.Size; free=[int64]$v.SizeRemaining; disk=$disk; system=([string]$v.DriveLetter -eq $sys); images=$img }
}
$r | ConvertTo-Json -Depth 5 -Compress
"""

_GB = 1 << 30


def _volumes():
    if IS_WIN:
        rows = core.ps_json(_VOL_PS, timeout=60)
    else:
        rows = [{"letter": "C", "label": "Windows", "fs": "NTFS", "type": "Fixed", "size": 476 * _GB, "free": 260 * _GB,
                 "disk": 0, "system": True, "images": []},
                {"letter": "D", "label": "Data", "fs": "NTFS", "type": "Fixed", "size": 931 * _GB, "free": 700 * _GB,
                 "disk": 1, "system": False, "images": []},
                {"letter": "E", "label": "Backup USB", "fs": "NTFS", "type": "Removable", "size": 1862 * _GB,
                 "free": 1500 * _GB, "disk": 2, "system": False,
                 "images": [{"pc": "DEMO-PC", "name": "Backup 2026-10-01 020000", "t": "2026-10-01 02:03"}]},
                {"letter": "F", "label": "Tiny stick", "fs": "FAT32", "type": "Removable", "size": 16 * _GB,
                 "free": 15 * _GB, "disk": 3, "system": False, "images": []}]
    out = []
    for r in rows:
        if (r.get("type") or "") in ("CD-ROM", "Unknown") or not r.get("size"):
            continue
        r["letter"] = str(r["letter"]).upper()
        r["images"] = sorted(r.get("images") or [], key=lambda i: i["t"], reverse=True)[:6]
        out.append(r)
    return sorted(out, key=lambda r: r["letter"])


VOLUMES = Lazy(_volumes, ttl=60)
IMAGE = {"job": None}
_TARGET_DRIVE = re.compile(r"[A-Za-z]:")
_TARGET_UNC = re.compile(r"\\\\[A-Za-z0-9._-]{1,63}\\[A-Za-z0-9._$ -]{1,80}")


def _image_state():
    v = VOLUMES.get()
    job = core.JOBS.get(IMAGE["job"] or "")
    return {"loading": v["loading"] and not v["ready"], "error": v["error"], "volumes": v["data"] or [],
            "wbadmin": bool(IS_WIN is False or shutil.which("wbadmin")), "admin": core.is_admin() or not IS_WIN,
            "running": bool(job and job.status == "running")}


def _image_cmd(target, include):
    return ["wbadmin", "start", "backup", f"-backupTarget:{target}",
            "-include:" + ",".join(f"{l}:" for l in include), "-allCritical", "-quiet"]


def plan_image(target, include):
    """Validate a request and return (target, include letters, estimated bytes). Raises ApiError."""
    vols = {v["letter"]: v for v in (VOLUMES.peek() or _volumes())}
    system = next((v for v in vols.values() if v["system"]), None)
    if not system:
        raise ApiError("Could not find the Windows drive.")
    target = str(target or "").strip()
    unc = bool(_TARGET_UNC.fullmatch(target))
    if not unc:
        if not _TARGET_DRIVE.fullmatch(target):
            raise ApiError("Choose a drive, or type a network folder such as \\\\server\\backups.")
        target = target.upper()
    letters = [system["letter"]]
    for l in include or []:
        l = str(l).upper()
        if l in vols and vols[l].get("type") == "Fixed" and l not in letters:
            letters.append(l)
    if not unc:
        t = vols.get(target[0])
        if not t:
            raise ApiError("That drive was not found. Plug it in and press Refresh.")
        if target[0] in letters:
            raise ApiError("The image cannot be saved on a drive it is copying. Choose a different drive.")
        if t.get("fs") != "NTFS":
            raise ApiError(f"Drive {target[0]}: is formatted as {t.get('fs') or 'unknown'}. Windows needs an NTFS drive for system images.")
    need = sum(vols[l]["size"] - vols[l]["free"] for l in letters)
    if not unc and vols[target[0]]["free"] < need:
        raise ApiError(f"Drive {target[0]}: has {vols[target[0]]['free'] / _GB:.0f} GB free but the image needs about "
                       f"{need / _GB:.0f} GB. Choose a bigger drive or copy fewer drives.")
    return target, letters, need


def _image_job(job, target, include):
    cmd = _image_cmd(target, include)
    job.log(f"Saving a full system image of {', '.join(l + ':' for l in include)} to {target}")
    job.log("This can take an hour or more. You can keep using the PC, but it will be slower.")
    if not IS_WIN:
        for pct in (5, 25, 50, 75, 100):
            time.sleep(0.4)
            job.log(f"Backup of volume ({include[0]}:) {pct}% completed")
        activity("system image", target, "ok", "test mode")
        return "System image saved (test mode: nothing was written)"
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=core.NO_WINDOW)
    tail, last_pct, buf = [], -10, b""
    while True:
        chunk = proc.stdout.read(256)
        if not chunk:
            break
        buf += chunk
        parts = re.split(rb"[\r\n]+", buf)
        buf = parts.pop()
        for raw in parts:
            line = raw.decode("oem", "replace").strip()
            if not line:
                continue
            m = re.search(r"(\d{1,3})\s*%", line)
            if m:                                           # progress: log every 5%, not every tick
                pct = int(m.group(1))
                if pct < last_pct + 5 and pct != 100:
                    continue
                last_pct = pct
            tail = (tail + [line])[-12:]
            job.log(line)
    code = proc.wait()
    if code != 0:
        activity("system image", target, "failed", " | ".join(tail[-2:])[:200])
        raise ApiError("Windows could not finish the image. " + (tail[-1] if tail else f"(exit code {code})"))
    VOLUMES.get(force=True)
    activity("system image", target, "ok", ", ".join(l + ":" for l in include))
    return "System image saved to " + target


@route("POST", r"/api/backup/image")
def r_image(req):
    b = req.body
    if b.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    if IS_WIN and not shutil.which("wbadmin"):
        raise ApiError("This edition of Windows does not include the wbadmin tool, so it cannot make a system image.")
    if IS_WIN and not core.is_admin():
        raise ApiError("A system image needs administrator permission. Close App Manager and open it again, choosing Yes.")
    job = core.JOBS.get(IMAGE["job"] or "")
    if job and job.status == "running":
        raise ApiError("A system image is already being made.")
    target, include, need = plan_image(b.get("target"), b.get("include"))
    j = core.start_job("Full system image", _image_job, target, include)
    IMAGE["job"] = j.id
    return {"job": j.id, "estimate": need}


@route("POST", r"/api/backup/image/stop")
def r_image_stop(req):
    job = core.JOBS.get(IMAGE["job"] or "")
    if not (job and job.status == "running"):
        raise ApiError("No system image is being made right now.")
    if IS_WIN:
        core.run(["wbadmin", "stop", "job", "-quiet"], timeout=60)
    else:
        job.log("Stop requested (test mode).")
    activity("stop system image")
    return {"ok": True}
