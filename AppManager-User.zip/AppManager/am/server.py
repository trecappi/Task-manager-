"""Local web server. Listens on 127.0.0.1 only and checks a secret on every request."""

import json
import secrets
import urllib.request
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import accounts, core
from .core import ApiError

STATE = {"port": 8765, "token": ""}


def cname(base):
    """Cookie names carry the port: browsers share cookies between 127.0.0.1 ports, so two App Manager apps
    running on one PC (say the Hub and the Client) would otherwise keep logging each other out."""
    return f"{base}{STATE['port']}"

STATIC = {"/static/app.css": ("app.css", "text/css; charset=utf-8"),
          "/static/app.js": ("app.js", "application/javascript; charset=utf-8")}

LOCKED_HTML = f"""<!doctype html><meta charset=utf-8><title>{core.PRODUCT}</title>
<body style="font:16px system-ui;max-width:32rem;margin:4rem auto;padding:0 1rem">
<h2>{core.PRODUCT}</h2><p>This page can only be opened from {core.PRODUCT} itself.
Open the <b>{core.PRODUCT}</b> shortcut (or run {core.ENTRY}) and it will open here.</p>"""


class Handler(BaseHTTPRequestHandler):
    server_version = "AppManager"

    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json", headers=None):
        data = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def json(self, obj, code=200):
        self.send(code, json.dumps(obj))

    def host_ok(self):
        p = STATE["port"]
        return self.headers.get("Host", "").lower() in (f"127.0.0.1:{p}", f"localhost:{p}")

    def authed(self):
        c = SimpleCookie(self.headers.get("Cookie", ""))
        n = cname("am_")
        return n in c and secrets.compare_digest(c[n].value, STATE["token"])

    def session_id(self):
        c = SimpleCookie(self.headers.get("Cookie", ""))
        n = cname("ams_")
        return c[n].value if n in c else ""

    def respond(self, result):
        if isinstance(result, core.Raw):
            return self.send(result.code, result.body, result.ctype, result.headers)
        return self.json(result)

    def handle_api(self, method, path, query, body):
        core.CTX.user = None
        try:
            user = accounts.current(self.session_id())
            launcher = secrets.compare_digest(self.headers.get("X-AppMgr-Launcher", ""),
                                              accounts.launcher_proof(STATE["token"]))
            accounts.gate(method, path, user, launcher)
            core.CTX.user = user
            found, result = core.dispatch(method, path, query, body)
        except ApiError as e:
            payload = {"error": e.msg}
            if e.confirm:
                payload["confirm"] = e.confirm
            return self.json(payload, e.code)
        except Exception as e:
            core.log(f"error on {method} {path}: {e!r}")
            return self.json({"error": f"Something went wrong: {e}"}, 500)
        finally:
            core.CTX.user = None
        if not found:
            return self.send(404, "Not found", "text/plain")
        if isinstance(result, dict) and "_session" in result:        # sign-in / sign-out sets the session cookie
            sid = result.pop("_session")
            cookie = (f"{cname('ams_')}={sid}; HttpOnly; SameSite=Strict; Path=/" if sid
                      else f"{cname('ams_')}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0")
            return self.send(200, json.dumps(result), "application/json", {"Set-Cookie": cookie})
        return self.respond(result)

    def do_GET(self):
        if not self.host_ok():
            return self.send(403, "Forbidden", "text/plain")
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query, keep_blank_values=True).items()}
        if u.path == "/api/ping":
            return self.json({"ok": True, "app": core.APP_ID, "version": core.VERSION})
        if u.path == "/" and "t" in q and secrets.compare_digest(q["t"], STATE["token"]):
            return self.send(302, "", "text/plain", {
                "Location": "/",
                "Set-Cookie": f"{cname('am_')}={STATE['token']}; HttpOnly; SameSite=Strict; Path=/"})
        if not self.authed():
            return self.send(403, LOCKED_HTML, "text/html; charset=utf-8")
        if u.path == "/":
            return self.send(200, (core.WEB / "index.html").read_bytes(),
                             "text/html; charset=utf-8")
        if u.path in STATIC:
            name, ctype = STATIC[u.path]
            return self.send(200, (core.WEB / name).read_bytes(), ctype)
        if u.path.startswith("/api/"):
            return self.handle_api("GET", u.path, q, {})
        self.send(404, "Not found", "text/plain")

    def do_POST(self):
        if not (self.host_ok() and self.authed() and self.headers.get("X-AppMgr") == "1"):
            return self.send(403, "Forbidden", "text/plain")
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(min(n, 1_000_000)) or b"{}")
        except (ValueError, json.JSONDecodeError):
            return self.json({"error": "Bad request"}, 400)
        self.handle_api("POST", urlparse(self.path).path, {}, body)


def ping_info(port):
    """None if nothing of ours is listening, else the running version ('' if it is too old to say)."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping", timeout=1.5) as r:
            d = json.loads(r.read())
        return d.get("version", "") if d.get("app") == core.APP_ID else None
    except Exception:
        return None


def ping(port):
    return ping_info(port) is not None


def stop_old(port, token):
    """Ask an older App Manager on this port to quit, and wait for the port to free up."""
    import time
    req = urllib.request.Request(f"http://127.0.0.1:{port}/api/quit", data=b"{}", method="POST", headers={
        "X-AppMgr": "1", "Content-Type": "application/json", "Cookie": f"am={token}",
        "X-AppMgr-Launcher": accounts.launcher_proof(token)})
    try:
        urllib.request.urlopen(req, timeout=3).read()
    except Exception:
        pass
    for _ in range(30):
        if ping_info(port) is None:
            return True
        time.sleep(0.2)
    return False


def make_server(port, token):
    STATE["port"], STATE["token"] = port, token
    return ThreadingHTTPServer(("127.0.0.1", port), Handler)
