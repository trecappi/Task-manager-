"""The small signed protocol between a managed device (controller) and its hub.

Nothing secret ever crosses the network:
  * Enrolling: the hub gives the technician a one-time code that holds a secret token. The device proves it
    knows the token (a keyed hash), the hub proves it too, and both derive the same long-term device key
    from the token and two fresh random numbers. The key itself is never sent.
  * Every later message is signed with that device key (HMAC-SHA256) together with a timestamp and a
    random one-time number, so nothing can be forged, altered or replayed. Replies are signed too and
    are tied to the request they answer, so a stranger on the network cannot hand a device orders.
Messages are signed but not encrypted: use a network you trust, or a VPN.
"""

import base64
import hashlib
import hmac
import json
import re
import secrets

PREFIX = "AMH1-"
HOLD = 20                                        # seconds the hub holds an idle check-in open
MAX_SKEW = 300                                   # seconds of clock difference tolerated
HOST_RX = re.compile(r"[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?")


def mac(key, *parts):
    msg = "|".join(str(p) for p in parts).encode("utf-8")
    return hmac.new(key if isinstance(key, bytes) else key.encode("utf-8"), msg, hashlib.sha256).hexdigest()


def same(a, b):
    return hmac.compare_digest(str(a), str(b))


def body_hash(raw):
    return hashlib.sha256(raw).hexdigest()


def sign_request(key, device_id, ts, nonce, raw):
    return mac(key, "req", device_id, ts, nonce, body_hash(raw))


def sign_response(key, nonce, raw):
    return mac(key, "resp", nonce, body_hash(raw))


def derive_key(secret, cn, sn):
    return mac(secret, "dk", cn, sn)


def enroll_proof(secret, cn, device_json):
    return mac(secret, "enroll", cn, device_json)


def hub_proof(secret, cn, sn, device_id):
    return mac(secret, "hub", cn, sn, device_id)


def new_token():
    """-> (token_id, secret)"""
    return secrets.token_hex(4), secrets.token_hex(16)


def encode_code(hostport, token_id, secret, hub_name=""):
    doc = {"h": hostport, "t": f"{token_id}.{secret}", "n": hub_name[:60]}
    return PREFIX + base64.urlsafe_b64encode(json.dumps(doc, separators=(",", ":")).encode()).decode().rstrip("=")


def decode_code(code):
    """-> (hostport, token_id, secret, hub_name); ValueError if it is not a valid code."""
    code = (code or "").strip()
    if not code.startswith(PREFIX):
        raise ValueError("That is not an enrollment code.")
    try:
        raw = code[len(PREFIX):]
        doc = json.loads(base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)))
        host, port = str(doc["h"]).rsplit(":", 1)
        tid, secret = str(doc["t"]).split(".", 1)
    except Exception:
        raise ValueError("That enrollment code is damaged. Copy it again in full.")
    if not (HOST_RX.fullmatch(host) and port.isdigit() and 1 <= int(port) <= 65535
            and re.fullmatch(r"[0-9a-f]{8}", tid) and re.fullmatch(r"[0-9a-f]{32}", secret)):
        raise ValueError("That enrollment code is not valid.")
    return f"{host}:{int(port)}", tid, secret, str(doc.get("n", ""))[:60]
