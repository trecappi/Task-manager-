"""Profiles: a named bundle of everything App Manager can set up on a PC.

A profile lists tweaks to apply, security protections to turn on, programs to install,
startup items to switch off and cleanup to run. Applying it does all of that in one go,
with a preview first. Technicians can build their own, duplicate the built-in ones,
capture one from the current PC, and export or import profiles as small .json files.
"""

import json
import re
import secrets
import time

from . import accounts, cleanup, core, installer, security, startup, tweaks, winsys
from .core import ApiError, activity, route

FILE = core.HOME / "profiles.json"
FORMAT = "appmanager-profile"

BUILTIN = [
    {"id": "builtin-baseline", "name": "Safe baseline", "builtin": True,
     "desc": "Sensible protection and privacy for any PC. Nothing risky.",
     "tweaks": ["ext", "adid", "tailored", "suggest", "bing", "activity", "dop2p", "remoteassist"],
     "security": [{"id": i, "mode": "on"} for i in ("cfa", "rtm", "maps", "pua", "np", "fw", "smb1")],
     "install": [], "custom_winget": [], "startup_off": [], "cleanup": ["user_temp", "thumbs"]},
    {"id": "builtin-office", "name": "Office workstation", "builtin": True,
     "desc": "Baseline plus a tidy desktop and everyday office programs.",
     "tweaks": ["ext", "adid", "tailored", "suggest", "bing", "activity", "dop2p", "remoteassist", "widgets", "sticky"],
     "security": [{"id": i, "mode": "on"} for i in ("cfa", "rtm", "maps", "pua", "np", "fw", "smb1", "uac", "autorun")],
     "install": ["Mozilla.Firefox", "7zip.7zip", "SumatraPDF.SumatraPDF", "TheDocumentFoundation.LibreOffice"],
     "custom_winget": [], "startup_off": [], "cleanup": ["user_temp"]},
    {"id": "builtin-gaming", "name": "Gaming PC", "builtin": True,
     "desc": "Frame-rate friendly settings, launchers and the runtimes games need.",
     "tweaks": ["ext", "adid", "suggest", "gamedvr", "ultimate"],
     "security": [{"id": i, "mode": "on"} for i in ("rtm", "fw", "smb1")],
     "install": ["Valve.Steam", "EpicGames.EpicGamesLauncher", "Discord.Discord", "Microsoft.VCRedist.2015+.x64",
                 "Microsoft.DotNet.DesktopRuntime.8", "OBSProject.OBSStudio"],
     "custom_winget": [], "startup_off": [], "cleanup": ["user_temp"]},
    {"id": "builtin-tech", "name": "Technician toolkit", "builtin": True,
     "desc": "Diagnostic and support programs for a technician's own PC.",
     "tweaks": ["ext", "hidden"], "security": [],
     "install": ["CPUID.CPU-Z", "CPUID.HWMonitor", "TechPowerUp.GPU-Z", "Microsoft.Sysinternals.ProcessExplorer",
                 "Microsoft.Sysinternals.Autoruns", "7zip.7zip", "voidtools.Everything", "WinDirStat.WinDirStat",
                 "Rufus.Rufus", "AnyDeskSoftwareGmbH.AnyDesk", "WiresharkFoundation.Wireshark", "PuTTY.PuTTY"],
     "custom_winget": [], "startup_off": [], "cleanup": []},
]


def _load():
    try:
        return json.loads(FILE.read_text(encoding="utf-8")).get("profiles", [])
    except (OSError, json.JSONDecodeError):
        return []


def _store(items):
    FILE.write_text(json.dumps({"profiles": items}, indent=1), encoding="utf-8")


def all_profiles():
    return BUILTIN + _load()


def find(pid):
    p = next((p for p in all_profiles() if p["id"] == pid), None)
    if not p:
        raise ApiError("That profile no longer exists.", 404)
    return p


# --------------------------------------------------------------------------
# Options the editor can offer, and validation
# --------------------------------------------------------------------------

def options():
    cats = [{"name": c, "items": [{"id": i, "name": n} for i, n, _ in items]} for c, items in installer.CATALOG.items()]
    # The hub PC's own startup list says nothing about the managed PCs, so the hub does not offer it.
    st = {"data": [], "loading": False} if core.ROLE == "hub" else startup.STARTUP.get()
    return {
        "tweaks": [{"id": t["id"], "name": t["name"], "group": t["group"]} for t in tweaks.TWEAKS],
        "security": [{"id": i["id"], "name": i["name"], "group": i["group"], "audit": bool(i.get("audit")),
                      "optional": bool(i.get("optional"))} for i in security.ITEMS if i["kind"] != "info"],
        "install": cats,
        "startup": sorted({e["name"] for e in st["data"] or []}, key=str.lower),
        "cleanup": [{"id": c["id"], "name": c["name"]} for c in cleanup._categories()],
        "startup_loading": st["loading"],
    }


SECTION_AREA = {"tweaks": "tweaks", "security": "security", "install": "install", "custom_winget": "install",
                "startup_off": "startup", "cleanup": "tools"}


def _need_areas(p):
    """A technician can only save or apply what their account is allowed to change."""
    user = core.CTX.user
    if user and not user.get("admin"):
        accounts.require_areas(user, sorted({a for k, a in SECTION_AREA.items() if p.get(k)}))


def clean(p):
    """Validate and normalise a profile coming from the browser or an imported file."""
    if not isinstance(p, dict):
        raise ApiError("That is not a profile.")
    name = str(p.get("name", "")).strip()[:60]
    if not name:
        raise ApiError("Give the profile a name.")
    sec_ok = {i["id"]: i for i in security.ITEMS if i["kind"] != "info"}
    custom = []
    for w in p.get("custom_winget") or []:
        if isinstance(w, dict) and installer.ID_RX.match(str(w.get("id", ""))) and "." in str(w.get("id")):
            custom.append({"id": str(w["id"]), "name": str(w.get("name") or w["id"])[:80]})
    known = set(installer.ALL_IDS) | {w["id"] for w in custom}
    sec = []
    for s in p.get("security") or []:
        sid = s.get("id") if isinstance(s, dict) else s
        if sid in sec_ok:
            mode = "audit" if isinstance(s, dict) and s.get("mode") == "audit" and sec_ok[sid].get("audit") else "on"
            sec.append({"id": sid, "mode": mode})
    cleanup_ok = {c["id"] for c in cleanup._categories()}
    return {
        "id": str(p.get("id") or "p-" + secrets.token_hex(4)),
        "name": name, "desc": str(p.get("desc", "")).strip()[:200], "builtin": False,
        "tweaks": [t for t in dict.fromkeys(p.get("tweaks") or []) if t in tweaks.BY_ID],
        "security": sec,
        "install": [i for i in dict.fromkeys(p.get("install") or []) if i in known],
        "custom_winget": custom,
        "startup_off": [str(n)[:120] for n in dict.fromkeys(p.get("startup_off") or []) if isinstance(n, str)][:200],
        "cleanup": [c for c in dict.fromkeys(p.get("cleanup") or []) if c in cleanup_ok],
    }


# --------------------------------------------------------------------------
# Preview and apply
# --------------------------------------------------------------------------

def _startup_entries():
    return startup.STARTUP.get()["data"] or []


def preview(p):
    """What applying this profile would actually change on this PC."""
    st = {t["id"]: t for t in tweaks.list_tweaks()}
    sec_state = {i["id"]: i for i in security.items_view(security._read())}
    have = installer._installed()
    names = {i: n for items in installer.CATALOG.values() for i, n, _ in items}
    names.update({w["id"]: w["name"] for w in p.get("custom_winget", [])})
    on = {e["name"].lower() for e in _startup_entries() if e["enabled"]}
    out = {
        "tweaks": [st[t]["name"] for t in p["tweaks"] if st[t]["state"] != "on"],
        "security": [sec_state[s["id"]]["name"] + (" (audit mode)" if s["mode"] == "audit" else "") for s in p["security"]
                     if sec_state[s["id"]]["status"] in ("bad", "partial", "unknown")],
        "install": [names.get(i, i) for i in p["install"] if i.lower() not in have],
        "startup_off": [n for n in p["startup_off"] if n.lower() in on],
        "cleanup": [c["name"] for c in cleanup._categories() if c["id"] in p["cleanup"]],
    }
    out["already"] = (sum(len(p[k]) for k in ("tweaks", "install", "startup_off")) + len(p["security"])
                      - sum(len(out[k]) for k in ("tweaks", "security", "install", "startup_off")))
    return out


def _apply_job(job, p, make_point):
    if make_point:
        job.log("=== Restore point ===")
        job.log("Restore point created." if winsys.restore_point(f"Before profile: {p['name'][:40]}")
                else "Windows would not make a restore point (it may be switched off). Continuing.")
    results = []
    todo = [t for t in tweaks.list_tweaks() if t["id"] in p["tweaks"] and t["state"] != "on"]
    if todo:
        job.log(f"=== Tweaks ({len(todo)}) ===")
        results.append("tweaks: " + tweaks._job_apply(job, [t["id"] for t in todo], False))
    if p["security"]:
        job.log("=== Security ===")
        state = {i["id"]: i for i in security.items_view(security._read())}
        done = 0
        for s in p["security"]:
            if state[s["id"]]["status"] not in ("bad", "partial", "unknown"):
                continue
            try:
                security.fix(s["id"], s["mode"])
                job.log(f"Turned on: {security.BY_ID[s['id']]['name']}" + (" (audit)" if s["mode"] == "audit" else ""))
                done += 1
            except ApiError as e:
                job.log(f"Could not turn on {security.BY_ID[s['id']]['name']}: {e.msg}")
        results.append(f"security: {done} turned on")
    if p["startup_off"]:
        job.log("=== Startup ===")
        off = 0
        for e in _startup_entries():
            if e["name"].lower() in {n.lower() for n in p["startup_off"]} and e["enabled"]:
                try:
                    startup.r_toggle(core.Req({}, {"enabled": False}, (e["id"],)))
                    job.log(f"Switched off: {e['name']}")
                    off += 1
                except ApiError as ex:
                    job.log(f"Could not switch off {e['name']}: {ex.msg}")
        results.append(f"startup: {off} switched off")
    if p["install"]:
        c = installer._custom()
        for w in p.get("custom_winget", []):
            if w["id"] not in installer.all_entries():
                c["winget"].append({"id": w["id"], "name": w["name"], "desc": w["id"]})
        installer._save_custom(c)
        have = installer._installed()
        ids = [i for i in p["install"] if i.lower() not in have and i in installer.all_entries()]
        if ids:
            job.log(f"=== Programs ({len(ids)}) ===")
            if not installer.winget_available():
                job.log("Windows Package Manager (winget) was not found, so no programs were installed.")
            else:
                results.append("programs: " + installer._job(job, ids))
    if p["cleanup"]:
        job.log("=== Cleanup ===")
        results.append("cleanup: " + cleanup._clean_job(job, p["cleanup"]))
    activity("apply profile", p["name"], "ok", "; ".join(results)[:200])
    return "Profile applied. " + "; ".join(results) if results else "Nothing needed changing"


# --------------------------------------------------------------------------
# Capture from this PC
# --------------------------------------------------------------------------

def capture(name):
    sec = [{"id": i["id"], "mode": "on"} for i in security.items_view(security._read())
           if i["status"] == "ok" and i["id"] in security.BY_ID and security.BY_ID[i["id"]]["kind"] != "info"]
    return clean({"name": name, "desc": "Captured from this PC on " + time.strftime("%Y-%m-%d"),
                  "tweaks": [t["id"] for t in tweaks.list_tweaks() if t["state"] == "on"], "security": sec,
                  "startup_off": [e["name"] for e in _startup_entries() if not e["enabled"]]})


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------

@route("GET", r"/api/profiles")
def r_list(req):
    return {"items": all_profiles(), "options": options()}


@route("POST", r"/api/profiles/save")
def r_save(req):
    p = clean(req.body.get("profile"))
    _need_areas(p)
    items = _load()
    if any(b["id"] == p["id"] for b in BUILTIN):
        p["id"] = "p-" + secrets.token_hex(4)
    for i, old in enumerate(items):
        if old["id"] == p["id"]:
            items[i] = p
            break
    else:
        items.append(p)
    _store(items)
    activity("save profile", p["name"])
    return {"profile": p}


@route("POST", r"/api/profiles/delete")
def r_delete(req):
    pid = str(req.body.get("id", ""))
    items = _load()
    if not any(p["id"] == pid for p in items):
        raise ApiError("Built-in profiles cannot be deleted. Duplicate one to make your own.")
    _store([p for p in items if p["id"] != pid])
    activity("delete profile", pid)
    return {"ok": True}


@route("POST", r"/api/profiles/capture")
def r_capture(req):
    name = str(req.body.get("name", "")).strip() or "Captured profile"
    p = capture(name)
    items = _load() + [p]
    _store(items)
    return {"profile": p}


@route("POST", r"/api/profiles/draft")
def r_draft(req):
    """A starting point for the builder (nothing is saved): this PC's current settings, or a copy of a profile."""
    src = str(req.body.get("from", ""))
    if src == "current":
        return {"profile": dict(capture("New profile"), desc="")}
    p = dict(find(src))
    return {"profile": dict(p, id=None, builtin=False, name=p["name"] + " (copy)")}


@route("POST", r"/api/profiles/import")
def r_import(req):
    data = req.body.get("data")
    if not isinstance(data, dict) or data.get("app") != FORMAT or not isinstance(data.get("profile"), dict):
        raise ApiError("That file is not an App Manager profile.")
    p = clean(dict(data["profile"], id=None))
    items = _load() + [p]
    _store(items)
    activity("import profile", p["name"])
    return {"profile": p}


@route("GET", r"/api/profiles/export")
def r_export(req):
    p = find(req.query.get("id", ""))
    doc = {"app": FORMAT, "version": 1, "exported": time.strftime("%Y-%m-%d %H:%M"),
           "profile": {k: v for k, v in p.items() if k not in ("id", "builtin")}}
    safe = re.sub(r"[^A-Za-z0-9_-]+", "-", p["name"]).strip("-") or "profile"
    return core.Raw(json.dumps(doc, indent=1).encode("utf-8"), "application/json",
                    {"Content-Disposition": f'attachment; filename="profile-{safe}.json"'})


@route("POST", r"/api/profiles/preview")
def r_preview(req):
    p = find(str(req.body.get("id", "")))
    return {"name": p["name"], "preview": preview(p)}


@route("POST", r"/api/profiles/apply")
def r_apply(req):
    b = req.body
    if b.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    p = find(str(b.get("id", "")))
    _need_areas(p)
    return {"job": core.start_job(f"Apply profile: {p['name'][:40]}", _apply_job, p, bool(b.get("restore_point"))).id}
