"""Shared start-up for both apps: the User app (app_manager.py) and the Hub app (app_hub.py).

The role comes from the APPMGR_ROLE environment variable, which each entry script sets before anything
else is imported. It decides which modules load, which web paths are answered, which folder holds the
data and which port the dashboard uses.
"""

import argparse
import ctypes
import importlib
import os
import subprocess
import sys
import threading
import webbrowser

from . import core

USER_MODULES = ["accounts", "agent", "backup", "cleanup", "common", "errors", "devfix", "drivercheck", "hardware", "installer",
                "monitor", "myapps", "profiles", "programs", "remote", "security", "server", "startup", "tech",
                "tweaks", "ui", "updates"]
CLIENT_MODULES = ["accounts", "agent", "common", "errors", "remote", "server", "ui"]
HUB_MODULES = ["accounts", "common", "errors", "hub", "profiles", "remote", "server", "ui"]
# The Hub app answers only these web paths; everything else (local tweaks, programs ...) is not reachable there.
HUB_PATHS = (r"/api/(session|login|logout|ping|meta|jobs|ui|search|activity|quit|shortcut|me/password|errors|techs(/.*)?|"
             r"hub(/.*)?|remote(/.*)?|profiles|profiles/(save|delete|import|export|draft)|install/search)")
# The Client app answers only these paths: its own hub link and the remote-support list.
CLIENT_PATHS = r"/api/(session|login|logout|ping|meta|jobs|ui|quit|shortcut|me/password|errors|agent(/.*)?|remote(/.*)?)"
DEFAULT_PORT = {"user": 8765, "hub": 8775, "client": 8785}


def message_box(text, title=None):
    title = title or core.PRODUCT
    if core.IS_WIN:
        try:
            ctypes.windll.user32.MessageBoxW(None, text, title, 0x40)
            return
        except Exception:
            pass
    print(f"{title}: {text}")


def ensure_admin(args):
    """Windows: re-launch with a permission prompt so system changes (and the hub's firewall rule) will work."""
    if not core.IS_WIN or core.is_admin() or args.no_elevate:
        return
    if core.FROZEN:
        prog, params = sys.executable, subprocess.list2cmdline(sys.argv[1:])
    else:
        prog, params = core.python_exe(True), subprocess.list2cmdline([os.path.abspath(sys.argv[0])] + sys.argv[1:])
    r = ctypes.windll.shell32.ShellExecuteW(None, "runas", prog, params, None, 1)
    if r > 32:
        sys.exit(0)
    message_box(f"{core.PRODUCT} needs permission from Windows to do its work.\n\nPlease open it again and choose 'Yes'.")
    sys.exit(1)


def main():
    role = core.ROLE
    mods = {n: importlib.import_module("am." + n) for n in {"hub": HUB_MODULES, "client": CLIENT_MODULES}.get(role, USER_MODULES)}
    if role == "hub":
        core.set_allowed(HUB_PATHS)
    elif role == "client":
        core.set_allowed(CLIENT_PATHS)
    server, accounts = mods["server"], mods["accounts"]

    ap = argparse.ArgumentParser(description=core.PRODUCT)
    ap.add_argument("--port", type=int, default=DEFAULT_PORT[role])
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--background", action="store_true")
    ap.add_argument("--no-elevate", action="store_true")
    ap.add_argument("--reset-logins", action="store_true")
    args = ap.parse_args()
    if args.reset_logins:
        done = accounts.reset_logins()
        message_box("Technician sign-in has been switched off. Open the app and create the administrator again."
                    if done else "There were no technician accounts to remove.")
        return
    token = core.get_token()
    url = f"http://127.0.0.1:{args.port}/?t={token}"

    ensure_admin(args)

    running = server.ping_info(args.port)
    if running is not None and running != core.VERSION:     # an older copy is still running: replace it
        core.log(f"replacing running version {running or 'old'} with {core.VERSION}")
        if not server.stop_old(args.port, token):
            message_box(f"An older {core.PRODUCT} is still running and would not close.\n\n"
                        "Open Task Manager, end 'Python', and start it again.")
            sys.exit(1)
    elif running is not None:                   # same version already running: just open it
        if not (args.no_browser or args.background):
            webbrowser.open(url)
        return

    try:
        srv = server.make_server(args.port, token)
    except OSError as e:
        message_box(f"{core.PRODUCT} could not start because port {args.port} is busy.\n({e})")
        sys.exit(1)

    core.log(f"started {core.PRODUCT} v{core.VERSION} (admin={core.is_admin()}, port={args.port})")
    if core.installed_entry().exists():             # keep the auto-start copy current
        try:
            core.install_self()
        except OSError as e:
            core.log(f"could not refresh installed copy: {e!r}")

    if role == "hub":
        mods["hub"].start_if_enabled()
    elif role == "client":
        mods["agent"].AGENT.start()
    else:
        mods["myapps"].start_background()
        mods["agent"].AGENT.start()
        mods["programs"].INVENTORY.get()                  # warm the slow lists
        mods["startup"].STARTUP.get()
        mods["hardware"].HARDWARE.get()

    if not (args.no_browser or args.background):
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    print(f"{core.PRODUCT} is running at http://127.0.0.1:{args.port}  (Ctrl+C to quit)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
