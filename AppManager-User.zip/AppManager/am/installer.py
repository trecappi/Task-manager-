"""Install apps: a curated list of common free programs, installed through winget.

Pick the ones you want (or a preset), press Install. Programs that are already on the
PC are marked. Every package comes from the official winget repository.
"""

import hashlib
import json
import os
import re
import shlex
import subprocess
import time

from . import core
from .core import IS_WIN, ApiError, Lazy, activity, route
from .updates import _COMMON, _log_line, winget_available

# (winget id, name, one-line description)
CATALOG = {
    "Browsers": [
        ("Mozilla.Firefox", "Firefox", "Fast, private browser from Mozilla"),
        ("Google.Chrome", "Google Chrome", "Google's browser"),
        ("Brave.Brave", "Brave", "Chromium browser with a built-in ad blocker"),
        ("Vivaldi.Vivaldi", "Vivaldi", "Highly customisable browser"),
        ("LibreWolf.LibreWolf", "LibreWolf", "Firefox hardened for privacy"),
        ("TorProject.TorBrowser", "Tor Browser", "Anonymous browsing"),
    ],
    "Communication": [
        ("Discord.Discord", "Discord", "Voice, video and text chat"),
        ("Zoom.Zoom", "Zoom", "Video meetings"),
        ("SlackTechnologies.Slack", "Slack", "Team messaging"),
        ("Telegram.TelegramDesktop", "Telegram", "Messaging"),
        ("OpenWhisperSystems.Signal", "Signal", "Private messaging"),
        ("Microsoft.Teams", "Microsoft Teams", "Chat and meetings"),
    ],
    "Utilities": [
        ("7zip.7zip", "7-Zip", "Opens and creates zip, rar, 7z and more"),
        ("voidtools.Everything", "Everything", "Instant file search"),
        ("Microsoft.PowerToys", "PowerToys", "Power-user tools from Microsoft"),
        ("WinDirStat.WinDirStat", "WinDirStat", "See what is using your disk space"),
        ("Notepad++.Notepad++", "Notepad++", "Better text editor"),
        ("ShareX.ShareX", "ShareX", "Screenshots and screen recording"),
        ("Greenshot.Greenshot", "Greenshot", "Simple screenshot tool"),
        ("AnyDeskSoftwareGmbH.AnyDesk", "AnyDesk", "Remote desktop"),
        ("Usoris.RemoteUtilitiesViewer", "Remote Utilities Viewer", "Remote desktop (ID unverified)"),
        ("UltraViewer.UltraViewer", "UltraViewer", "Remote desktop (ID unverified)"),
        ("AOMEI.AnyViewer", "AnyViewer", "Remote desktop (ID unverified)"),
        ("TeamViewer.TeamViewer", "TeamViewer", "Remote support"),
        ("Rufus.Rufus", "Rufus", "Create bootable USB drives"),
        ("Balena.Etcher", "balenaEtcher", "Write disk images to USB"),
        ("Bitwarden.Bitwarden", "Bitwarden", "Password manager"),
        ("KeePassXCTeam.KeePassXC", "KeePassXC", "Offline password manager"),
    ],
    "System tools": [
        ("CPUID.CPU-Z", "CPU-Z", "CPU, memory and board details"),
        ("CPUID.HWMonitor", "HWMonitor", "Temperatures, fans and voltages"),
        ("TechPowerUp.GPU-Z", "GPU-Z", "Graphics card details"),
        ("Microsoft.Sysinternals.ProcessExplorer", "Process Explorer", "Advanced Task Manager"),
        ("Microsoft.Sysinternals.Autoruns", "Autoruns", "Everything that starts with Windows"),
        ("WiresharkFoundation.Wireshark", "Wireshark", "Network analysis"),
        ("WinSCP.WinSCP", "WinSCP", "File transfer over SFTP/SCP"),
        ("PuTTY.PuTTY", "PuTTY", "SSH client"),
    ],
    "Media": [
        ("VideoLAN.VLC", "VLC", "Plays almost any video or audio file"),
        ("Spotify.Spotify", "Spotify", "Music streaming"),
        ("OBSProject.OBSStudio", "OBS Studio", "Streaming and recording"),
        ("Audacity.Audacity", "Audacity", "Audio editor"),
        ("HandBrake.HandBrake", "HandBrake", "Video converter"),
        ("GIMP.GIMP", "GIMP", "Image editor"),
        ("Inkscape.Inkscape", "Inkscape", "Vector graphics"),
        ("BlenderFoundation.Blender", "Blender", "3D modelling and animation"),
        ("KDE.Kdenlive", "Kdenlive", "Video editor"),
    ],
    "Documents": [
        ("TheDocumentFoundation.LibreOffice", "LibreOffice", "Free office suite"),
        ("Adobe.Acrobat.Reader.64-bit", "Adobe Acrobat Reader", "PDF reader"),
        ("SumatraPDF.SumatraPDF", "SumatraPDF", "Light PDF reader"),
        ("Obsidian.Obsidian", "Obsidian", "Notes that link together"),
    ],
    "Developer": [
        ("Git.Git", "Git", "Version control"),
        ("Microsoft.VisualStudioCode", "Visual Studio Code", "Code editor"),
        ("Python.Python.3.12", "Python 3.12", "Python language"),
        ("OpenJS.NodeJS.LTS", "Node.js (LTS)", "JavaScript runtime"),
        ("Docker.DockerDesktop", "Docker Desktop", "Containers"),
        ("GitHub.GitHubDesktop", "GitHub Desktop", "Git with a simple window"),
        ("Microsoft.WindowsTerminal", "Windows Terminal", "Modern command-line window"),
        ("Microsoft.PowerShell", "PowerShell 7", "Newer PowerShell"),
        ("Postman.Postman", "Postman", "Test web APIs"),
    ],
    "Gaming": [
        ("Valve.Steam", "Steam", "Game store and launcher"),
        ("EpicGames.EpicGamesLauncher", "Epic Games Launcher", "Game store and launcher"),
        ("GOG.Galaxy", "GOG Galaxy", "Game launcher"),
        ("Guru3D.Afterburner", "MSI Afterburner", "GPU tuning and overlay"),
    ],
    "Runtimes": [
        ("Microsoft.VCRedist.2015+.x64", "Visual C++ Redistributable (x64)", "Needed by many programs and games"),
        ("Microsoft.DotNet.DesktopRuntime.8", ".NET Desktop Runtime 8", "Needed by many programs"),
        ("Microsoft.OpenJDK.21", "Java 21 (OpenJDK)", "Java runtime"),
    ],
    "Cloud storage": [
        ("Dropbox.Dropbox", "Dropbox", "File sync"),
        ("Google.GoogleDrive", "Google Drive", "File sync"),
    ],
    "Security": [
        ("Malwarebytes.Malwarebytes", "Malwarebytes", "Second-opinion malware scanner"),
    ],
}

PRESETS = [
    ("Essentials", "Browser, archiver, media player, PDF reader and runtimes",
     ["Mozilla.Firefox", "7zip.7zip", "VideoLAN.VLC", "SumatraPDF.SumatraPDF", "Notepad++.Notepad++",
      "Microsoft.VCRedist.2015+.x64", "Microsoft.DotNet.DesktopRuntime.8"]),
    ("Gaming", "Launchers, chat and the runtimes games need",
     ["Valve.Steam", "EpicGames.EpicGamesLauncher", "Discord.Discord", "Microsoft.VCRedist.2015+.x64",
      "Microsoft.DotNet.DesktopRuntime.8", "OBSProject.OBSStudio"]),
    ("Developer", "Git, VS Code, Python, Node, terminal",
     ["Git.Git", "Microsoft.VisualStudioCode", "Python.Python.3.12", "OpenJS.NodeJS.LTS",
      "Microsoft.WindowsTerminal", "GitHub.GitHubDesktop"]),
    ("Technician", "Diagnostics, remote support and disk tools",
     ["CPUID.CPU-Z", "CPUID.HWMonitor", "TechPowerUp.GPU-Z", "Microsoft.Sysinternals.ProcessExplorer",
      "Microsoft.Sysinternals.Autoruns", "7zip.7zip", "voidtools.Everything", "WinDirStat.WinDirStat",
      "Rufus.Rufus", "AnyDeskSoftwareGmbH.AnyDesk", "WiresharkFoundation.Wireshark", "PuTTY.PuTTY"]),
    ("Creator", "Editing, recording and graphics",
     ["OBSProject.OBSStudio", "Audacity.Audacity", "GIMP.GIMP", "Inkscape.Inkscape", "HandBrake.HandBrake",
      "Kdenlive.Kdenlive"]),
]

ALL_IDS = {i[0] for items in CATALOG.values() for i in items}
ID_RX = re.compile(r"[\w.\-+]+\Z")


def _installed():
    """Set of winget ids present on this PC (lower-case)."""
    if not IS_WIN:
        from . import fake
        return set(fake.INSTALLED_IDS)
    if not winget_available():
        return set()
    out = core.run(["winget", "list", "--accept-source-agreements", "--disable-interactivity"], timeout=180).stdout
    return {t.lower() for t in re.findall(r"[\w.\-+]+", out) if "." in t}


INSTALLED = Lazy(_installed, ttl=120)


CUSTOM_FILE = core.HOME / "install_custom.json"


def _custom():
    try:
        d = json.loads(CUSTOM_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        d = {}
    d.setdefault("winget", [])
    d.setdefault("files", [])
    d.setdefault("hidden", [])
    return d


def _save_custom(d):
    CUSTOM_FILE.write_text(json.dumps(d, indent=1), encoding="utf-8")


def _file_id(path):
    return "file:" + hashlib.sha1(path.lower().encode()).hexdigest()[:10]


def all_entries():
    """{id: (name, kind)} for everything that can currently be installed."""
    c = _custom()
    out = {i: (n, "builtin") for items in CATALOG.values() for i, n, _ in items if i not in c["hidden"]}
    for w in c["winget"]:
        out[w["id"]] = (w["name"], "winget")
    for f in c["files"]:
        out[f["id"]] = (f["name"], "file")
    return out


@route("GET", r"/api/install")
def r_catalog(req):
    snap = INSTALLED.get(force="refresh" in req.query)
    have = snap["data"] or set()
    c = _custom()
    hidden = set(c["hidden"])
    mine = [{"id": w["id"], "name": w["name"], "desc": w.get("desc") or w["id"], "installed": w["id"].lower() in have,
             "custom": True, "kind": "winget"} for w in c["winget"]]
    mine += [{"id": f["id"], "name": f["name"], "desc": f["path"] + (("  " + f["args"]) if f.get("args") else ""),
              "installed": False, "custom": True, "kind": "file", "missing": not os.path.isfile(f["path"])}
             for f in c["files"]]
    cats = [{"name": "My programs", "items": mine}] if mine else []
    for cat, items in CATALOG.items():
        shown = [{"id": i, "name": n, "desc": d, "installed": i.lower() in have, "custom": False}
                 for i, n, d in items if i not in hidden]
        if shown:
            cats.append({"name": cat, "items": shown})
    return {"loading": snap["loading"], "ready": snap["ready"], "error": snap["error"],
            "winget": winget_available(), "categories": cats, "hidden": len(hidden),
            "presets": [{"name": n, "desc": d, "ids": [i for i in ids if i not in hidden]} for n, d, ids in PRESETS]}


def parse_search_table(text):
    """Parse `winget search` output: Name / Id / Version [/ Match] [/ Source]."""
    lines = [l.rstrip() for l in text.splitlines() if len(l.strip()) > 1]
    for i, ln in enumerate(lines):
        if i > 0 and re.fullmatch(r"-{5,}", ln.strip()):
            h = lines[i - 1]
            pos = {k: h.find(k) for k in ("Name", "Id", "Version", "Match", "Source")}
            if min(pos["Name"], pos["Id"], pos["Version"]) < 0:
                continue
            nxt = [p for p in (pos["Match"], pos["Source"]) if p > pos["Version"]]
            end_v = min(nxt) if nxt else None
            out = []
            for row in lines[i + 1:]:
                item = {"name": row[pos["Name"]:pos["Id"]].strip(), "id": row[pos["Id"]:pos["Version"]].strip(),
                        "version": row[pos["Version"]:end_v].strip()}
                if item["id"] and " " not in item["id"] and ID_RX.match(item["id"]):
                    out.append(item)
            return out
    return []


_FAKE_SEARCH = [("Notepad++", "Notepad++.Notepad++", "8.6"), ("Krita", "KDE.Krita", "5.2"),
                ("FileZilla", "TimKosse.FileZilla.Client", "3.67"), ("Zoom Workplace", "Zoom.Zoom", "6.0")]


@route("POST", r"/api/install/search")
def r_search(req):
    q = str(req.body.get("q", "")).strip()
    if len(q) < 2 or len(q) > 60 or not re.fullmatch(r"[\w .+\-#]+", q):
        raise ApiError("Type at least two letters of the program's name.")
    if not IS_WIN:
        return {"items": [{"name": n, "id": i, "version": v} for n, i, v in _FAKE_SEARCH if q.lower() in n.lower()]}
    if not winget_available():
        raise ApiError("Windows Package Manager (winget) was not found on this PC.")
    out = core.run(["winget", "search", q, "--accept-source-agreements", "--disable-interactivity", "--count", "20"],
                   timeout=60).stdout
    return {"items": parse_search_table(out)[:20]}


@route("POST", r"/api/install/add")
def r_add(req):
    b, c = req.body, _custom()
    name = str(b.get("name", "")).strip()[:80]
    if b.get("kind") == "winget":
        pid = str(b.get("id", "")).strip()
        if not ID_RX.match(pid) or "." not in pid:
            raise ApiError("That is not a valid winget package ID.")
        if pid in all_entries():
            raise ApiError("That program is already in the list.")
        c["winget"].append({"id": pid, "name": name or pid, "desc": str(b.get("desc", ""))[:120]})
        c["hidden"] = [h for h in c["hidden"] if h != pid]
    elif b.get("kind") == "file":
        path = str(b.get("path", "")).strip().strip('"')
        if not os.path.isabs(path) or not os.path.isfile(path) or not path.lower().endswith((".exe", ".msi")):
            raise ApiError("Choose an installer file (.exe or .msi) that exists on this PC.")
        fid = _file_id(path)
        if fid in all_entries():
            raise ApiError("That installer is already in the list.")
        c["files"].append({"id": fid, "name": name or os.path.splitext(os.path.basename(path))[0], "path": path,
                           "args": str(b.get("args", "")).strip()[:200]})
    else:
        raise ApiError("Unknown kind.")
    _save_custom(c)
    activity("add installer", name or "")
    INSTALLED.get(force=True)
    return {"ok": True}


@route("POST", r"/api/install/remove")
def r_remove(req):
    iid, c = str(req.body.get("id", "")), _custom()
    before = len(c["winget"]) + len(c["files"])
    c["winget"] = [w for w in c["winget"] if w["id"] != iid]
    c["files"] = [f for f in c["files"] if f["id"] != iid]
    if len(c["winget"]) + len(c["files"]) == before:                # not one of mine: hide the built-in entry
        if iid not in ALL_IDS:
            raise ApiError("Unknown program.")
        if iid not in c["hidden"]:
            c["hidden"].append(iid)
    _save_custom(c)
    activity("remove from install list", iid)
    return {"ok": True}


@route("POST", r"/api/install/restore")
def r_restore(req):
    c = _custom()
    c["hidden"] = []
    _save_custom(c)
    return {"ok": True}


def _run_file(job, entry):
    path, args = entry["path"], entry.get("args", "")
    if not os.path.isfile(path):
        job.log("The installer file is missing.")
        return 1
    if not IS_WIN:
        job.log("Test mode: pretending to run the installer…")
        time.sleep(0.6)
        return 0
    cmd = ["msiexec", "/i", path, "/qn", "/norestart"] if path.lower().endswith(".msi") else [path]
    try:
        cmd += shlex.split(args, posix=False)
    except ValueError:
        job.log("The switches are not valid.")
        return 1
    job.log("Running: " + " ".join(cmd))
    return subprocess.run(cmd, stdin=subprocess.DEVNULL, creationflags=core.NO_WINDOW).returncode


def _run_winget(job, pid):
    from . import fake
    if not IS_WIN:
        job.log("Test mode: pretending to download and install…")
        time.sleep(0.8)
        fake.INSTALLED_IDS.add(pid)
        return 0
    proc = subprocess.Popen(
        ["winget", "install", "--id", pid, "--exact", "--silent", "--accept-package-agreements"] + _COMMON,
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        creationflags=core.NO_WINDOW)
    buf = b""
    for chunk in iter(lambda: proc.stdout.read(256), b""):
        buf += chunk
        parts = re.split(rb"[\r\n]+", buf)
        buf = parts.pop()
        for part in parts:
            _log_line(job, part.decode("utf-8", "replace"))
    _log_line(job, buf.decode("utf-8", "replace"))
    return proc.wait()


def _job(job, ids):
    entries, c = all_entries(), _custom()
    files = {f["id"]: f for f in c["files"]}
    names = {i: n for i, (n, _) in entries.items()}
    ok = bad = 0
    for pid in ids:
        job.log(f"--- {names[pid]} ---")
        code = _run_file(job, files[pid]) if pid in files else _run_winget(job, pid)
        if code in (0, 0x8A150061, 0x8A15002B):      # already installed / nothing newer
            ok += 1
            activity("install", names[pid])
        else:
            bad += 1
            job.log(f"winget reported a problem (code {code}).")
            activity("install", names[pid], "failed", f"code {code}")
    INSTALLED.get(force=True)
    return f"{ok} installed" + (f", {bad} had problems" if bad else "")


@route("POST", r"/api/install/run")
def r_run(req):
    b = req.body
    if b.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    ids = [i for i in dict.fromkeys(b.get("ids", [])) if isinstance(i, str) and i in all_entries()][:40]
    if not ids:
        raise ApiError("Nothing selected.")
    if not winget_available() and any(not i.startswith("file:") for i in ids):
        raise ApiError("Windows Package Manager (winget) was not found on this PC.")
    return {"job": core.start_job(f"Install {len(ids)} program{'s' if len(ids) != 1 else ''}", _job, ids).id}
