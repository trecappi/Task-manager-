"""Hardware overview, device tree (Device Manager style) and driver information."""

from . import core
from .core import IS_WIN, Lazy, route

_CLASS_NAMES = {
    "Net": "Network adapters", "Display": "Display adapters", "DiskDrive": "Disk drives",
    "USB": "USB controllers and devices", "HIDClass": "Human interface devices",
    "Keyboard": "Keyboards", "Mouse": "Mice and pointing devices", "Monitor": "Monitors",
    "MEDIA": "Sound, video and game controllers", "AudioEndpoint": "Audio inputs and outputs",
    "Bluetooth": "Bluetooth", "Processor": "Processors", "System": "System devices",
    "SCSIAdapter": "Storage controllers", "HDC": "IDE / SATA controllers",
    "Camera": "Cameras", "Image": "Imaging devices", "Printer": "Printers",
    "PrintQueue": "Print queues", "Battery": "Batteries", "Firmware": "Firmware",
    "SoftwareDevice": "Software devices", "SecurityDevices": "Security devices",
    "Volume": "Storage volumes", "WPD": "Portable devices", "Ports": "Ports (COM and LPT)",
    "Biometric": "Biometric devices", "SmartCardReader": "Smart card readers",
    "Sensor": "Sensors", "Extension": "Software components", "Computer": "Computer",
    "Other": "Other devices", "SoftwareComponent": "Software components",
    "Volume": "Storage volumes", "VolumeSnapshot": "Storage volume shadow copies",
}

_PROBLEMS = {
    1: "Not set up correctly", 3: "The driver may be damaged, or the PC is low on memory",
    10: "The device can't start", 12: "Not enough free resources to run",
    14: "Needs a restart to work", 18: "The drivers need to be reinstalled",
    19: "Windows settings for this device are damaged", 24: "Not present or not working",
    28: "No driver is installed", 31: "Not working properly",
    32: "The driver is turned off", 37: "The driver failed to start",
    39: "The driver is damaged or missing",
    43: "Windows stopped it because it reported a problem",
    52: "The driver is not digitally signed",
}

# Codes that are not really "errors": 22 = turned off by the user, 45 = unplugged.
_NOT_PROBLEMS = (0, 22, 45)

_HW_SCRIPT = r"""
function D($d){ if($d){ ([datetime]$d).ToString('yyyy-MM-dd') } else { $null } }
$r=@{}
try{
 $os=Get-CimInstance Win32_OperatingSystem
 $cs=Get-CimInstance Win32_ComputerSystem
 $r.system=@{ manufacturer=$cs.Manufacturer; model=$cs.Model; os=$os.Caption; version=$os.Version; build=$os.BuildNumber; arch=$os.OSArchitecture; installed=(D $os.InstallDate); uptime=[int]((Get-Date)-$os.LastBootUpTime).TotalSeconds; name=$cs.Name }
 $r.ramtotal=[int64]$cs.TotalPhysicalMemory
}catch{}
try{ $b=Get-CimInstance Win32_BIOS; $r.bios=@{ vendor=$b.Manufacturer; version=$b.SMBIOSBIOSVersion; date=(D $b.ReleaseDate) } }catch{}
try{ $bb=Get-CimInstance Win32_BaseBoard; $r.board=@{ maker=$bb.Manufacturer; product=$bb.Product } }catch{}
try{ $r.cpu=@(Get-CimInstance Win32_Processor | ForEach-Object{ @{ name=([string]$_.Name).Trim(); cores=$_.NumberOfCores; threads=$_.NumberOfLogicalProcessors; mhz=$_.MaxClockSpeed } }) }catch{}
try{ $r.gpu=@(Get-CimInstance Win32_VideoController | ForEach-Object{ @{ name=$_.Name; vram=[int64]$_.AdapterRAM; driver=$_.DriverVersion; date=(D $_.DriverDate) } }) }catch{}
try{ $r.modules=@(Get-CimInstance Win32_PhysicalMemory | ForEach-Object{ @{ slot=$_.DeviceLocator; size=[int64]$_.Capacity; speed=$_.Speed; maker=([string]$_.Manufacturer).Trim(); part=([string]$_.PartNumber).Trim() } }) }catch{}
try{ $r.disks=@(Get-PhysicalDisk | ForEach-Object{ @{ name=$_.FriendlyName; type=[string]$_.MediaType; bus=[string]$_.BusType; size=[int64]$_.Size; health=[string]$_.HealthStatus } }) }catch{}
try{ $r.volumes=@(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object{ @{ drive=$_.DeviceID; label=$_.VolumeName; fs=$_.FileSystem; size=[int64]$_.Size; free=[int64]$_.FreeSpace } }) }catch{}
try{ $r.secureboot=[bool](Confirm-SecureBootUEFI -ErrorAction Stop) }catch{ $r.secureboot=$null }
$r | ConvertTo-Json -Depth 5 -Compress
"""

_DEV_SCRIPT = (
    "Get-CimInstance Win32_PnPEntity | ForEach-Object { [pscustomobject]@{ name=$_.Name; "
    "raw_cls=$_.PNPClass; maker=$_.Manufacturer; status=$_.Status; code=[int]$_.ConfigManagerErrorCode; "
    "present=$(if($_.Present -eq $null){$true}else{[bool]$_.Present}); id=$_.DeviceID; "
    "service=$_.Service } } | ConvertTo-Json -Compress")

_DRV_SCRIPT = (
    "Get-CimInstance Win32_PnPSignedDriver | Where-Object { $_.DeviceName } | ForEach-Object { "
    "[pscustomobject]@{ device=$_.DeviceName; raw_cls=$_.DeviceClass; provider=$_.DriverProviderName; "
    "version=$_.DriverVersion; date=$(if($_.DriverDate){([datetime]$_.DriverDate).ToString('yyyy-MM-dd')}"
    "else{$null}); inf=$_.InfName; signed=[bool]$_.IsSigned; signer=$_.Signer; id=$_.DeviceID } } "
    "| ConvertTo-Json -Compress")


def _friendly(cls):
    return _CLASS_NAMES.get(cls or "Other", cls or "Other devices")


def _load_hardware():
    if IS_WIN:
        raw = core.ps_obj(_HW_SCRIPT, timeout=90)
    else:
        from . import fake
        raw = fake.hardware()
    ram = raw.get("ram") or {"total": raw.get("ramtotal", 0), "modules": raw.get("modules", [])}
    return {"system": raw.get("system") or {}, "bios": raw.get("bios") or {},
            "board": raw.get("board") or {}, "cpu": raw.get("cpu") or [],
            "gpu": raw.get("gpu") or [], "ram": ram, "disks": raw.get("disks") or [],
            "volumes": raw.get("volumes") or [], "secureboot": raw.get("secureboot")}


def _load_devices():
    if IS_WIN:
        rows = core.ps_json(_DEV_SCRIPT, timeout=120)
    else:
        from . import fake
        rows = fake.devices()
    out = []
    for r in rows:
        code = int(r.get("code") or 0)
        out.append({"name": r.get("name") or "Unknown device", "cls": _friendly(r.get("raw_cls")),
                    "maker": r.get("maker") or "", "status": r.get("status") or "",
                    "code": code, "present": bool(r.get("present", True)),
                    "disabled": code == 22,
                    "problem": ("" if code in _NOT_PROBLEMS
                                else _PROBLEMS.get(code, f"Windows reports error code {code}")),
                    "id": r.get("id") or ""})
    return sorted(out, key=lambda d: (d["cls"].lower(), d["name"].lower()))


def _load_drivers():
    if IS_WIN:
        rows = core.ps_json(_DRV_SCRIPT, timeout=180)
    else:
        from . import fake
        rows = fake.drivers()
    out = [{"device": r.get("device") or "", "cls": _friendly(r.get("raw_cls")),
            "provider": r.get("provider") or "", "version": r.get("version") or "",
            "date": r.get("date") or "", "inf": r.get("inf") or "",
            "signed": bool(r.get("signed")), "signer": r.get("signer") or "",
            "id": r.get("id") or ""} for r in rows]
    return sorted(out, key=lambda d: (d["cls"].lower(), d["device"].lower()))


HARDWARE = Lazy(_load_hardware, ttl=600)
DEVICES = Lazy(_load_devices, ttl=300)
DRIVERS = Lazy(_load_drivers, ttl=600)


@route("GET", r"/api/hardware")
def r_hardware(req):
    s = HARDWARE.get(force="refresh" in req.query)
    return {"loading": s["loading"], "error": s["error"], "ready": s["ready"], "data": s["data"]}


@route("GET", r"/api/devices")
def r_devices(req):
    s = DEVICES.get(force="refresh" in req.query)
    return {"loading": s["loading"], "error": s["error"], "ready": s["ready"],
            "items": s["data"] or []}


@route("GET", r"/api/drivers")
def r_drivers(req):
    s = DRIVERS.get(force="refresh" in req.query)
    return {"loading": s["loading"], "error": s["error"], "ready": s["ready"],
            "items": s["data"] or []}
