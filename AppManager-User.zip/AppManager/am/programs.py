"""Programs: installed-app inventory, details, uninstall, export, favorites."""

import csv
import difflib
import html
import io
import os
import re
import subprocess
import time

from . import core, myapps
from .backend import BACKEND
from .core import (IS_WIN, LOCK, ApiError, Lazy, Raw, activity, load_state, norm,
                   route, save_state)

_UNINSTALL = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"
_SKIP_EXE = re.compile(r"unins|uninst|setup|crash|update|helper|redist|vc_|install", re.I)


# --------------------------------------------------------------------------
# Reading the installed programs
# --------------------------------------------------------------------------

def _read_values(winreg, key):
    vals, i = {}, 0
    while True:
        try:
            name, value, _t = winreg.EnumValue(key, i)
        except OSError:
            return vals
        vals[name] = value
        i += 1


def _fmt_date(raw):
    raw = str(raw or "").strip()
    if re.fullmatch(r"\d{8}", raw) and raw[:2] in ("19", "20"):
        return f"{raw[:4]}-{raw[4:6]}-{raw[6:]}"
    return ""


def _win_registry():
    import winreg
    views = [("machine", 64, winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_64KEY),
             ("machine", 32, winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_32KEY),
             ("user", 64, winreg.HKEY_CURRENT_USER, winreg.KEY_WOW64_64KEY),
             ("user", 32, winreg.HKEY_CURRENT_USER, winreg.KEY_WOW64_32KEY)]
    items, seen = [], set()
    for scope, bits, hive, flag in views:
        try:
            root = winreg.OpenKey(hive, _UNINSTALL, 0, winreg.KEY_READ | flag)
        except OSError:
            continue
        with root:
            for i in range(winreg.QueryInfoKey(root)[0]):
                try:
                    sub = winreg.EnumKey(root, i)
                    with winreg.OpenKey(root, sub, 0, winreg.KEY_READ | flag) as k:
                        vals = _read_values(winreg, k)
                except OSError:
                    continue
                name = str(vals.get("DisplayName") or "").strip()
                if (not name or vals.get("SystemComponent") == 1 or vals.get("ParentKeyName")
                        or vals.get("ReleaseType") in ("Update", "Security Update", "Hotfix",
                                                       "Service Pack")):
                    continue
                uninstall = str(vals.get("UninstallString") or "").strip()
                quiet = str(vals.get("QuietUninstallString") or "").strip()
                guid = sub if re.fullmatch(r"\{[0-9A-Fa-f-]{36}\}", sub) else None
                if guid and (vals.get("WindowsInstaller") == 1 or "msiexec" in uninstall.lower()):
                    uninstall = f"msiexec.exe /x {guid}"
                    quiet = f"msiexec.exe /x {guid} /qn /norestart"
                icon = re.sub(r",\s*-?\d+$", "", str(vals.get("DisplayIcon") or "").strip().strip('"'))
                try:
                    size = int(vals.get("EstimatedSize")) or None
                except (TypeError, ValueError):
                    size = None
                dupe = (scope, sub, name, str(vals.get("DisplayVersion") or ""))
                if dupe in seen:          # some hives show the same key in both views
                    continue
                seen.add(dupe)
                items.append({
                    "id": core.file_id("reg", scope, bits, sub), "kind": "desktop", "name": name,
                    "version": str(vals.get("DisplayVersion") or ""),
                    "publisher": str(vals.get("Publisher") or ""),
                    "installed": _fmt_date(vals.get("InstallDate")), "size_kb": size,
                    "location": str(vals.get("InstallLocation") or "").strip().strip('"'),
                    "icon": icon.strip('"'), "uninstall": uninstall, "quiet": quiet,
                    "can_uninstall": bool(uninstall) and vals.get("NoRemove") != 1,
                    "scope": scope, "arch": f"{bits}-bit",
                    "reg": {"scope": scope, "bits": bits, "key": sub}})
    return items


def _store_name(pkg):
    part = pkg.split(".", 1)[1] if "." in pkg else pkg
    return re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", part)


def _win_store():
    rows = core.ps_json(
        "Get-AppxPackage | Where-Object { -not $_.IsFramework -and -not $_.NonRemovable -and "
        "-not $_.IsResourcePackage -and $_.SignatureKind -ne 'System' } | ForEach-Object { "
        "[pscustomobject]@{ name=$_.Name; full=$_.PackageFullName; version=[string]$_.Version; "
        "publisher=[string]$_.Publisher; location=[string]$_.InstallLocation; "
        "arch=[string]$_.Architecture } } | ConvertTo-Json -Compress", timeout=90)
    items = []
    for r in rows:
        m = re.search(r"CN=([^,]+)", r.get("publisher") or "")
        items.append({
            "id": core.file_id("store", r["full"]), "kind": "store", "name": _store_name(r["name"]),
            "version": r.get("version") or "", "publisher": (m.group(1) if m else ""),
            "installed": "", "size_kb": None, "location": r.get("location") or "", "exe": "",
            "icon": "", "uninstall": "", "quiet": "", "can_uninstall": True, "scope": "user",
            "arch": r.get("arch") or "", "reg": None, "store": {"full": r["full"]}})
    return items


def _load_inventory():
    if not IS_WIN:
        from . import fake
        return sorted(fake.programs(), key=lambda p: p["name"].lower())
    items = _win_registry()
    try:
        items += _win_store()
    except Exception as e:
        core.log(f"store apps scan failed: {e!r}")
    return sorted(items, key=lambda p: p["name"].lower())


INVENTORY = Lazy(_load_inventory, ttl=300)


def _find(pid):
    snap = INVENTORY.get()
    for p in snap["data"] or []:
        if p["id"] == pid:
            return p
    raise ApiError("That program is no longer in the list. Refresh and try again.", 404)


# --------------------------------------------------------------------------
# Finding a program's .exe (needed for firewall rules and "My apps")
# --------------------------------------------------------------------------

def guess_exe(p):
    if "exe" in p and p["exe"] is not None:
        return p["exe"] or None
    exe = None
    icon = p.get("icon") or ""
    if icon.lower().endswith(".exe") and os.path.isfile(icon) and not _SKIP_EXE.search(os.path.basename(icon)):
        exe = icon
    elif p.get("location") and os.path.isdir(p["location"]):
        best, loc = None, p["location"]
        for dirpath, dirs, files in os.walk(loc):
            if dirpath[len(loc):].count(os.sep) >= 2:
                dirs[:] = []
            for f in files:
                if f.lower().endswith(".exe") and not _SKIP_EXE.search(f):
                    score = difflib.SequenceMatcher(
                        None, os.path.splitext(f)[0].lower(), p["name"].lower()).ratio()
                    if best is None or score > best[0]:
                        best = (score, os.path.join(dirpath, f))
        exe = best[1] if best else None
    p["exe"] = exe or ""
    return exe


def dir_size(path, limit_s=10):
    total, end = 0, time.time() + limit_s
    for dirpath, dirs, files in os.walk(path):
        if time.time() > end:
            return total, False
        for f in files:
            try:
                fp = os.path.join(dirpath, f)
                if not os.path.islink(fp):
                    total += os.path.getsize(fp)
            except OSError:
                pass
    return total, True


# --------------------------------------------------------------------------
# Routes: list and details
# --------------------------------------------------------------------------

_LIST_KEYS = ("id", "kind", "name", "version", "publisher", "installed", "size_kb",
              "location", "scope", "arch", "can_uninstall")


@route("GET", r"/api/programs")
def r_list(req):
    snap = INVENTORY.get(force="refresh" in req.query)
    fav = set(load_state()["favorites"])
    items = [dict({k: p[k] for k in _LIST_KEYS}, favorite=p["id"] in fav)
             for p in snap["data"] or []]
    return {"loading": snap["loading"], "error": snap["error"], "ready": snap["ready"],
            "items": items}


@route("GET", r"/api/programs/([0-9a-f]{10})")
def r_detail(req):
    p = _find(req.groups[0])
    exe = guess_exe(p) if p["kind"] == "desktop" else None
    s = load_state()
    d = {k: v for k, v in p.items() if k not in ("reg",)}
    d.update(exe=exe or "", favorite=p["id"] in s["favorites"],
             blocked=bool(exe) and norm(exe) in s["blocked"],
             managed=bool(exe) and any(norm(a["exe"]) == norm(exe) for a in s["apps"].values()),
             location_exists=bool(p["location"]) and os.path.isdir(p["location"]),
             system=core.is_system_path(exe or ""))
    return d


@route("GET", r"/api/programs/([0-9a-f]{10})/size")
def r_size(req):
    p = _find(req.groups[0])
    if not p["location"] or not os.path.isdir(p["location"]):
        return {"bytes": None, "complete": True}
    size, complete = dir_size(p["location"])
    return {"bytes": size, "complete": complete}


@route("POST", r"/api/programs/([0-9a-f]{10})/favorite")
def r_favorite(req):
    pid = req.groups[0]
    with LOCK:
        s = load_state()
        if pid in s["favorites"]:
            s["favorites"].remove(pid)
        else:
            s["favorites"].append(pid)
        save_state(s)
    return {"favorite": pid in s["favorites"]}


@route("POST", r"/api/programs/([0-9a-f]{10})/open")
def r_open(req):
    p = _find(req.groups[0])
    if not p["location"] or not os.path.isdir(p["location"]):
        raise ApiError("I don't know where this program's folder is.")
    BACKEND.open_folder(p["location"])
    return {"ok": True}


@route("POST", r"/api/programs/([0-9a-f]{10})/block")
def r_block(req):
    p = _find(req.groups[0])
    exe = guess_exe(p) if p["kind"] == "desktop" else None
    if not exe:
        raise ApiError("I couldn't find this program's file, so I can't block it. Use "
                       "'Add a program' under My apps to choose its file yourself.")
    return myapps.block_exe(exe, p["name"], bool(req.body.get("blocked")),
                            bool(req.body.get("force")))


@route("POST", r"/api/programs/([0-9a-f]{10})/manage")
def r_manage(req):
    p = _find(req.groups[0])
    exe = guess_exe(p) if p["kind"] == "desktop" else None
    if not exe:
        raise ApiError("I couldn't find this program's file. Use 'Add a program' under "
                       "My apps to choose it yourself.")
    myapps.add_app(exe, p["name"])
    return {"ok": True}


# --------------------------------------------------------------------------
# Export
# --------------------------------------------------------------------------

def _rows():
    items = INVENTORY.get()["data"] or []
    for p in items:
        yield [p["name"], p["version"], p["publisher"], p["installed"],
               round(p["size_kb"] / 1024, 1) if p["size_kb"] else "", p["location"],
               "Microsoft Store" if p["kind"] == "store" else "Desktop"]


_COLS = ["Name", "Version", "Publisher", "Install date", "Size (MB)", "Location", "Source"]


@route("GET", r"/api/programs/export")
def r_export(req):
    fmt = req.query.get("format", "csv")
    stamp = time.strftime("%Y-%m-%d")
    if fmt == "html":
        head = "".join(f"<th>{html.escape(c)}</th>" for c in _COLS)
        body = "".join("<tr>" + "".join(f"<td>{html.escape(str(c))}</td>" for c in r) + "</tr>"
                       for r in _rows())
        doc = ("<!doctype html><meta charset=utf-8><title>Installed programs</title>"
               "<style>body{font:14px system-ui;margin:2rem}table{border-collapse:collapse}"
               "td,th{border:1px solid #ccc;padding:4px 8px;text-align:left}"
               "th{background:#f0f2f5}</style>"
               f"<h2>Installed programs ({stamp})</h2><table><tr>{head}</tr>{body}</table>")
        return Raw(doc.encode("utf-8"), "text/html; charset=utf-8",
                   {"Content-Disposition": f'attachment; filename="programs-{stamp}.html"'})
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(_COLS)
    w.writerows(_rows())
    return Raw(("﻿" + buf.getvalue()).encode("utf-8"), "text/csv; charset=utf-8",
               {"Content-Disposition": f'attachment; filename="programs-{stamp}.csv"'})


# --------------------------------------------------------------------------
# Uninstall (one or many) as a background task
# --------------------------------------------------------------------------

def _reg_exists(reg):
    import winreg
    hive = winreg.HKEY_LOCAL_MACHINE if reg["scope"] == "machine" else winreg.HKEY_CURRENT_USER
    flag = winreg.KEY_WOW64_64KEY if reg["bits"] == 64 else winreg.KEY_WOW64_32KEY
    try:
        winreg.CloseKey(winreg.OpenKey(hive, _UNINSTALL + "\\" + reg["key"], 0,
                                       winreg.KEY_READ | flag))
        return True
    except OSError:
        return False


def _restore_point(job):
    job.log("Creating a restore point first…")
    try:
        core.ps("Checkpoint-Computer -Description 'App Manager: before uninstall' "
                "-RestorePointType MODIFY_SETTINGS -ErrorAction Stop", timeout=240)
        job.log("Restore point created.")
    except Exception as e:
        job.log("Could not create a restore point (System Protection may be off, or one "
                f"was made in the last 24 hours). Continuing. ({e})")


def _uninstall_one(job, p, silent):
    if not IS_WIN:
        from . import fake
        return fake.fake_uninstall(job, p)
    if p["kind"] == "store":
        job.log("Removing this Microsoft Store app…")
        core.ps(f"Remove-AppxPackage -Package {core.ps_quote(p['store']['full'])} -ErrorAction Stop",
                timeout=300)
        return True
    cmd = p["quiet"] if (silent and p["quiet"]) else p["uninstall"]
    if silent and not p["quiet"]:
        job.log("This program has no silent option, so its own uninstaller window will open.")
    cmd = os.path.expandvars(cmd)
    job.log(f"Running: {cmd}")
    proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL, creationflags=core.NO_WINDOW)
    try:
        code = proc.wait(timeout=3600)
    except subprocess.TimeoutExpired:
        job.log("The uninstaller is still running after an hour; I'm no longer waiting.")
        return False
    job.log(f"Uninstaller finished (exit code {code}).")
    if p.get("reg"):
        for _ in range(20):                      # some uninstallers hand off and exit early
            if not _reg_exists(p["reg"]):
                return True
            time.sleep(2)
        return False
    return code == 0


def _uninstall_job(job, ids, silent, restore):
    inv = {p["id"]: p for p in INVENTORY.get()["data"] or []}
    if restore and IS_WIN:
        _restore_point(job)
    removed = unclear = 0
    for pid in ids:
        p = inv.get(pid)
        if not p:
            continue
        job.log(f"--- {p['name']} ---")
        try:
            ok = _uninstall_one(job, p, silent)
        except Exception as e:
            job.log(f"Failed: {e}")
            activity("uninstall", p["name"], "failed", str(e))
            unclear += 1
            continue
        if ok:
            job.log("Removed.")
            activity("uninstall", p["name"], "ok")
            removed += 1
        else:
            job.log("It still shows as installed. It may still be finishing, or you may "
                    "have cancelled it.")
            activity("uninstall", p["name"], "unclear")
            unclear += 1
    INVENTORY.get(force=True)
    return f"{removed} removed" + (f", {unclear} need a look" if unclear else "")


@route("POST", r"/api/programs/uninstall")
def r_uninstall(req):
    b = req.body
    if b.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    ids = [i for i in b.get("ids", []) if isinstance(i, str)][:50]
    if not ids:
        raise ApiError("Nothing selected.")
    inv = {p["id"]: p for p in INVENTORY.get()["data"] or []}
    for i in ids:
        if i not in inv:
            raise ApiError("One of those programs is no longer in the list. Refresh and try again.")
        if not inv[i]["can_uninstall"]:
            raise ApiError(f"{inv[i]['name']} can't be uninstalled from here.")
    title = f"Uninstall {inv[ids[0]]['name']}" if len(ids) == 1 else f"Uninstall {len(ids)} programs"
    job = core.start_job(title, _uninstall_job, ids, bool(b.get("silent")), bool(b.get("restore_point")))
    return {"job": job.id}
