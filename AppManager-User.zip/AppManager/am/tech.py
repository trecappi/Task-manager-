"""Technician toolkit: PC health report, network tools, Windows repair, Windows Update
status and shortcuts to the classic admin consoles."""

import html
import os
import re
import socket
import subprocess
import time

from . import core
from .core import IS_WIN, ApiError, Lazy, Raw, activity, route

HOST_RX = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.\-]{0,251}[A-Za-z0-9])?$|^[0-9A-Fa-f:]{2,45}$")


def _host(b):
    h = str(b.get("host", "")).strip()
    if not HOST_RX.match(h):
        raise ApiError("Type a website or IP address, such as example.com or 192.168.1.1.")
    return h


def _need(b):
    if b.get("confirm") is not True:
        raise ApiError("Please confirm first.")


def _run_text(cmd, timeout):
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout, creationflags=core.NO_WINDOW)
    except FileNotFoundError:
        raise ApiError(f"{cmd[0]} is not available on this system.")
    except subprocess.TimeoutExpired:
        raise ApiError("That took too long and was stopped.")
    raw = r.stdout + r.stderr
    return raw.decode("utf-16-le" if raw[:2] == b"\xff\xfe" else "utf-8", "replace").replace("\x00", "")


# --------------------------------------------------------------------------
# Network
# --------------------------------------------------------------------------

_NET_PS = (
    "Get-NetIPConfiguration | ForEach-Object { [pscustomobject]@{ name=$_.InterfaceAlias; "
    "desc=$_.InterfaceDescription; ip=@($_.IPv4Address.IPAddress); gw=@($_.IPv4DefaultGateway.NextHop); "
    "dns=@($_.DNSServer.ServerAddresses); up=[bool]($_.NetAdapter.Status -eq 'Up') } } | ConvertTo-Json -Compress -Depth 3")


@route("GET", r"/api/tech/network")
def r_network(req):
    if IS_WIN:
        rows = core.ps_json(_NET_PS, timeout=45)
    else:
        rows = [{"name": "Ethernet", "desc": "Demo adapter", "ip": ["192.168.1.20"], "gw": ["192.168.1.1"],
                 "dns": ["1.1.1.1", "8.8.8.8"], "up": True}]
    fix = lambda v: [x for x in (v if isinstance(v, list) else [v]) if x]
    return {"items": [{"name": r.get("name") or "", "desc": r.get("desc") or "", "ip": fix(r.get("ip")),
                       "gw": fix(r.get("gw")), "dns": fix(r.get("dns")), "up": bool(r.get("up"))} for r in rows]}


@route("POST", r"/api/tech/ping")
def r_ping(req):
    h = _host(req.body)
    if not IS_WIN:
        return {"output": f"Test mode: would run a ping to {h}.\nReply from {h}: time=12ms (sample)"}
    return {"output": _run_text(["ping", "-n", "4", h], 25)}


@route("POST", r"/api/tech/dns")
def r_dns(req):
    h = _host(req.body)
    if not IS_WIN and h.endswith(".test"):
        return {"addresses": ["203.0.113.7"]}
    try:
        infos = socket.getaddrinfo(h, None)
    except socket.gaierror as e:
        raise ApiError(f"Could not find {h}: {e.strerror or e}")
    return {"addresses": sorted({i[4][0] for i in infos})}


@route("POST", r"/api/tech/port")
def r_port(req):
    h = _host(req.body)
    try:
        port = int(req.body.get("port"))
    except (TypeError, ValueError):
        raise ApiError("Type a port number from 1 to 65535.")
    if not 1 <= port <= 65535:
        raise ApiError("Type a port number from 1 to 65535.")
    t = time.time()
    try:
        with socket.create_connection((h, port), timeout=4):
            return {"open": True, "ms": int((time.time() - t) * 1000)}
    except socket.gaierror:
        raise ApiError(f"Could not find {h}.")
    except OSError:
        return {"open": False, "ms": int((time.time() - t) * 1000)}


def _trace_job(job, host):
    if not IS_WIN:
        job.log(f"Test mode: pretending to trace the route to {host}…")
        time.sleep(1)
        job.log("1  192.168.1.1  2 ms\n2  10.0.0.1  9 ms")
        return "Done (test mode)"
    proc = subprocess.Popen(["tracert", "-d", "-h", "20", host], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            creationflags=core.NO_WINDOW)
    for line in iter(proc.stdout.readline, b""):
        job.log(line.decode("utf-8", "replace"))
    proc.wait()
    return "Trace finished"


@route("POST", r"/api/tech/trace")
def r_trace(req):
    h = _host(req.body)
    return {"job": core.start_job(f"Trace route to {h}", _trace_job, h).id}


_FIXES = {
    "flushdns": ("Clear the DNS cache", [["ipconfig", "/flushdns"]], False),
    "renew": ("Renew the IP address (the connection drops for a few seconds)",
              [["ipconfig", "/release"], ["ipconfig", "/renew"]], False),
    "winsock": ("Reset Winsock (restart needed)", [["netsh", "winsock", "reset"]], True),
    "ipreset": ("Reset the TCP/IP stack (restart needed)", [["netsh", "int", "ip", "reset"]], True),
}


@route("POST", r"/api/tech/netfix")
def r_netfix(req):
    _need(req.body)
    fix = _FIXES.get(req.body.get("action"))
    if not fix:
        raise ApiError("Unknown action.")
    label, cmds, reboot = fix
    if not IS_WIN:
        return {"output": f"Test mode: {label}. Nothing was changed.", "reboot": reboot}
    out = "\n".join(_run_text(c, 60) for c in cmds)
    activity("network fix", label)
    return {"output": out[-1500:], "reboot": reboot}


# --------------------------------------------------------------------------
# Repair
# --------------------------------------------------------------------------

_REPAIRS = {
    "sfc": ("Check Windows system files (SFC)", ["sfc", "/scannow"]),
    "dism": ("Repair the Windows image (DISM)", ["DISM", "/Online", "/Cleanup-Image", "/RestoreHealth"]),
    "chkdsk": ("Scan the system drive for errors (read-only)", ["chkdsk", os.environ.get("SystemDrive", "C:")]),
}


def _repair_job(job, key):
    label, cmd = _REPAIRS[key]
    if not IS_WIN:
        job.log(f"Test mode: pretending to run {' '.join(cmd)}…")
        time.sleep(1.2)
        job.log("Nothing was changed.")
        return "Finished (test mode)"
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=core.NO_WINDOW)
    buf = b""
    for chunk in iter(lambda: proc.stdout.read(128), b""):
        buf += chunk
        parts = re.split(rb"[\r\n]+", buf)
        buf = parts.pop()
        for part in parts:
            line = (part.decode("utf-16-le", "replace") if part[:1] == b"\xff" else part.decode("utf-8", "replace"))
            line = line.replace("\x00", "").strip()
            if len(re.findall(r"[A-Za-z0-9]", line)) >= 3:
                job.log(line)
    code = proc.wait()
    activity("repair", label, "ok" if code == 0 else "failed", f"code {code}")
    if code != 0:
        raise ApiError(f"Finished with code {code}. Read the log above for details.")
    return "Finished without problems"


@route("POST", r"/api/tech/repair")
def r_repair(req):
    _need(req.body)
    key = req.body.get("id")
    if key not in _REPAIRS:
        raise ApiError("Unknown repair.")
    if not core.is_admin() and IS_WIN:
        raise ApiError("This needs administrator permission. Close App Manager and open it again, choosing Yes.")
    return {"job": core.start_job(_REPAIRS[key][0], _repair_job, key).id}


# --------------------------------------------------------------------------
# Windows Update status and admin consoles
# --------------------------------------------------------------------------

_WU_PS = (
    "$s=New-Object -ComObject Microsoft.Update.Session; "
    "$r=$s.CreateUpdateSearcher().Search('IsInstalled=0 and IsHidden=0'); "
    "$r.Updates | ForEach-Object { [pscustomobject]@{ title=$_.Title; kb=($_.KBArticleIDs -join ','); "
    "size=[int64]$_.MaxDownloadSize; reboot=[bool]($_.InstallationBehavior.RebootBehavior -ne 0) } } | ConvertTo-Json -Compress")


def _wu():
    if IS_WIN:
        return core.ps_json(_WU_PS, timeout=240)
    return [{"title": "2026-10 Cumulative Update for Windows 11 (KB5099999)", "kb": "5099999", "size": 612000000,
             "reboot": True},
            {"title": "Security Intelligence Update for Microsoft Defender Antivirus", "kb": "2267602", "size": 1100000,
             "reboot": False}]


WU = Lazy(_wu, ttl=600)


@route("GET", r"/api/tech/wu")
def r_wu(req):
    s = WU.get(force="refresh" in req.query)
    return {"loading": s["loading"], "ready": s["ready"], "error": s["error"], "items": s["data"] or []}


_OPEN = {"windowsupdate": "ms-settings:windowsupdate", "devmgmt": "devmgmt.msc", "services": "services.msc",
         "eventvwr": "eventvwr.msc", "diskmgmt": "diskmgmt.msc", "taskschd": "taskschd.msc",
         "programs": "appwiz.cpl", "network": "ncpa.cpl", "taskmgr": "taskmgr.exe", "msinfo": "msinfo32.exe"}


@route("POST", r"/api/tech/open")
def r_open(req):
    target = _OPEN.get(req.body.get("what"))
    if not target:
        raise ApiError("Unknown tool.")
    if not IS_WIN:
        return {"ok": True, "note": "Test mode: nothing opened."}
    os.startfile(target)                                        # noqa: S606
    return {"ok": True}


@route("POST", r"/api/tech/wu/scan")
def r_wu_scan(req):
    if IS_WIN:
        core.run(["UsoClient", "StartScan"], timeout=20)
    WU.get(force=True)
    activity("windows update scan")
    return {"ok": True}


# --------------------------------------------------------------------------
# PC health report (downloadable HTML)
# --------------------------------------------------------------------------

def _wait(lazy, seconds=75):
    end = time.time() + seconds
    while True:
        s = lazy.get()
        if s["ready"] or (not s["loading"] and s["error"]) or time.time() > end:
            return s["data"]
        time.sleep(0.5)


def build_report():
    from . import hardware, monitor, programs, security, startup, updates
    h = _wait(hardware.HARDWARE) or {}
    devs = _wait(hardware.DEVICES) or []
    progs = _wait(programs.INVENTORY) or []
    st = _wait(startup.STARTUP) or []
    upd = _wait(updates.UPDATES) or []
    sec = security.items_view(_wait(security.STATE) or {}) if _wait(security.STATE) else []
    health = _wait(monitor.HEALTH) or {}
    e = lambda v: html.escape(str(v if v is not None else ""))
    s = h.get("system", {})
    fb = lambda b: f"{b / 1073741824:.1f} GB" if b else ""
    rows = lambda items: "".join(f"<tr>{''.join(f'<td>{e(c)}</td>' for c in r)}</tr>" for r in items)
    probs = [d for d in devs if d.get("problem")]
    parts = [
        f"<h1>PC health report</h1><p class=m>{e(s.get('name'))} · created {time.strftime('%Y-%m-%d %H:%M')} by App Manager {core.VERSION}</p>",
        "<h2>System</h2><table>" + rows([
            ("Computer", s.get("name")), ("Maker / model", f"{s.get('manufacturer', '')} {s.get('model', '')}"),
            ("Windows", f"{s.get('os', '')} {s.get('version', '')} build {s.get('build', '')}"),
            ("BIOS", f"{h.get('bios', {}).get('version', '')} ({h.get('bios', {}).get('date', '')})"),
            ("Board", f"{h.get('board', {}).get('maker', '')} {h.get('board', {}).get('product', '')}"),
            ("Processor", ", ".join(c.get("name", "") for c in h.get("cpu", []))),
            ("Memory", fb(h.get("ram", {}).get("total"))),
            ("Graphics", ", ".join(g.get("name", "") for g in h.get("gpu", []))),
            ("Secure Boot", {True: "On", False: "Off"}.get(h.get("secureboot"), "Unknown"))]) + "</table>",
        "<h2>Drives</h2><table><tr><th>Drive</th><th>Size</th><th>Free</th></tr>" + rows(
            (f"{v.get('drive')} {v.get('label', '')}", fb(v.get("size")), fb(v.get("free")))
            for v in h.get("volumes", [])) + "</table>",
        "<h2>Drive health</h2><table><tr><th>Drive</th><th>Health</th><th>Notes</th></tr>" + rows(
            (d.get("name"), d.get("health"), "; ".join(d.get("notes", [])) or "No problems") for d in health.get("disks", []))
        + "</table>",
        f"<h2>Security ({sum(1 for i in sec if i['status'] == 'ok')} of {sum(1 for i in sec if i['status'] != 'na')} on)</h2>"
        "<table><tr><th>Check</th><th>Status</th><th>Detail</th></tr>" + rows(
            (i["name"], i["status"], i["detail"]) for i in sec) + "</table>",
        f"<h2>Devices with problems ({len(probs)})</h2><table>" + (rows((d["name"], d["problem"]) for d in probs)
                                                                  or "<tr><td>None</td></tr>") + "</table>",
        f"<h2>Program updates available ({len(upd)})</h2><table>" + (rows(
            (u["name"], u["version"], u["available"]) for u in upd) or "<tr><td>None</td></tr>") + "</table>",
        f"<h2>Startup items ({sum(1 for i in st if i.get('enabled'))} on)</h2><table>" + rows(
            (i.get("name"), i.get("where"), "On" if i.get("enabled") else "Off") for i in st) + "</table>",
        f"<h2>Installed programs ({len(progs)})</h2><table><tr><th>Name</th><th>Version</th><th>Publisher</th></tr>" + rows(
            (p["name"], p.get("version"), p.get("publisher")) for p in sorted(progs, key=lambda p: p["name"].lower()))
        + "</table>",
    ]
    css = ("body{font:14px system-ui,Segoe UI,sans-serif;max-width:900px;margin:30px auto;padding:0 16px;color:#14171f}"
           "h1{margin-bottom:0}h2{margin-top:28px;border-bottom:1px solid #ddd;padding-bottom:4px}.m{color:#667085}"
           "table{border-collapse:collapse;width:100%}td,th{padding:5px 8px;border-bottom:1px solid #eee;text-align:left;"
           "vertical-align:top}th{color:#667085;font-size:12px;text-transform:uppercase}")
    return f"<!doctype html><meta charset=utf-8><title>PC health report</title><style>{css}</style>" + "".join(parts)


@route("GET", r"/api/tech/report")
def r_report(req):
    body = build_report().encode("utf-8")
    activity("health report")
    return Raw(body, "text/html; charset=utf-8", {
        "Content-Disposition": f'attachment; filename="pc-report-{time.strftime("%Y%m%d")}.html"'})
