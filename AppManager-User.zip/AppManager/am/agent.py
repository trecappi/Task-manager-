"""The controller: lets this PC be managed by a hub.

It enrolls with a one-time code, then checks in with the hub every so often (this PC calls the hub, so no
port is opened here), reports what it looks like, and carries out the orders the hub sends. Orders are limited
to a fixed list, are checked again here, and the owner of this PC decides which kinds are allowed.
"""

import json
import os
import platform
import re
import secrets
import socket
import threading
import time
import urllib.error
import urllib.request

from . import errors, remote
from .errors import Coded
from . import cleanup, core, hardware, installer, monitor, profiles, programs, proto, security, startup, tech, tweaks, updates
from .core import IS_WIN, ApiError, activity, route

FILE = core.HOME / "agent.json"
HISTORY = core.HOME / "agent_history.json"
POLICY_KEYS = ("profiles", "repair", "cleanup", "install")
NEEDS = {"apply_profile": "profiles", "repair": "repair", "fix_devices": "repair", "restore_point": "repair",
         "cleanup": "cleanup", "install": "install", "update": "install", "refresh_status": None}
LOCK = threading.RLock()


def _load():
    try:
        return json.loads(FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _save(cfg):
    tmp = FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, indent=1), encoding="utf-8")
    tmp.replace(FILE)


# --------------------------------------------------------------------------
# Status report
# --------------------------------------------------------------------------

def _uptime():
    try:
        if IS_WIN:
            import ctypes
            return int(ctypes.windll.kernel32.GetTickCount64() / 1000)
        return int(float(open("/proc/uptime").read().split()[0]))
    except Exception:
        return None


def collect_status():
    """A compact picture of this PC from data App Manager already holds (never blocks on slow reads)."""
    out = {"t": time.time(), "uptime": _uptime(), "os": platform.platform()[:80]}
    hw = hardware.HARDWARE.get()["data"]
    if hw:
        out["hardware"] = {k: hw.get(k) for k in ("system", "bios", "board", "cpu", "gpu", "ram", "disks", "volumes", "secureboot")}
    s = security.STATE.get()["data"]
    if s is not None:
        out["security"] = [{"id": i["id"], "name": i["name"], "status": i["status"]} for i in security.items_view(s)
                           if not i.get("settings")]
    dv = hardware.DEVICES.get()["data"]
    if dv is not None:
        out["problems"] = [{"name": d["name"], "cls": d["cls"], "problem": d["problem"]} for d in dv if d["problem"] and d["present"]][:50]
    up = updates.UPDATES.get()["data"]
    if up is not None:
        out["updates"] = [{"id": u["id"], "name": u["name"], "current": u.get("current", ""), "available": u.get("available", "")} for u in up][:100]
    inv = programs.INVENTORY.get()["data"]
    if inv is not None:
        out["programs"] = {"count": len(inv), "items": [{"n": p["name"], "v": p.get("version", "")} for p in inv][:600]}
    h = monitor.HEALTH.get()["data"]
    if h:
        out["health"] = h
    st = startup.STARTUP.get()["data"]
    if st is not None:
        out["startup"] = {"on": sum(1 for e in st if e["enabled"]), "total": len(st)}
    try:
        out["remote"] = remote.report()
    except Exception as e:
        core.log(f"remote tool scan failed: {e!r}")
    try:
        out["tweaks_on"] = [t["name"] for t in tweaks.list_tweaks() if t["state"] == "on"]
    except Exception:
        pass
    return out


# --------------------------------------------------------------------------
# Orders
# --------------------------------------------------------------------------

def _install_job(job, ids):
    ok = bad = 0
    names = {i: n for i, (n, _) in installer.all_entries().items()}
    for pid in ids:
        job.log(f"--- {names.get(pid, pid)} ---")
        code = installer._run_winget(job, pid)
        if code in (0, 0x8A150061, 0x8A15002B):
            ok += 1
            activity("install", names.get(pid, pid))
        else:
            bad += 1
            job.log(f"winget reported a problem (code {code}).")
            activity("install", names.get(pid, pid), "failed", f"code {code}")
    installer.INSTALLED.get(force=True)
    return f"{ok} installed" + (f", {bad} had problems" if bad else "")


def _refuse(msg):
    raise ApiError(msg)


def start_order(ctype, params, policy):
    """Validate an order again here and start it. Returns the Job (or None for refresh_status)."""
    need = NEEDS.get(ctype, "?")
    if need == "?":
        _refuse("This PC does not know that kind of order.")
    if need and not policy.get(need, False):
        _refuse(f"The owner of this PC has not allowed “{need}” orders from the hub.")
    p = params if isinstance(params, dict) else {}
    if ctype == "refresh_status":
        return None
    if IS_WIN and ctype in ("repair", "cleanup", "install", "update", "apply_profile", "fix_devices", "restore_point") \
            and not core.is_admin():
        _refuse("App Manager on this PC is not running as administrator, so it cannot carry this out.")
    if ctype == "apply_profile":
        prof = profiles.clean(dict(p.get("profile") or {}, id=None))
        return core.start_job(f"Hub: apply profile {prof['name'][:30]}", profiles._apply_job, prof, bool(p.get("restore_point", True)))
    if ctype == "install":
        ids = [i for i in (p.get("ids") or []) if isinstance(i, str) and re.fullmatch(r"[\w.\-+]{3,100}", i) and "." in i][:20]
        if not ids:
            _refuse("No valid programs in this order.")
        if not installer.winget_available():
            _refuse("Windows Package Manager (winget) was not found on this PC.")
        return core.start_job(f"Hub: install {len(ids)} programs", _install_job, ids)
    if ctype == "update":
        if not updates.winget_available():
            _refuse("Windows Package Manager (winget) was not found on this PC.")
        ids = [i for i in (p.get("ids") or []) if isinstance(i, str) and re.fullmatch(r"[\w.\-+]+", i)][:30]
        if not p.get("all") and not ids:
            _refuse("No valid programs in this order.")
        return core.start_job("Hub: update programs", updates._install_job, ids, bool(p.get("all")))
    if ctype == "repair":
        if p.get("what") not in tech._REPAIRS:
            _refuse("Unknown repair.")
        return core.start_job("Hub: " + tech._REPAIRS[p["what"]][0], tech._repair_job, p["what"])
    if ctype == "cleanup":
        ok = {c["id"] for c in cleanup._categories()}
        ids = [i for i in (p.get("ids") or []) if i in ok]
        if not ids:
            _refuse("Nothing valid to clean.")
        return core.start_job("Hub: clean up disk space", cleanup._clean_job, ids)
    if ctype == "fix_devices":
        from . import devfix
        ids = [d["id"] for d in devfix._devices() if d["problem"] and d["present"]][:15]
        if not ids:
            _refuse("No devices have problems.")
        return core.start_job("Hub: fix problem devices", devfix._job, ids, "safe")
    if ctype == "restore_point":
        from . import backup
        return core.start_job("Hub: create restore point", backup._rp_job)
    _refuse("Unknown order.")


# --------------------------------------------------------------------------
# The check-in loop
# --------------------------------------------------------------------------

class Agent:
    def __init__(self):
        self.jobs = {}                 # order id -> Job (running)
        self.done = {}                 # order id -> result waiting to be sent
        self.last_ok = 0.0
        self.last_error = ""
        self.last_code = ""
        self.errlog = []                # recent coded problems [{code, t, d}], newest last; sent to the hub when it can be reached
        self._diag = (0.0, None)        # (when, (code, message)) so the automatic test runs at most once a minute
        self.interval = 30
        self.longpoll = True            # idle check-ins wait on the hub for orders (so they arrive at once)
        self.want_status = True
        self.thread = None
        self.stop = threading.Event()
        self.lock = threading.RLock()

    def cfg(self):
        return _load()

    def note(self, code, detail=""):
        """Remember a coded problem and make it the one shown on the Hub link tab."""
        d = errors.describe(code) or {"title": code}
        with self.lock:
            self.last_code, self.last_error = code, f"{d['title']}" + (f" ({detail})" if detail else "")
            if not self.errlog or self.errlog[-1]["code"] != code or time.time() - self.errlog[-1]["t"] > 300:
                self.errlog.append({"code": code, "t": int(time.time()), "d": str(detail)[:120]})
                del self.errlog[:-10]

    def auto_test(self, hostport):
        """The automatic test after a failed connection: find out why and return the (code, message)."""
        t, hit = self._diag
        if hit and time.time() - t < 60:
            return hit
        hit = diagnose(hostport)
        self._diag = (time.time(), hit)
        return hit

    def enrolled(self):
        return bool(self.cfg().get("key"))

    def start(self):
        if self.enrolled() and not (self.thread and self.thread.is_alive()):
            self.stop.clear()
            self.thread = threading.Thread(target=self._loop, daemon=True)
            self.thread.start()

    def _loop(self):
        for lazy in (hardware.HARDWARE, hardware.DEVICES, security.STATE, updates.UPDATES, programs.INVENTORY,
                     startup.STARTUP, monitor.HEALTH):
            lazy.get()                                   # warm the slow readings before the first report
        self.stop.wait(8)
        while not self.stop.is_set() and self.enrolled():
            try:
                self.checkin_once()
                self.last_error = self.last_code = ""
            except Coded as e:
                self.note(e.code, e.detail)
                core.log(f"hub check-in failed: {e}")
            except Exception as e:
                self.last_error = str(e)[:200]
                core.log(f"hub check-in failed: {e!r}")
            self.stop.wait(max(1, min(self.interval, 120)))

    # -- one round trip --
    def _post(self, cfg, path, body, sign=True, wait=False):
        raw = json.dumps(body).encode()
        headers = {"Content-Type": "application/json"}
        nonce = None
        if sign:
            ts, nonce = int(time.time()), secrets.token_hex(12)
            headers.update({"X-AM-Device": cfg["device_id"], "X-AM-Time": str(ts), "X-AM-Nonce": nonce,
                            "X-AM-Sig": proto.sign_request(cfg["key"], cfg["device_id"], ts, nonce, raw)})
        req = urllib.request.Request(f"http://{cfg['hub']}{path}", data=raw, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=20 + (hub_hold() if wait else 0)) as r:
                data, sig = r.read(), r.headers.get("X-AM-Sig", "")
        except urllib.error.HTTPError as e:
            msg = ""
            try:
                msg = json.loads(e.read()).get("error", "")
            except Exception:
                pass
            if not sign:                                    # enrollment
                raise Coded("AM-E204" if e.code == 429 else "AM-E201" if e.code == 403 else "AM-C302", f"HTTP {e.code}")
            raise Coded({"unknown device": "AM-C301", "stale": "AM-C304", "bad signature": "AM-C305", "replayed": "AM-C305"}
                        .get(msg, "AM-C302"), f"HTTP {e.code}{': ' + msg if msg else ''}")
        except (urllib.error.URLError, OSError, socket.timeout) as e:
            code, text = self.auto_test(cfg["hub"])
            if code == "OK":                                # reachable now: it was a one-off hiccup
                raise Coded("AM-N104", "a request timed out once")
            raise Coded(code, getattr(e, "reason", e) if False else "")
        if sign and not proto.same(proto.sign_response(cfg["key"], nonce, data), sig):
            raise Coded("AM-C303")
        return json.loads(data)

    def checkin_once(self):
        cfg = self.cfg()
        if not cfg.get("key"):
            raise RuntimeError("This PC is not enrolled.")
        with self.lock:
            for oid, job in list(self.jobs.items()):
                if job.status != "running":
                    self.done[oid] = {"id": oid, "status": "done" if job.status == "done" else "error",
                                      "result": job.result if job.status == "done" else errors.msg("AM-O402", job.result), "log": job.lines[-40:]}
                    self.jobs.pop(oid)
            results = list(self.done.values())
            active = [{"id": oid, "line": (j.lines[-1] if j.lines else "")} for oid, j in self.jobs.items()]
        body = {"hb": {"os": platform.platform()[:80], "version": core.VERSION, "admin": core.is_admin(),
                       "policy": cfg.get("policy", {}), "errors": list(self.errlog)},
                "name": cfg.get("name", ""), "results": results, "active": active}
        if self.want_status:
            body["status"] = collect_status()
        idle = self.longpoll and not results and not active and not self.want_status
        body["wait"] = bool(idle)
        reply = self._post(cfg, "/hub/checkin", body, wait=idle)
        with self.lock:
            for r in results:
                self.done.pop(r["id"], None)
            self.last_ok = time.time()
            self.interval = int(reply.get("interval") or 30)
            self.want_status = bool(reply.get("want_status"))
            for c in (reply.get("commands") or [])[:20]:
                self._take(c, cfg)
        return reply

    def _take(self, c, cfg):
        oid, ctype = str(c.get("id", "")), str(c.get("type", ""))
        if not re.fullmatch(r"[0-9a-f]{12}", oid) or oid in self.jobs or oid in self.done:
            return
        policy = {k: bool(cfg.get("policy", {}).get(k)) for k in POLICY_KEYS}
        core.CTX.user = {"username": "hub", "admin": True}
        try:
            job = start_order(ctype, c.get("params"), policy)
            if job is None:                                 # refresh_status
                self.want_status = True
                self.done[oid] = {"id": oid, "status": "done", "result": "Status will be sent now.", "log": []}
            else:
                self.jobs[oid] = job
            state = "started"
        except ApiError as e:
            self.done[oid] = {"id": oid, "status": "refused", "result": errors.msg("AM-O401", e.msg), "log": []}
            state = "refused: " + e.msg
        finally:
            core.CTX.user = None
        activity("hub order: " + ctype, state[:80], "ok" if not state.startswith("refused") else "failed")


def hub_hold():
    return proto.HOLD + 10


AGENT = Agent()


def recent():
    with AGENT.lock:
        return [{"id": o, "state": "running", "line": (j.lines[-1] if j.lines else ""), "title": j.title} for o, j in AGENT.jobs.items()]


# --------------------------------------------------------------------------
# Routes (administrator of this PC only: not in the technician access table)
# --------------------------------------------------------------------------

@route("GET", r"/api/agent")
def r_state(req):
    c = _load()
    return {"enrolled": bool(c.get("key")), "hub": c.get("hub", ""), "hub_name": c.get("hub_name", ""),
            "name": c.get("name", socket.gethostname()), "policy": c.get("policy", {k: True for k in POLICY_KEYS}),
            "last_ok": AGENT.last_ok, "error": AGENT.last_error, "error_code": AGENT.last_code,
            "errors": [dict(e, **{k: v for k, v in (errors.describe(e["code"]) or {}).items() if k != "code"}) for e in reversed(AGENT.errlog)], "interval": AGENT.interval, "running": recent(),
            "default_name": socket.gethostname()}


def diagnose(hostport):
    """Find out why a hub cannot be reached. Returns (code, plain message); code is "OK" when it can be reached."""
    def out(code, extra=""):
        d = errors.describe(code)
        return code, f"[{code}] {d['title']}. {d['cause']} {d['fix']}" + (f" ({extra})" if extra else "")
    host, _, port = hostport.rpartition(":")
    try:
        port = int(port)
    except ValueError:
        return out("AM-N101")
    if host in ("127.0.0.1", "localhost", "::1"):
        return out("AM-N102")
    try:
        ip = socket.gethostbyname(host)
    except OSError:
        return out("AM-N103", host)
    t0 = time.time()
    try:
        c = socket.create_connection((ip, port), timeout=6)
        c.close()
    except socket.timeout:
        return out("AM-N104", f"{host}:{port}")
    except ConnectionRefusedError:
        return out("AM-N105", f"{host}:{port}")
    except OSError as e:
        return out("AM-N106", e.strerror or str(e))
    try:
        with urllib.request.urlopen(f"http://{ip}:{port}/hub/ping", timeout=6) as r:
            if json.loads(r.read()).get("app") == "appmgr-hublink":
                return "OK", f"The hub at {host}:{port} is reachable ({int((time.time() - t0) * 1000)} ms)."
    except (urllib.error.URLError, OSError, ValueError):
        pass
    return out("AM-N107", f"{host}:{port}")


@route("POST", r"/api/agent/test")
def r_test(req):
    try:
        hostport = proto.decode_code(str(req.body.get("code", "")))[0]
    except ValueError as e:
        raise ApiError(str(e))
    code, msg = diagnose(hostport)
    if code != "OK":
        AGENT.note(code)
    return {"ok": code == "OK", "code": code, "message": msg}


@route("POST", r"/api/agent/enroll")
def r_enroll(req):
    if _load().get("key"):
        raise ApiError(errors.msg("AM-E203", "This PC is already managed by a hub. Open Hub link and choose Stop being managed first."))
    try:
        hostport, tid, secret, hub_name = proto.decode_code(str(req.body.get("code", "")))
    except ValueError as e:
        raise ApiError(str(e))
    name = re.sub(r"[^\w .-]", "", str(req.body.get("name") or socket.gethostname()))[:40] or "PC"
    dev = {"name": name, "uid": secrets.token_hex(8), "os": platform.platform()[:80], "version": core.VERSION,
           "admin": core.is_admin()}
    cn = secrets.token_hex(8)
    dev_json = json.dumps(dev, sort_keys=True, separators=(",", ":"))
    body = {"token_id": tid, "cn": cn, "device": dev, "mac": proto.enroll_proof(secret, cn, dev_json)}
    cfg = {"hub": hostport}
    try:
        reply = AGENT._post(cfg, "/hub/enroll", body, sign=False)
    except Coded as e:
        AGENT.note(e.code, e.detail)
        d = errors.describe(e.code)
        raise ApiError(f"[{e.code}] {d['title']}. {d['cause']} {d['fix']}")
    except RuntimeError as e:
        raise ApiError(str(e))
    if not proto.same(proto.hub_proof(secret, cn, str(reply.get("sn")), str(reply.get("device_id"))), str(reply.get("proof"))):
        AGENT.note("AM-E202")
        d = errors.describe("AM-E202")
        raise ApiError(f"[AM-E202] {d['title']}. {d['cause']} {d['fix']}")
    key = proto.derive_key(secret, cn, str(reply["sn"]))
    _save({"hub": hostport, "hub_name": str(reply.get("hub_name", hub_name))[:60], "device_id": str(reply["device_id"]),
           "key": key, "name": name, "policy": {k: True for k in POLICY_KEYS}})
    AGENT.want_status, AGENT.last_error = True, ""
    AGENT.start()
    activity("enrolled with hub", hostport)
    return {"ok": True}


@route("POST", r"/api/agent/leave")
def r_leave(req):
    if req.body.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    AGENT.stop.set()
    try:
        FILE.unlink()
    except OSError:
        pass
    activity("left hub")
    return {"ok": True}


@route("POST", r"/api/agent/policy")
def r_policy(req):
    c = _load()
    if not c.get("key"):
        raise ApiError("This PC is not managed by a hub.")
    c["policy"] = {k: bool(req.body.get(k, c.get("policy", {}).get(k, True))) for k in POLICY_KEYS}
    _save(c)
    activity("hub permissions changed", ", ".join(k for k, v in c["policy"].items() if v) or "none")
    return {"policy": c["policy"]}
