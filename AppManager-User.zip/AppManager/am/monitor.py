"""Live monitor: CPU, memory and network graphs, busiest programs, drive and battery health.

Sampling only runs while the Monitor tab is open (it stops 90 seconds after the last
request), so it costs nothing the rest of the time. Everything uses built-in Windows
features; no extra helper programs are needed.
"""

import os
import re
import subprocess
import threading
import time
from collections import deque

from . import core
from .core import IS_WIN, Lazy, route

INTERVAL = 2.0
IDLE_STOP = 90.0
KEEP = 150


# --------------------------------------------------------------------------
# Raw readings
# --------------------------------------------------------------------------

class _Cpu:
    """CPU load between two calls."""

    def __init__(self):
        self.prev = None

    def read(self):
        if IS_WIN:
            import ctypes
            from ctypes import wintypes
            idle, kern, user = (wintypes.FILETIME() for _ in range(3))
            ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kern), ctypes.byref(user))
            q = lambda f: (f.dwHighDateTime << 32) | f.dwLowDateTime
            cur = (q(idle), q(kern) + q(user))          # kernel time already includes idle time
        else:
            with open("/proc/stat", encoding="utf-8") as f:
                v = [int(x) for x in f.readline().split()[1:8]]
            cur = (v[3] + v[4], sum(v))
        prev, self.prev = self.prev, cur
        if not prev or cur[1] == prev[1]:
            return None
        return max(0.0, min(100.0, 100.0 * (1 - (cur[0] - prev[0]) / (cur[1] - prev[1]))))


def read_memory():
    """-> (used_bytes, total_bytes)"""
    if IS_WIN:
        import ctypes

        class MS(ctypes.Structure):
            _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong), ("total", ctypes.c_ulonglong),
                        ("avail", ctypes.c_ulonglong), ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong),
                        ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong), ("ae", ctypes.c_ulonglong)]
        m = MS()
        m.l = ctypes.sizeof(MS)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        return m.total - m.avail, m.total
    info = {}
    with open("/proc/meminfo", encoding="utf-8") as f:
        for line in f:
            k, _, v = line.partition(":")
            info[k] = int(v.split()[0]) * 1024
    return info["MemTotal"] - info.get("MemAvailable", info["MemFree"]), info["MemTotal"]


def read_net():
    """-> (bytes received, bytes sent) summed over real adapters, or None."""
    if IS_WIN:
        try:
            import ctypes
            from ctypes import wintypes
            size = wintypes.ULONG(0)
            ctypes.windll.iphlpapi.GetIfTable(None, ctypes.byref(size), False)
            buf = ctypes.create_string_buffer(size.value)
            if ctypes.windll.iphlpapi.GetIfTable(buf, ctypes.byref(size), False) != 0:
                return None
            import struct
            n = struct.unpack_from("<I", buf, 0)[0]
            rx = tx = 0
            for i in range(n):
                off = 4 + i * 860                       # MIB_IFROW is 860 bytes
                typ, = struct.unpack_from("<I", buf, off + 516)
                oper, = struct.unpack_from("<I", buf, off + 544)
                if typ == 24 or oper not in (4, 5):     # skip loopback and adapters that are down
                    continue
                rx += struct.unpack_from("<I", buf, off + 552)[0]
                tx += struct.unpack_from("<I", buf, off + 576)[0]
            return rx, tx
        except Exception as e:
            core.log(f"net read failed: {e!r}")
            return None
    rx = tx = 0
    try:
        with open("/proc/net/dev", encoding="utf-8") as f:
            for line in list(f)[2:]:
                name, _, rest = line.partition(":")
                if name.strip() == "lo":
                    continue
                cols = rest.split()
                rx, tx = rx + int(cols[0]), tx + int(cols[8])
    except OSError:
        return None
    return rx, tx


_PROC_PS = (
    "Get-CimInstance Win32_PerfFormattedData_PerfProc_Process | Where-Object { $_.Name -ne '_Total' -and "
    "$_.Name -ne 'Idle' } | Sort-Object PercentProcessorTime -Descending | Select-Object -First 60 | "
    "ForEach-Object { [pscustomobject]@{ n=$_.Name; c=[double]$_.PercentProcessorTime; "
    "m=[int64]$_.WorkingSetPrivate } } | ConvertTo-Json -Compress")


def top_processes(limit=12):
    rows = []
    if IS_WIN:
        cores = os.cpu_count() or 1
        for r in core.ps_json(_PROC_PS, timeout=30):
            rows.append((re.sub(r"#\d+$", "", r["n"]), r["c"] / cores, r["m"]))
    else:
        out = subprocess.run(["ps", "-eo", "comm,pcpu,rss", "--sort=-pcpu", "--no-headers"],
                             capture_output=True, text=True, timeout=10).stdout
        for line in out.splitlines()[:60]:
            p = line.rsplit(None, 2)
            if len(p) == 3:
                rows.append((p[0], float(p[1]) / (os.cpu_count() or 1), int(p[2]) * 1024))
    agg = {}
    for name, cpu, mem in rows:
        a = agg.setdefault(name.lower(), {"name": name, "cpu": 0.0, "mem": 0, "count": 0})
        a["cpu"] += cpu
        a["mem"] += mem
        a["count"] += 1
    out = sorted(agg.values(), key=lambda a: (a["cpu"], a["mem"]), reverse=True)[:limit]
    for a in out:
        a["cpu"] = round(a["cpu"], 1)
    return out


# --------------------------------------------------------------------------
# Sampler thread (runs only while someone is watching)
# --------------------------------------------------------------------------

class Sampler:
    def __init__(self):
        self.samples = deque(maxlen=KEEP)
        self.procs = []
        self.last_touch = 0.0
        self.thread = None
        self.lock = threading.Lock()

    def touch(self):
        with self.lock:
            self.last_touch = time.time()
            if not (self.thread and self.thread.is_alive()):
                self.thread = threading.Thread(target=self.run, daemon=True)
                self.thread.start()

    def run(self):
        cpu, net_prev, tick = _Cpu(), None, 0
        cpu.read()
        while time.time() - self.last_touch < IDLE_STOP:
            time.sleep(INTERVAL)
            now = time.time()
            try:
                used, total = read_memory()
                net = read_net()
                rx = tx = None
                if net and net_prev:
                    dt = max(now - net_prev[2], 0.1)
                    rx = ((net[0] - net_prev[0]) % 2 ** 32) / dt        # 32-bit counters wrap around
                    tx = ((net[1] - net_prev[1]) % 2 ** 32) / dt
                net_prev = (net[0], net[1], now) if net else None
                self.samples.append({"t": now, "cpu": cpu.read(), "mem_used": used, "mem_total": total,
                                     "rx": rx, "tx": tx})
                if tick % 2 == 0:
                    self.procs = top_processes()
                tick += 1
            except Exception as e:
                core.log(f"monitor sample failed: {e!r}")


SAMPLER = Sampler()


# --------------------------------------------------------------------------
# Health: drives (SMART-style counters), temperatures, battery
# --------------------------------------------------------------------------

_HEALTH_PS = r"""
$r=@{}
try{ $r.disks=@(Get-PhysicalDisk | ForEach-Object { $c=$_ | Get-StorageReliabilityCounter; @{ name=$_.FriendlyName; type=[string]$_.MediaType; health=[string]$_.HealthStatus; temp=$c.Temperature; wear=$c.Wear; hours=$c.PowerOnHours; rerr=$c.ReadErrorsTotal; werr=$c.WriteErrorsTotal } }) }catch{}
try{ $r.temps=@(Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature | ForEach-Object { [math]::Round($_.CurrentTemperature/10-273.15,1) }) }catch{}
try{ $b=Get-CimInstance Win32_Battery; if($b){ $r.battery=@{ charge=[int]$b.EstimatedChargeRemaining; status=[int]$b.BatteryStatus } } }catch{}
$r | ConvertTo-Json -Depth 4 -Compress
"""


def _health():
    if IS_WIN:
        raw = core.ps_obj(_HEALTH_PS, timeout=90)
    else:
        raw = {"disks": [{"name": "Demo SSD 1TB", "type": "SSD", "health": "Healthy", "temp": 38, "wear": 4,
                          "hours": 5120, "rerr": 0, "werr": 0},
                         {"name": "Demo HDD 2TB", "type": "HDD", "health": "Warning", "temp": 47, "wear": None,
                          "hours": 41000, "rerr": 12, "werr": 0}],
               "temps": [52.0], "battery": {"charge": 81, "status": 2}}
    disks = []
    for d in raw.get("disks") or []:
        notes = []
        if d.get("health") and d["health"] != "Healthy":
            notes.append(f"Windows reports its health as {d['health']}")
        if (d.get("rerr") or 0) > 0 or (d.get("werr") or 0) > 0:
            notes.append(f"{(d.get('rerr') or 0) + (d.get('werr') or 0)} read/write errors recorded")
        if d.get("wear") is not None and d["wear"] >= 80:
            notes.append(f"{d['wear']}% of its rated life used")
        if d.get("temp") and d["temp"] >= 60:
            notes.append(f"running hot ({d['temp']} °C)")
        disks.append({**d, "notes": notes})
    temps = raw.get("temps") or []
    bat = raw.get("battery")
    return {"disks": disks, "temps": temps, "battery": bat}


HEALTH = Lazy(_health, ttl=120)


@route("GET", r"/api/monitor")
def r_monitor(req):
    SAMPLER.touch()
    h = HEALTH.get(force="refresh" in req.query)
    return {"samples": list(SAMPLER.samples)[-90:], "procs": SAMPLER.procs, "interval": INTERVAL,
            "cores": os.cpu_count() or 1, "health": h["data"], "health_loading": h["loading"],
            "health_error": h["error"]}
