"""Error codes. A code like AM-N104 is shown on the PC where something went wrong; the hub can look it up here.

Letters: N network, E enrollment, C check-in, O orders, R remote tools, H hub. The text is the same on both sides.
"""
import re
import time

from .core import route

CODES = {
    # --- reaching the hub ---
    "AM-N101": ("The code has no usable address", "The enrollment code holds a hub address with a missing or wrong port.",
                "Make a new enrollment code on the hub and copy all of it."),
    "AM-N102": ("The code points at the hub PC itself (127.0.0.1)", "The code was made with the loopback address, which means 'this PC' on whichever PC reads it.",
                "On the hub, make a new code and choose the hub's network address (192.168.x.x) or its Tailscale address (100.x.x.x)."),
    "AM-N103": ("The hub's name could not be looked up", "The code uses a computer name and this PC cannot turn it into an address.",
                "Make a new code that uses the hub's numeric address instead of its name."),
    "AM-N104": ("Nothing answered (timed out)", "The PC could not open a connection to the hub's port. Usually the hub PC's firewall is blocking it, the PCs are on different networks, or the address is wrong.",
                "Run the hub as administrator so it can open its firewall port. On different networks, put both PCs on Tailscale and use the hub's Tailscale address. Check the hub says 'Listening on port ...'."),
    "AM-N105": ("Connection refused", "The hub PC answered but nothing is listening on that port.",
                "On the hub, turn the hub on (Devices tab) and check the port matches the one in the code. Make a new code after changing the port."),
    "AM-N106": ("The network blocked the connection", "The operating system reported a network error (no route, network unreachable, VPN down).",
                "Check this PC is online and on the same network or VPN as the hub, then press Test connection."),
    "AM-N107": ("That address is not an App Manager Hub", "Something answered, but it did not reply like a hub.",
                "Check the port in the code. Make a new code on the hub."),
    # --- enrolling ---
    "AM-E201": ("The hub did not accept the enrollment code", "The code is wrong, has expired, or was already used (each code works once).",
                "Make a new enrollment code on the hub and use it within its time limit."),
    "AM-E202": ("The hub's reply could not be trusted", "The reply did not match the code, so enrollment was cancelled. The code may belong to a different hub.",
                "Make a new code on the hub you mean to use and try again."),
    "AM-E203": ("This PC is already managed", "It is already enrolled with a hub.", "Open Hub link and choose Stop being managed first."),
    "AM-E204": ("Too many attempts", "The hub blocks an address for a minute after repeated bad enrollment attempts.", "Wait a minute, then use a fresh code."),
    # --- check-ins ---
    "AM-C301": ("The hub no longer knows this PC", "The device was removed from the hub, or the hub's data was reset.",
                "On this PC choose Stop being managed, then enroll again with a new code."),
    "AM-C302": ("The hub refused the check-in", "The hub answered with an error that is not one of the specific cases.", "Look at the hub's activity log, then restart the hub. If it continues, enroll again."),
    "AM-C303": ("The hub's reply had the wrong signature", "The reply was changed on the way or came from a different hub.", "Check the address is really your hub. If it is, enroll again."),
    "AM-C304": ("The clocks differ too much", "The hub refuses check-ins whose time is more than 5 minutes off its own.", "Set the date, time and time zone correctly on this PC and the hub PC (Windows: sync now)."),
    "AM-C305": ("The signature did not match", "This PC's key does not match the hub's, or a request was repeated.", "Enroll this PC again."),
    # --- orders ---
    "AM-O401": ("The PC refused the order", "The owner of this PC has not allowed that kind of order.", "On the PC open Hub link and tick the kind of order, or send a different one."),
    "AM-O402": ("The order failed on the PC", "The order started but a step failed. The order's log on the hub says which.", "Open the device on the hub, read the order's log, and try again."),
    # --- remote tools ---
    "AM-R501": ("The remote tool is not installed", "The program is missing on the PC that has to run it (the hub PC for Connect, the managed PC for its ID).", "Install it from the Remote support tab."),
    "AM-R502": ("The remote tool would not start", "Windows could not start the program.", "Open the program yourself once, then try again."),
    "AM-R503": ("winget was not found", "Windows Package Manager is needed for installing programs.", "Install 'App Installer' from the Microsoft Store, or install the program from its website."),
    "AM-R504": ("winget could not install the program", "winget reported a failure. For UltraViewer, AnyViewer and Remote Utilities the winget ID has not been verified.", "Install the program from its website."),
    "AM-R505": ("No ID known for that PC", "The PC has not reported an ID for that tool and none was typed in.", "Type the ID on the device's window, or open the tool on the PC and read the ID."),
    # --- hub ---
    "AM-H601": ("The hub could not listen on its port", "Another program uses the port, or Windows refused it.", "Choose another port (1024-65535) and make new codes."),
}
CODE_RX = re.compile(r"AM-[A-Z]\d{3}")


def msg(code, text):
    return f"[{code}] {text}"


def describe(code):
    code = str(code or "").strip().upper()
    if not CODE_RX.fullmatch(code):
        return None
    t = CODES.get(code)
    if not t:
        return {"code": code, "title": "Unknown code", "cause": "This code is not in this version's list. The PC may run a newer App Manager.", "fix": "Update the hub and the PC to the same version."}
    return {"code": code, "title": t[0], "cause": t[1], "fix": t[2]}


class Coded(RuntimeError):
    """An error that carries a code."""

    def __init__(self, code, detail=""):
        self.code, self.detail = code, detail
        super().__init__(msg(code, (describe(code) or {}).get("title", "") + (f" ({detail})" if detail else "")))


@route("GET", r"/api/errors")
def r_list(req):
    q = str(req.query.get("code", "")).strip()
    if q:
        d = describe(q if q.upper().startswith("AM-") else "AM-" + q)
        if not d:
            from .core import ApiError
            raise ApiError("That is not an error code. They look like AM-N104.")
        return {"item": d}
    return {"items": [dict(describe(c)) for c in sorted(CODES)]}
