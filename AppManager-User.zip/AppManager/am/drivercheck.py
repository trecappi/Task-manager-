"""Driver check: read this PC's identity, look for newer drivers, compare, report.

Two sources, both read-only (nothing is ever downloaded or installed here):

* Microsoft Update Catalog, searched by each device's hardware ID.
* The PC maker's own site. ASUS laptops have a real adapter (the same JSON service
  ASUS's own support page uses). Every other maker gets a link to its support page
  with the serial number or model already known.

Both services are third-party web endpoints that can change without notice, so the
parsers are defensive and the screen labels results as "possible updates".
"""

import json
import re
import time
import urllib.parse
import urllib.request
from html.parser import HTMLParser

from . import core
from .core import IS_WIN, ApiError, activity, route

UA = "Mozilla/5.0 (compatible; AppManager)"
CACHE = core.HOME / "drivercheck.json"
MAX_CATALOG_DEVICES = 30

# --------------------------------------------------------------------------
# Identity
# --------------------------------------------------------------------------

_ID_SCRIPT = r"""
$r=@{}
try{ $b=Get-CimInstance Win32_BIOS; $r.bios_serial=$b.SerialNumber; $r.bios_version=$b.SMBIOSBIOSVersion }catch{}
try{ $bb=Get-CimInstance Win32_BaseBoard; $r.board_maker=$bb.Manufacturer; $r.board_product=$bb.Product; $r.board_serial=$bb.SerialNumber }catch{}
try{ $cs=Get-CimInstance Win32_ComputerSystem; $r.maker=$cs.Manufacturer; $r.model=$cs.Model; $r.sku=$cs.SystemSKUNumber }catch{}
try{ $r.product_serial=(Get-CimInstance Win32_ComputerSystemProduct).IdentifyingNumber }catch{}
try{ $r.build=[int](Get-CimInstance Win32_OperatingSystem).BuildNumber }catch{}
$r | ConvertTo-Json -Compress
"""

_BAD_SERIALS = {"", "none", "default string", "to be filled by o.e.m.", "system serial number",
                "not applicable", "n/a", "0", "123456789", "type2 - board serial number"}


def _clean(s):
    s = (s or "").strip()
    return "" if s.lower() in _BAD_SERIALS else s


def identity():
    if IS_WIN:
        r = core.ps_obj(_ID_SCRIPT, timeout=60)
    else:
        from . import fake
        r = fake.identity()
    maker = (r.get("maker") or r.get("board_maker") or "").strip()
    serial = _clean(r.get("product_serial")) or _clean(r.get("bios_serial")) or _clean(r.get("board_serial"))
    return {"maker": maker, "model": (r.get("model") or "").strip(),
            "board_maker": (r.get("board_maker") or "").strip(),
            "board": (r.get("board_product") or "").strip(),
            "serial": serial, "board_serial": _clean(r.get("board_serial")),
            "sku": _clean(r.get("sku")), "bios": r.get("bios_version") or "",
            "build": int(r.get("build") or 0), "brand": brand_of(maker or r.get("board_maker") or "")}


def brand_of(text):
    t = (text or "").lower()
    for key, name in (("asus", "asus"), ("dell", "dell"), ("hewlett", "hp"), ("hp", "hp"),
                      ("lenovo", "lenovo"), ("micro-star", "msi"), ("msi", "msi"), ("acer", "acer"),
                      ("gigabyte", "gigabyte"), ("samsung", "samsung"), ("microsoft", "microsoft")):
        if key in t:
            return name
    return "other"


# --------------------------------------------------------------------------
# Versions
# --------------------------------------------------------------------------

def vtuple(v):
    """'31.0.101.5333' -> (31, 0, 101, 5333). Returns None if there is no number in it."""
    nums = re.findall(r"\d+", str(v or ""))
    return tuple(int(n) for n in nums[:6]) if nums else None


def newer(candidate, installed):
    a, b = vtuple(candidate), vtuple(installed)
    if a is None or b is None:
        return None
    n = max(len(a), len(b))
    return a + (0,) * (n - len(a)) > b + (0,) * (n - len(b))


def strip_rev(hwid):
    return re.sub(r"&REV_[0-9A-F]+.*$", "", hwid or "", flags=re.I)


# --------------------------------------------------------------------------
# Installed drivers (with hardware IDs)
# --------------------------------------------------------------------------

_LOCAL_SCRIPT = (
    "Get-CimInstance Win32_PnPSignedDriver | Where-Object { $_.DriverVersion -and $_.HardWareID } | "
    "ForEach-Object { [pscustomobject]@{ name=$_.DeviceName; cls=$_.DeviceClass; maker=$_.Manufacturer; "
    "provider=$_.DriverProviderName; version=$_.DriverVersion; "
    "date=$(if($_.DriverDate){([datetime]$_.DriverDate).ToString('yyyy-MM-dd')}else{$null}); "
    "hwid=@($_.HardWareID) } } | ConvertTo-Json -Compress -Depth 3")


def local_drivers():
    if IS_WIN:
        rows = core.ps_json(_LOCAL_SCRIPT, timeout=180)
    else:
        from . import fake
        rows = fake.local_drivers()
    out = []
    for r in rows:
        ids = r.get("hwid") or []
        if isinstance(ids, str):
            ids = [ids]
        out.append({"name": r.get("name") or "", "cls": r.get("cls") or "", "maker": r.get("maker") or "",
                    "provider": r.get("provider") or "", "version": r.get("version") or "",
                    "date": r.get("date") or "", "hwids": [strip_rev(i) for i in ids if i]})
    return out


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------

def http_get(url, timeout=25):
    if not IS_WIN:                              # test mode: no real network calls
        from . import fake
        return fake.http(url)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Encoding": "identity"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


# --------------------------------------------------------------------------
# Microsoft Update Catalog
# --------------------------------------------------------------------------

class _CatalogParser(HTMLParser):
    """Reads the results table (id=ctl00_catalogBody_updateMatches): one dict per row."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.in_table = 0
        self.rows, self._row, self._cell, self._cells = [], None, None, None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "table" and a.get("id") == "ctl00_catalogBody_updateMatches":
            self.in_table = 1
        elif self.in_table:
            if tag == "table":
                self.in_table += 1
            elif tag == "tr":
                self._cells, self._row = [], {"id": (a.get("id") or "").split("_")[0]}
            elif tag == "td" and self._cells is not None:
                self._cell = {"text": "", "input": ""}
            elif tag == "input" and self._cell is not None and a.get("id"):
                self._cell["input"] = a["id"]

    def handle_endtag(self, tag):
        if not self.in_table:
            return
        if tag == "td" and self._cell is not None:
            self._cells.append(self._cell)
            self._cell = None
        elif tag == "tr" and self._cells is not None:
            if len(self._cells) >= 7:
                c = [re.sub(r"\s+", " ", x["text"]).strip() for x in self._cells]
                self.rows.append({"id": self._cells[7]["input"] if len(self._cells) > 7 and self._cells[7]["input"]
                                  else self._row["id"],
                                  "title": c[1], "products": c[2], "classification": c[3],
                                  "updated": c[4], "version": c[5]})
            self._cells = self._row = None
        elif tag == "table":
            self.in_table -= 1

    def handle_data(self, data):
        if self._cell is not None:
            self._cell["text"] += data


def parse_catalog(html):
    p = _CatalogParser()
    p.feed(html)
    out = []
    for r in p.rows:
        m = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", r["updated"])
        r["updated_iso"] = f"{m.group(3)}-{int(m.group(1)):02d}-{int(m.group(2)):02d}" if m else ""
        out.append(r)
    return out


def catalog_search(hwid):
    q = urllib.parse.quote(hwid)
    html = http_get(f"https://www.catalog.update.microsoft.com/Search.aspx?q={q}")
    if "ctl00_catalogBody_updateMatches" not in html:
        return []
    return parse_catalog(html)


def best_catalog_match(rows, build):
    """Newest driver listing for this Windows generation."""
    gen = "Windows 11" if build >= 22000 else "Windows 10"
    best = None
    for r in rows:
        if "driver" not in r["classification"].lower() and "driver" not in r["products"].lower():
            continue
        if "Windows" in r["products"] and gen not in r["products"] and "Windows 10" not in r["products"]:
            continue
        if vtuple(r["version"]) is None:
            continue
        if best is None or newer(r["version"], best["version"]) or (
                not newer(best["version"], r["version"]) and r["updated_iso"] > best["updated_iso"]):
            best = r
    return best


_CATALOG_CLASSES = {"display", "net", "media", "bluetooth", "hdc", "scsiadapter", "system",
                    "camera", "biometric", "sensor", "image", "usb", "hidclass", "firmware"}


def catalog_targets(drivers):
    """Real hardware only (PCI or USB), one lookup per distinct device model."""
    seen, out = set(), []
    for d in drivers:
        if (d["cls"] or "").lower() not in _CATALOG_CLASSES:
            continue
        hw = next((h for h in d["hwids"] if re.match(r"(PCI|USB|HDAUDIO)\\", h, re.I)), None)
        if not hw or hw.upper() in seen or not vtuple(d["version"]):
            continue
        seen.add(hw.upper())
        out.append((hw, d))
    return out[:MAX_CATALOG_DEVICES]


def run_catalog(job, drivers, build):
    found, targets = [], catalog_targets(drivers)
    job.log(f"Asking Microsoft Update Catalog about {len(targets)} devices…")
    for n, (hw, d) in enumerate(targets, 1):
        job.log(f"[{n}/{len(targets)}] {d['name'] or hw}")
        try:
            hit = best_catalog_match(catalog_search(hw), build)
        except Exception as e:
            job.log(f"   no answer ({str(e)[:80]})")
            if n == 1 and not found:
                raise ApiError("Could not reach Microsoft Update Catalog. Check the internet connection.")
            continue
        time.sleep(0.6)
        if not hit:
            continue
        is_new = newer(hit["version"], d["version"])
        if is_new and d["date"] and hit["updated_iso"] and hit["updated_iso"] <= d["date"]:
            is_new = False                      # listed before the installed driver was built
        found.append({"source": "catalog", "device": d["name"], "cls": d["cls"],
                      "installed": d["version"], "installed_date": d["date"],
                      "available": hit["version"], "available_date": hit["updated_iso"],
                      "title": hit["title"], "status": "newer" if is_new else "current",
                      "url": "https://www.catalog.update.microsoft.com/Search.aspx?q=" + urllib.parse.quote(hw),
                      "hwid": hw})
    return found


# --------------------------------------------------------------------------
# Vendor adapters
# --------------------------------------------------------------------------

def support_link(ident):
    b, sn, model = ident["brand"], ident["serial"], ident["model"] or ident["board"]
    q = urllib.parse.quote
    links = {
        "asus": ("ASUS Support", "https://www.asus.com/support/download-center/"),
        "dell": ("Dell Support", f"https://www.dell.com/support/home/en-us/product-support/servicetag/{q(sn)}/drivers"
                 if sn else "https://www.dell.com/support/home/en-us/products"),
        "hp": ("HP Support", "https://support.hp.com/us-en/drivers"),
        "lenovo": ("Lenovo Support", f"https://pcsupport.lenovo.com/us/en/search?query={q(sn)}" if sn
                   else "https://pcsupport.lenovo.com/"),
        "msi": ("MSI Support", "https://www.msi.com/support/download/"),
        "acer": ("Acer Support", "https://www.acer.com/us-en/support/drivers-and-manuals"),
        "gigabyte": ("Gigabyte Support", "https://www.gigabyte.com/Support"),
        "samsung": ("Samsung Support", "https://www.samsung.com/us/support/downloads/"),
        "microsoft": ("Surface downloads", "https://support.microsoft.com/surface/download-drivers-and-firmware-for-surface-09bb2e09-2a4b-cb69-0951-078a7739e120"),
    }
    name, url = links.get(b, ("", ""))
    if not url:
        url = "https://www.bing.com/search?q=" + q(f"{ident['maker']} {model} drivers")
        name = "Search for drivers"
    return {"name": name, "url": url}


def asus_candidates(ident):
    """Model codes to try. The service wants the short family code (e.g. GA503), not the full name."""
    out = []
    for raw in (ident["board"], ident["model"]):
        for tok in re.findall(r"[A-Za-z]{1,3}\d{3,4}[A-Za-z0-9]*", raw or ""):
            tok = tok.split("_")[0]
            for c in (tok[:5], tok[:6], tok):
                if c and c.upper() not in out:
                    out.append(c.upper())
    return out[:5]


def parse_asus(payload):
    """ASUS service JSON: Result.Obj[] -> groups with Files[]. Returns normalized entries."""
    data = json.loads(payload) if isinstance(payload, str) else payload
    result = data.get("Result") or {}
    groups = result.get("Obj") if isinstance(result, dict) else None
    out, last = [], None
    for g in groups or []:
        for f in g.get("Files") or []:
            title = str(f.get("Title") or "")
            version = str(f.get("Version") or "").replace("V", "").strip()
            if not title or title == last:
                continue
            last = title
            ids = []
            for h in f.get("HardwareInfoList") or []:
                hid = strip_rev(str(h.get("hardwareid") or ""))
                if hid:
                    ids.append(hid)
            url = ""
            du = f.get("DownloadUrl")
            if isinstance(du, dict):
                url = du.get("Global") or next(iter(du.values()), "") or ""
            out.append({"category": str(g.get("Name") or ""), "title": title, "version": version,
                        "date": str(f.get("ReleaseDate") or ""), "url": url, "hwids": ids})
    return out


def compare_vendor(entries, drivers):
    results = []
    for e in entries:
        best = None
        if e["hwids"]:
            ids = [i.upper() for i in e["hwids"]]
            pool = [d for d in drivers if any(i in h.upper() for i in ids for h in d["hwids"])]
            best = None
            for d in pool:
                if best is None or newer(d["version"], best["version"]):
                    best = d
        status, inst, inst_date = "unknown", "", ""
        if best:
            inst, inst_date = best["version"], best["date"]
            n = newer(e["version"], inst)
            status = "unknown" if n is None else ("newer" if n else "current")
        elif e["hwids"]:
            status = "absent"             # the service lists it but this PC has no such device
        results.append({"source": "vendor", "device": e["title"], "cls": e["category"],
                        "installed": inst, "installed_date": inst_date,
                        "available": e["version"], "available_date": e["date"][:10],
                        "title": e["title"], "status": status, "url": e["url"], "hwid": ""})
    return results


def run_vendor(job, ident, drivers):
    if ident["brand"] != "asus":
        link = support_link(ident)
        job.log(f"{link['name']}: no automatic lookup for this brand yet. Use the support link on the page.")
        return [], link
    link = support_link(ident)
    for model in asus_candidates(ident):
        job.log(f"Asking ASUS about model {model}…")
        url = ("https://rog.asus.com/support/webapi/product/GetPDDrivers?website=global"
               f"&model={urllib.parse.quote(model)}&cpu={urllib.parse.quote(model)}&osid=52&systemCode=rog")
        try:
            entries = parse_asus(http_get(url))
        except Exception as e:
            job.log(f"   no usable answer ({str(e)[:80]})")
            continue
        if entries:
            job.log(f"ASUS lists {len(entries)} downloads for {model}.")
            return compare_vendor(entries, drivers), link
    job.log("ASUS had no driver list for this model (desktop boards are not covered by this service).")
    return [], link


# --------------------------------------------------------------------------
# Run, cache, routes
# --------------------------------------------------------------------------

STATE = {"ident": None}


def _load_cache():
    try:
        return json.loads(CACHE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _job(job, use_catalog, use_vendor):
    job.log("Reading this PC's identity…")
    ident = identity()
    STATE["ident"] = ident
    job.log(f"{ident['maker']} {ident['model']}  ·  serial {ident['serial'] or 'not stored in BIOS'}")
    drivers = local_drivers()
    job.log(f"{len(drivers)} installed drivers read.")
    items, link, notes = [], support_link(ident), []
    if use_vendor:
        try:
            v, link = run_vendor(job, ident, drivers)
            items += v
            if not v:
                notes.append("vendor-empty")
        except ApiError:
            raise
        except Exception as e:
            job.log(f"Vendor lookup failed: {e}")
            notes.append("vendor-failed")
    if use_catalog:
        items += run_catalog(job, drivers, ident["build"])
    items = [i for i in items if i["status"] != "absent"]
    rank = {"newer": 0, "unknown": 1, "current": 2}
    items.sort(key=lambda i: (rank.get(i["status"], 3), i["device"].lower()))
    data = {"when": time.strftime("%Y-%m-%d %H:%M"), "items": items, "link": link, "notes": notes,
            "sources": [s for s, on in (("catalog", use_catalog), ("vendor", use_vendor)) if on]}
    try:
        CACHE.write_text(json.dumps(data), encoding="utf-8")
    except OSError:
        pass
    n = sum(1 for i in items if i["status"] == "newer")
    activity("driver check", ident["model"] or ident["maker"], "ok", f"{n} possible updates")
    return f"{n} possible update{'s' if n != 1 else ''} found" if n else "No newer drivers found"


@route("GET", r"/api/drivercheck")
def r_state(req):
    if STATE["ident"] is None:
        try:
            STATE["ident"] = identity()
        except Exception as e:
            core.log(f"identity failed: {e!r}")
            STATE["ident"] = {"maker": "", "model": "", "board": "", "serial": "", "sku": "",
                              "bios": "", "build": 0, "brand": "other", "board_maker": "",
                              "board_serial": ""}
    ident = STATE["ident"]
    last = _load_cache()
    return {"identity": ident, "link": support_link(ident), "last": last,
            "vendor_auto": ident["brand"] == "asus", "online_note": True}


@route("POST", r"/api/drivercheck/run")
def r_run(req):
    b = req.body
    cat, ven = b.get("catalog", True) is not False, b.get("vendor", True) is not False
    if not (cat or ven):
        raise ApiError("Pick at least one source.")
    return {"job": core.start_job("Driver check", _job, cat, ven).id}
