"""Third-party remote desktop tools: AnyDesk, UltraViewer, AnyViewer and Remote Utilities.

App Manager does not replace them. It finds out which are installed and what their IDs are, installs them with
winget, and (in the Hub app) opens a session from the technician's PC to a managed PC.

How each one is started (from the vendors' own documentation where there is any):
  AnyDesk            AnyDesk.exe <ID> [--with-password, the password is sent on standard input, never on the
                     command line]; the ID of this PC comes from AnyDesk.exe --get-id.
  Remote Utilities   rutview.exe -create -name:<name> -host:<ID> adds an address-book entry, then
                     rutview.exe -name:<name> -fullcontrol opens it. Using a 12-digit Internet-ID as the host
                     is how the product is meant to be used but is not spelled out in the command-line page.
  UltraViewer,       no command-line connect is documented, so the program is opened and you type the ID.
  AnyViewer
Nothing here talks to a vendor's servers; the tools do that themselves.
"""

import json
import os
import re
import subprocess
import threading
import time

from . import core, errors
from .core import IS_WIN, ApiError, activity, route

FILE = core.HOME / "remote.json"
ID_RX = re.compile(r"[A-Za-z0-9][\w .@-]{2,38}[A-Za-z0-9]")

PF = r"%ProgramFiles%"
PF86 = r"%ProgramFiles(x86)%"
TOOLS = [
    {"id": "anydesk", "name": "AnyDesk", "winget": "AnyDeskSoftwareGmbH.AnyDesk", "verified": True,
     "exes": [PF86 + r"\AnyDesk\AnyDesk.exe", PF + r"\AnyDesk\AnyDesk.exe"], "match": "anydesk",
     "connect": "cli", "auto_id": True, "site": "anydesk.com"},
    {"id": "rutview", "name": "Remote Utilities", "winget": "Usoris.RemoteUtilitiesViewer", "verified": False,
     "exes": [PF86 + r"\Remote Utilities - Viewer\rutview.exe", PF + r"\Remote Utilities - Viewer\rutview.exe"],
     "match": "remote utilities", "connect": "rut", "auto_id": False, "site": "remoteutilities.com",
     "note": "This PC needs the Viewer to connect out; a managed PC needs the Host and shows its Internet-ID."},
    {"id": "ultraviewer", "name": "UltraViewer", "winget": "UltraViewer.UltraViewer", "verified": False,
     "exes": [PF86 + r"\UltraViewer\UltraViewer_Desktop.exe", PF + r"\UltraViewer\UltraViewer_Desktop.exe"],
     "match": "ultraviewer", "connect": "manual", "auto_id": False, "site": "ultraviewer.net"},
    {"id": "anyviewer", "name": "AnyViewer", "winget": "AOMEI.AnyViewer", "verified": False,
     "exes": [PF86 + r"\AOMEI AnyViewer\AnyViewer.exe", PF + r"\AOMEI AnyViewer\AnyViewer.exe"],
     "match": "anyviewer", "connect": "manual", "auto_id": False, "site": "anyviewer.com"},
]
BY_ID = {t["id"]: t for t in TOOLS}
LAUNCHES = []                    # test mode: what would have been started
_ID_CACHE = {}


def tool(tid):
    t = BY_ID.get(str(tid))
    if not t:
        raise ApiError("Unknown remote tool.")
    return t


# --------------------------------------------------------------------------
# Finding the programs and this PC's IDs
# --------------------------------------------------------------------------

def _registry_exe(match):
    """Windows: find a program's exe through its Uninstall entry (covers custom install folders)."""
    if not IS_WIN:
        return None
    try:
        import winreg
    except ImportError:
        return None
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        for sub in (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                    r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"):
            try:
                key = winreg.OpenKey(hive, sub)
            except OSError:
                continue
            with key:
                for i in range(winreg.QueryInfoKey(key)[0]):
                    try:
                        with winreg.OpenKey(key, winreg.EnumKey(key, i)) as k:
                            name = str(winreg.QueryValueEx(k, "DisplayName")[0])
                            if match not in name.lower():
                                continue
                            icon = str(winreg.QueryValueEx(k, "DisplayIcon")[0]).split(",")[0].strip('"')
                            if icon.lower().endswith(".exe") and "unins" not in icon.lower() and os.path.isfile(icon):
                                return icon
                    except OSError:
                        continue
    return None


def find_exe(t):
    for c in t["exes"]:
        p = os.path.expandvars(c)
        if os.path.isfile(p):
            return p
    return _registry_exe(t["match"])


def _store():
    try:
        return json.loads(FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _auto_id(t, exe):
    if not (t["auto_id"] and exe):
        return None
    hit = _ID_CACHE.get(t["id"])
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    val = None
    try:
        r = subprocess.run([exe, "--get-id"], capture_output=True, text=True, timeout=10, creationflags=core.NO_WINDOW)
        out = (r.stdout or "").strip().splitlines()
        if out and re.fullmatch(r"[\w.@-]{4,40}", out[-1].strip()):
            val = out[-1].strip()
    except (OSError, subprocess.SubprocessError):
        pass
    _ID_CACHE[t["id"]] = (time.time(), val)
    return val


def state():
    """What is installed on this PC and each tool's ID here (read automatically where the tool allows)."""
    ids = _store().get("ids", {})
    out = []
    for t in TOOLS:
        if IS_WIN:
            exe = find_exe(t)
            rid, src = _auto_id(t, exe), "auto"
            if not rid and ids.get(t["id"]):
                rid, src = ids[t["id"]], "typed"
            installed = bool(exe)
        else:                                                    # test mode: pretend two are installed
            installed = t["id"] in ("anydesk", "ultraviewer")
            rid = {"anydesk": "123 456 789"}.get(t["id"]) or ids.get(t["id"])
            src = "auto" if t["id"] == "anydesk" else "typed"
        out.append({"id": t["id"], "name": t["name"], "installed": installed, "remote_id": rid or "",
                    "id_source": src if rid else "", "connect": t["connect"], "winget": t["winget"],
                    "verified": t["verified"], "site": t["site"], "note": t.get("note", "")})
    return out


def report():
    """The short form a managed PC sends to its hub."""
    return [{"tool": s["id"], "installed": s["installed"], "id": s["remote_id"]} for s in state()]


# --------------------------------------------------------------------------
# Starting a session (Hub app: from this PC to a managed PC)
# --------------------------------------------------------------------------

def connect(tid, remote_id, password="", label=""):
    t = tool(tid)
    rid = str(remote_id or "").strip()
    if not ID_RX.fullmatch(rid):
        raise ApiError(f"That does not look like a {t['name']} ID.")
    label = re.sub(r"[^\w .-]", "", str(label))[:40] or "PC"
    password = str(password or "")
    if len(password) > 64 or re.search(r"[\r\n\x00]", password):
        raise ApiError("That password cannot be used.")
    st = next(s for s in state() if s["id"] == tid)
    if not st["installed"]:
        raise ApiError(errors.msg("AM-R501", f"{t['name']} is not installed on this PC. Install it first."))
    note = ""
    if t["connect"] == "manual":
        cmd = [find_exe(t) or "<exe>"]
        note = f"{t['name']} has no command-line connect. It was opened: type the ID {rid} into its connect box."
    elif t["connect"] == "rut":
        exe = find_exe(t) or "<exe>"
        cmd = [exe, f"-name:AM {label}", "-fullcontrol"]
        note = "Remote Utilities asks for the Host's password in its own window."
    else:
        exe = find_exe(t) or "<exe>"
        cmd = [exe, rid] + (["--with-password"] if password else [])
    LAUNCHES.append({"tool": tid, "cmd": cmd, "stdin": bool(password and t["connect"] == "cli")})
    del LAUNCHES[:-20]
    if IS_WIN:
        try:
            if t["connect"] == "rut":
                subprocess.run([cmd[0], "-create", f"-name:AM {label}", f"-host:{rid}", "-group:App Manager"],
                               timeout=15, creationflags=core.NO_WINDOW)
            p = subprocess.Popen(cmd, stdin=subprocess.PIPE if password and t["connect"] == "cli" else None)
            if password and t["connect"] == "cli":
                p.stdin.write((password + "\n").encode())           # same as: echo password | AnyDesk.exe ID --with-password
                p.stdin.close()
        except (OSError, subprocess.SubprocessError) as e:
            raise ApiError(errors.msg("AM-R502", f"Could not start {t['name']}: {e}"))
    activity("remote session", f"{t['name']} to {label}")
    return {"started": True, "note": note, "tool": t["name"], "test": not IS_WIN}


# --------------------------------------------------------------------------
# Routes (this PC's own tools; shared by both apps)
# --------------------------------------------------------------------------

@route("GET", r"/api/remote")
def r_state(req):
    return {"items": state(), "test": not IS_WIN}


@route("POST", r"/api/remote/open")
def r_open(req):
    t = tool(req.body.get("tool"))
    exe = find_exe(t) if IS_WIN else None
    if IS_WIN and not exe:
        raise ApiError(errors.msg("AM-R501", f"{t['name']} is not installed on this PC."))
    if IS_WIN:
        subprocess.Popen([exe])
    return {"ok": True}


@route("POST", r"/api/remote/id")
def r_id(req):
    t = tool(req.body.get("tool"))
    rid = str(req.body.get("id", "")).strip()
    s = _store()
    ids = s.setdefault("ids", {})
    if rid:
        if not ID_RX.fullmatch(rid):
            raise ApiError(f"That does not look like a {t['name']} ID.")
        ids[t["id"]] = rid
    else:
        ids.pop(t["id"], None)
    FILE.write_text(json.dumps(s), encoding="utf-8")
    return {"ok": True}


def _install_job(job, tid):
    from . import installer
    t = BY_ID[tid]
    job.log(f"--- {t['name']} ({t['winget']}) ---")
    code = installer._run_winget(job, t["winget"])
    if code not in (0, 0x8A150061, 0x8A15002B):
        raise ApiError(errors.msg("AM-R504", f"winget could not install {t['name']} (code {code}).")
                       + ("" if t["verified"] else f" The winget ID {t['winget']} has not been checked; install it from {t['site']} instead."))
    activity("install", t["name"])
    return f"{t['name']} installed"


@route("POST", r"/api/remote/install")
def r_install(req):
    from . import updates
    t = tool(req.body.get("tool"))
    if req.body.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    if not updates.winget_available():
        raise ApiError(errors.msg("AM-R503", "Windows Package Manager (winget) was not found on this PC. Install it from " + t["site"] + "."))
    return {"job": core.start_job(f"Install {t['name']}", _install_job, t["id"]).id}
