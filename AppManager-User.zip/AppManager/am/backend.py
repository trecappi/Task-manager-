"""Operating-system layer: processes, firewall, Windows startup task, file picker.

WindowsBackend is the real thing. FakeBackend lets the whole app run (and be
tested) on other systems; it does not change anything outside its own folder.
"""

import ctypes
import os
import shlex
import signal
import subprocess

from . import core
from .core import IS_WIN, ApiError, run

TASK_NAME = {"hub": "AppManagerHub", "client": "AppManagerClient"}.get(core.ROLE, "AppManager")


class WindowsBackend:
    name = "windows"
    supports_firewall = True

    # -- processes -------------------------------------------------------
    def processes(self):
        """[(pid, full exe path)] for everything we are allowed to see."""
        try:
            return self._processes_ctypes()
        except Exception as e:
            core.log(f"ctypes process scan failed, using PowerShell: {e!r}")
            rows = core.ps_json(
                "Get-CimInstance Win32_Process | Where-Object {$_.ExecutablePath} | "
                "Select-Object ProcessId,ExecutablePath | ConvertTo-Json -Compress")
            return [(int(r["ProcessId"]), r["ExecutablePath"]) for r in rows]

    def _processes_ctypes(self):
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)

        class PROCESSENTRY32W(ctypes.Structure):
            _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
                        ("th32ProcessID", wintypes.DWORD),
                        ("th32DefaultHeapID", ctypes.c_size_t),
                        ("th32ModuleID", wintypes.DWORD),
                        ("cntThreads", wintypes.DWORD),
                        ("th32ParentProcessID", wintypes.DWORD),
                        ("pcPriClassBase", wintypes.LONG),
                        ("dwFlags", wintypes.DWORD),
                        ("szExeFile", wintypes.WCHAR * 260)]

        k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        k32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
        k32.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
        k32.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
        k32.OpenProcess.restype = wintypes.HANDLE
        k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k32.QueryFullProcessImageNameW.argtypes = [
            wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        k32.CloseHandle.argtypes = [wintypes.HANDLE]

        invalid = wintypes.HANDLE(-1).value
        snap = k32.CreateToolhelp32Snapshot(0x2, 0)          # TH32CS_SNAPPROCESS
        if snap is None or snap == invalid:
            raise OSError("snapshot failed")
        out = []
        try:
            entry = PROCESSENTRY32W()
            entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
            ok = k32.Process32FirstW(snap, ctypes.byref(entry))
            while ok:
                pid = entry.th32ProcessID
                h = k32.OpenProcess(0x1000, False, pid)      # QUERY_LIMITED_INFORMATION
                if h:
                    buf = ctypes.create_unicode_buffer(1024)
                    size = wintypes.DWORD(1024)
                    if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                        out.append((pid, buf.value))
                    k32.CloseHandle(h)
                ok = k32.Process32NextW(snap, ctypes.byref(entry))
        finally:
            k32.CloseHandle(snap)
        return out

    def spawn(self, exe, args, cwd):
        cmdline = subprocess.list2cmdline([exe]) + (" " + args if args else "")
        flags = 0x00000008 | 0x00000200        # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        subprocess.Popen(cmdline, cwd=cwd or os.path.dirname(exe) or None,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, creationflags=flags, close_fds=True)

    def terminate(self, pids, force):
        for pid in pids:
            run(["taskkill", "/PID", str(pid), "/T"] + (["/F"] if force else []), timeout=15)

    # -- firewall --------------------------------------------------------
    def fw_block(self, exe):
        name = core.rule_name(exe)
        self.fw_allow(exe)
        for direction in ("out", "in"):
            r = run(["netsh", "advfirewall", "firewall", "add", "rule", f"name={name}",
                     f"dir={direction}", "action=block", f"program={exe}", "enable=yes"])
            if r.returncode != 0:
                raise ApiError("Windows would not let me change the firewall. Close App "
                               "Manager, open it again, and choose Yes when Windows asks "
                               f"for permission. ({(r.stdout or r.stderr).strip()})", 500)

    def fw_allow(self, exe):
        run(["netsh", "advfirewall", "firewall", "delete", "rule", f"name={core.rule_name(exe)}"])

    def fw_has(self, exe):
        r = run(["netsh", "advfirewall", "firewall", "show", "rule", f"name={core.rule_name(exe)}"])
        return r.returncode == 0 and "No rules match" not in r.stdout

    # -- misc ------------------------------------------------------------
    def autostart(self, enable):
        if not enable:
            run(["schtasks", "/delete", "/tn", TASK_NAME, "/f"])
            return
        prog, lead = core.self_command(True)
        tr = " ".join(f'"{x}"' for x in [prog] + lead) + " --background"
        r = run(["schtasks", "/create", "/tn", TASK_NAME, "/tr", tr, "/sc", "onlogon",
                 "/rl", "highest", "/f"])
        if r.returncode != 0:
            raise ApiError("Could not set up 'Start with Windows': "
                           + (r.stdout or r.stderr).strip(), 500)

    def pick_file(self):
        code = ("import tkinter as tk\nfrom tkinter import filedialog\n"
                "r=tk.Tk(); r.withdraw(); r.attributes('-topmost',True)\n"
                "p=filedialog.askopenfilename(title='Choose a program',"
                "filetypes=[('Programs','*.exe'),('All files','*.*')])\nprint(p)")
        r = subprocess.run([core.python_exe(False), "-c", code], capture_output=True,
                           text=True, encoding="utf-8", errors="replace",
                           creationflags=core.NO_WINDOW, timeout=600)
        return r.stdout.strip().replace("/", "\\")

    def pick_folder(self):
        code = ("import tkinter as tk\nfrom tkinter import filedialog\n"
                "r=tk.Tk(); r.withdraw(); r.attributes('-topmost',True)\n"
                "print(filedialog.askdirectory(title='Choose a folder'))")
        r = subprocess.run([core.python_exe(False), "-c", code], capture_output=True,
                           text=True, encoding="utf-8", errors="replace",
                           creationflags=core.NO_WINDOW, timeout=600)
        return r.stdout.strip().replace("/", "\\")

    def make_shortcut(self):
        prog, lead = core.self_command(True)
        script = ("$d=[Environment]::GetFolderPath('Desktop');"
                  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\\" + core.PRODUCT + ".lnk');"
                  f"$s.TargetPath={core.ps_quote(prog)};"
                  f"$s.Arguments={core.ps_quote(' '.join(chr(34) + x + chr(34) for x in lead))};"
                  f"$s.WorkingDirectory={core.ps_quote(core.HOME)};$s.Save()")
        try:
            core.ps(script)
        except RuntimeError as e:
            raise ApiError(f"Could not create the shortcut: {e}", 500)

    def open_folder(self, path):
        os.startfile(path)                                    # noqa: S606 (Windows only)


class FakeBackend:
    name = "test mode (not Windows)"
    # Pretend firewall rules work when APPMGR_FAKE_FW=1 (UI development only).
    supports_firewall = bool(os.environ.get("APPMGR_FAKE_FW"))

    def __init__(self):
        self._fw = set()

    def processes(self):
        out = []
        for d in os.listdir("/proc"):
            if d.isdigit():
                try:
                    out.append((int(d), os.readlink(f"/proc/{d}/exe")))
                except OSError:
                    pass
        return out

    def spawn(self, exe, args, cwd):
        subprocess.Popen([exe] + (shlex.split(args) if args else []), cwd=cwd or None,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)

    def terminate(self, pids, force):
        for pid in pids:
            try:
                os.kill(pid, signal.SIGKILL if force else signal.SIGTERM)
            except ProcessLookupError:
                pass

    def fw_block(self, exe):
        self._fw.add(core.rule_name(exe))

    def fw_allow(self, exe):
        self._fw.discard(core.rule_name(exe))

    def fw_has(self, exe):
        return core.rule_name(exe) in self._fw

    def autostart(self, enable):
        core.log(f"(test mode) autostart task {'on' if enable else 'off'}")

    def pick_file(self):
        raise ApiError("The file chooser only works on Windows.")

    def pick_folder(self):
        raise ApiError("The folder chooser only works on Windows. Type the folder path instead.")

    def make_shortcut(self):
        raise ApiError("Desktop shortcuts only work on Windows.")

    def open_folder(self, path):
        raise ApiError("Opening folders only works on Windows.")


BACKEND = WindowsBackend() if IS_WIN else FakeBackend()
