"""My apps: start / stop / restart, keep running, start with Windows,
internet block (firewall), running programs, blocked list."""

import os
import secrets
import threading
import time

from . import core
from .backend import BACKEND
from .core import (LOCK, ApiError, activity, is_system_path, load_state, norm,
                   pretty_name, route, save_state)

# Programs shared by many apps: blocking one blocks everything that uses it.
SHARED_EXES = {"python.exe", "pythonw.exe", "py.exe", "java.exe", "javaw.exe",
               "node.exe", "powershell.exe", "pwsh.exe", "cmd.exe", "wscript.exe",
               "cscript.exe", "dotnet.exe", "rundll32.exe"}

_snap = {"t": 0.0, "map": {}}


def running_map(max_age=1.0):
    """{normalized exe path: [pids]} for everything running right now."""
    with LOCK:
        if time.time() - _snap["t"] > max_age:
            m = {}
            for pid, exe in BACKEND.processes():
                m.setdefault(norm(exe), []).append(pid)
            _snap.update(t=time.time(), map=m)
        return _snap["map"]


def check_exe(exe):
    if not exe or not os.path.isfile(exe):
        raise ApiError("I can't find that program. It may have been moved or removed.")
    if core.IS_WIN and not exe.lower().endswith(".exe"):
        raise ApiError("That isn't a program file (.exe).")
    return exe


# --------------------------------------------------------------------------
# Internet block
# --------------------------------------------------------------------------

def block_exe(exe, name, want, force=False):
    check_exe(exe)
    key = norm(exe)
    name = name or pretty_name(exe)
    with LOCK:
        s = load_state()
        if want:
            if is_system_path(exe):
                raise ApiError("This is part of Windows itself. Blocking it could break "
                               "your computer, so I won't do that.")
            if os.path.basename(exe).lower() in SHARED_EXES and not force:
                raise ApiError("shared", 409, confirm=(
                    f"{os.path.basename(exe)} is used by many different programs. Blocking "
                    "it will cut off the internet for ALL of them. Block it anyway?"))
            BACKEND.fw_block(exe)
            s["blocked"][key] = {"exe": exe, "name": name}
        else:
            BACKEND.fw_allow(exe)
            s["blocked"].pop(key, None)
        save_state(s)
    activity("block internet" if want else "allow internet", name)
    return {"ok": True}


@route("POST", r"/api/block")
def r_block(req):
    b = req.body
    return block_exe(b.get("exe"), b.get("name"), bool(b.get("blocked")), bool(b.get("force")))


# --------------------------------------------------------------------------
# Managed apps
# --------------------------------------------------------------------------

def add_app(exe, name=None, args=""):
    check_exe(exe)
    with LOCK:
        s = load_state()
        if any(norm(a["exe"]) == norm(exe) for a in s["apps"].values()):
            raise ApiError("That program is already in My apps.")
        aid = secrets.token_hex(4)
        s["apps"][aid] = {"id": aid, "name": name or pretty_name(exe), "exe": exe,
                          "args": args, "autostart": False, "keep_running": False}
        save_state(s)
    activity("add to My apps", name or pretty_name(exe))
    return aid


def _app(s, aid):
    if aid not in s["apps"]:
        raise ApiError("That app is no longer in the list.", 404)
    return s["apps"][aid]


def do_start(a):
    exe = check_exe(a["exe"])
    if running_map(0).get(norm(exe)):
        return
    BACKEND.spawn(exe, a.get("args", ""), a.get("cwd"))
    a["want_running"] = True
    a["last_spawn"] = time.time()
    a["note"] = ""
    _snap["t"] = 0


def _stop_exe(key):
    pids = running_map(0).get(key, [])
    if not pids:
        return
    BACKEND.terminate(pids, force=False)
    deadline = time.time() + 4
    while time.time() < deadline and running_map(0).get(key):
        time.sleep(0.3)
    left = running_map(0).get(key, [])
    if left:
        BACKEND.terminate(left, force=True)
        time.sleep(0.5)
    _snap["t"] = 0


def do_stop(a):
    a["want_running"] = False
    _stop_exe(norm(a["exe"]))


@route("POST", r"/api/app/add")
def r_add(req):
    return {"ok": True, "id": add_app(req.body.get("exe"), req.body.get("name"),
                                      req.body.get("args", ""))}


@route("POST", r"/api/app/([0-9a-f]+)/(\w+)")
def r_action(req):
    aid, action = req.groups
    body = req.body
    with LOCK:
        s = load_state()
        a = _app(s, aid)
        name = a["name"]
        if action == "start":
            if running_map(0).get(norm(a["exe"])):
                raise ApiError("It's already running.")
            do_start(a)
        elif action == "stop":
            do_stop(a)
        elif action == "restart":
            do_stop(a)
            do_start(a)
        elif action == "remove":
            do_stop(a)
            s["apps"].pop(aid)
        elif action == "set":
            for k in ("autostart", "keep_running"):
                if k in body:
                    a[k] = bool(body[k])
            if str(body.get("name", "")).strip():
                a["name"] = str(body["name"]).strip()
            if body.get("keep_running") and running_map(0).get(norm(a["exe"])):
                a["want_running"] = True
        else:
            raise ApiError("Unknown action", 404)
        save_state(s)
        warn = None
        if action == "remove" or (action == "set" and "autostart" in body):
            try:
                BACKEND.autostart(any(x.get("autostart") for x in s["apps"].values()))
            except ApiError as e:
                warn = e.msg
    activity(f"{action} app" if action != "set" else "change app settings", name)
    return {"ok": True, "warning": warn}


@route("POST", r"/api/kill")
def r_kill(req):
    exe = req.body.get("exe") or ""
    if is_system_path(exe):
        raise ApiError("This is part of Windows itself. Stopping it could crash your "
                       "computer, so I won't do that.")
    key = norm(exe)
    with LOCK:
        s = load_state()
        for a in s["apps"].values():
            if norm(a["exe"]) == key:
                a["want_running"] = False
        save_state(s)
        _stop_exe(key)
    activity("stop program", pretty_name(exe))
    return {"ok": True}


# --------------------------------------------------------------------------
# Views
# --------------------------------------------------------------------------

@route("GET", r"/api/apps")
def r_apps(req):
    with LOCK:
        s = load_state()
        rmap = running_map()
        apps = []
        for a in s["apps"].values():
            key = norm(a["exe"])
            pids = rmap.get(key, [])
            apps.append({"id": a["id"], "name": a["name"], "exe": a["exe"],
                         "running": bool(pids), "pids": len(pids),
                         "blocked": key in s["blocked"], "exists": os.path.exists(a["exe"]),
                         "autostart": bool(a.get("autostart")),
                         "keep_running": bool(a.get("keep_running")),
                         "note": a.get("note", "")})
        blocked = [{"exe": b["exe"], "name": b["name"], "running": norm(b["exe"]) in rmap,
                    "exists": os.path.exists(b["exe"])} for b in s["blocked"].values()]
        return {"apps": apps, "blocked": blocked}


@route("GET", r"/api/running")
def r_running(req):
    show_system = "system" in req.query
    with LOCK:
        s = load_state()
        mine = {norm(a["exe"]): a["id"] for a in s["apps"].values()}
        procs = BACKEND.processes()
        _snap.update(t=time.time(), map={})
        originals = {}
        for pid, exe in procs:
            key = norm(exe)
            _snap["map"].setdefault(key, []).append(pid)
            originals.setdefault(key, exe)
        items = []
        for key, pids in _snap["map"].items():
            exe = originals[key]
            system = is_system_path(exe)
            if system and not show_system:
                continue
            items.append({"name": pretty_name(exe), "exe": exe, "count": len(pids),
                          "blocked": key in s["blocked"], "managed": key in mine,
                          "system": system})
        items.sort(key=lambda x: x["name"].lower())
        return {"items": items}


@route("POST", r"/api/pick")
def r_pick(req):
    return {"path": BACKEND.pick_file()}


@route("POST", r"/api/pickfolder")
def r_pick_folder(req):
    return {"path": BACKEND.pick_folder()}


# --------------------------------------------------------------------------
# Background work: keep running, start with Windows, firewall repair
# --------------------------------------------------------------------------

def supervisor_loop():
    while True:
        try:
            with LOCK:
                s = load_state()
                rmap = running_map(0)
                changed = False
                for a in s["apps"].values():
                    alive = bool(rmap.get(norm(a["exe"])))
                    if a.get("keep_running") and a.get("want_running") and not alive:
                        if time.time() - a.get("last_spawn", 0) < 6:
                            continue                       # give launchers time
                        recent = [t for t in a.get("restarts", []) if time.time() - t < 120]
                        if len(recent) >= 5 or not os.path.exists(a["exe"]):
                            a["want_running"] = False
                            a["note"] = "Gave up restarting: it keeps closing."
                            activity("gave up restarting", a["name"], "failed")
                        else:
                            try:
                                do_start(a)
                                recent.append(time.time())
                                activity("restarted (keep running)", a["name"])
                            except Exception as e:
                                core.log(f"restart failed {a['name']}: {e!r}")
                        a["restarts"] = recent
                        changed = True
                    elif a.get("want_running") and not alive and not a.get("keep_running") \
                            and time.time() - a.get("last_spawn", 0) > 6:
                        a["want_running"] = False          # user closed it
                        changed = True
                if changed:
                    save_state(s)
        except Exception as e:
            core.log(f"supervisor error: {e!r}")
        time.sleep(2)


def reconcile_firewall():
    """Re-create rules that vanished (removed by hand, or by Windows)."""
    with LOCK:
        s = load_state()
        for b in s["blocked"].values():
            if not os.path.exists(b["exe"]):
                continue
            try:
                if not BACKEND.fw_has(b["exe"]):
                    BACKEND.fw_block(b["exe"])
                    core.log(f"restored firewall rule for {b['name']}")
            except ApiError as e:
                core.log(f"reconcile failed for {b['name']}: {e.msg}")


def start_autostart_apps():
    with LOCK:
        s = load_state()
        for a in s["apps"].values():
            if a.get("autostart"):
                try:
                    do_start(a)
                    if a.get("keep_running"):
                        a["want_running"] = True
                except ApiError as e:
                    a["note"] = e.msg
        save_state(s)


def start_background():
    threading.Thread(target=supervisor_loop, daemon=True).start()
    threading.Thread(target=lambda: (reconcile_firewall(), start_autostart_apps()),
                     daemon=True).start()
