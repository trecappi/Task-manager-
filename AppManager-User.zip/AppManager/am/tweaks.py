"""Tweaks: privacy, tidy-up and performance settings, each with a plain-English
explanation and an Undo.

Every change first records what the setting was before. "Undo" puts that back.
Windows Defender, Windows Update and the firewall are never touched here.

Two groups, clearly marked on screen:
* Recommended: low risk, easy to reverse.
* Advanced: switches off Windows features. Useful to some people, annoying for others.
"""

import json
import time

from . import core, winsys
from .core import ApiError, activity, route

UNDO_FILE = core.HOME / "tweaks_undo.json"

POL = r"HKLM\SOFTWARE\Policies\Microsoft\Windows"
CDM = r"HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
ADV = r"HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"


def R(path, name, value, typ="dword"):
    return {"k": "reg", "path": path, "name": name, "value": value, "type": typ}


def S(name, mode="Disabled"):
    return {"k": "svc", "name": name, "value": mode}


def T(path):
    return {"k": "task", "path": path}


# group: "safe" or "adv".  restart: "explorer" | "reboot" | "".
TWEAKS = [
    # ---------------- recommended ----------------
    {"id": "ext", "group": "safe", "name": "Show file extensions",
     "desc": "Shows .exe, .pdf, .docx at the end of file names. Makes it much harder to be fooled by a file named “invoice.pdf.exe”.",
     "restart": "explorer", "ops": [R(ADV, "HideFileExt", 0)]},
    {"id": "hidden", "group": "safe", "name": "Show hidden files and folders",
     "desc": "Lets File Explorer show files that Windows hides by default. Handy for troubleshooting.",
     "restart": "explorer", "ops": [R(ADV, "Hidden", 1)]},
    {"id": "adid", "group": "safe", "name": "Turn off the advertising ID",
     "desc": "Stops apps from using a unique ID to show you targeted ads.",
     "ops": [R(r"HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo", "Enabled", 0)]},
    {"id": "tailored", "group": "safe", "name": "Turn off tailored experiences",
     "desc": "Stops Windows from using your diagnostic data to suggest tips and ads.",
     "ops": [R(r"HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy",
               "TailoredExperiencesWithDiagnosticDataEnabled", 0)]},
    {"id": "suggest", "group": "safe", "name": "Remove ads and suggestions from Windows",
     "desc": "Turns off “suggested apps”, lock-screen tips and Start-menu promotions.",
     "ops": [R(CDM, n, 0) for n in ("SubscribedContent-338387Enabled", "SubscribedContent-338388Enabled",
                                     "SubscribedContent-338389Enabled", "SubscribedContent-353698Enabled",
                                     "SystemPaneSuggestionsEnabled", "SoftLandingEnabled",
                                     "RotatingLockScreenOverlayEnabled", "ContentDeliveryAllowed",
                                     "PreInstalledAppsEnabled", "OemPreInstalledAppsEnabled")]
     + [R(POL + r"\CloudContent", "DisableWindowsConsumerFeatures", 1)]},
    {"id": "bing", "group": "safe", "name": "Keep web results out of Start search",
     "desc": "Searching the Start menu searches only this PC instead of also sending what you type to Bing.",
     "restart": "explorer",
     "ops": [R(r"HKCU\Software\Policies\Microsoft\Windows\Explorer", "DisableSearchBoxSuggestions", 1)]},
    {"id": "activity", "group": "safe", "name": "Turn off activity history",
     "desc": "Windows stops recording the apps and files you open (the Timeline feature).",
     "ops": [R(POL + r"\System", "EnableActivityFeed", 0), R(POL + r"\System", "PublishUserActivities", 0),
             R(POL + r"\System", "UploadUserActivities", 0)]},
    {"id": "gamedvr", "group": "safe", "name": "Turn off Game DVR background recording",
     "desc": "Stops Windows from quietly recording gameplay in the background, which can cost frames per second.",
     "ops": [R(r"HKCU\System\GameConfigStore", "GameDVR_Enabled", 0),
             R(POL + r"\GameDVR", "AllowGameDVR", 0)]},
    {"id": "sticky", "group": "safe", "name": "Stop the Sticky Keys pop-up",
     "desc": "Pressing Shift five times no longer opens the Sticky Keys prompt.",
     "ops": [R(r"HKCU\Control Panel\Accessibility\StickyKeys", "Flags", "506", "string")]},
    {"id": "dop2p", "group": "safe", "name": "Stop sharing Windows updates with other PCs",
     "desc": "Delivery Optimization stops using your internet connection to send updates to strangers.",
     "ops": [R(r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config", "DODownloadMode", 0)]},
    {"id": "remoteassist", "group": "safe", "name": "Turn off Remote Assistance",
     "desc": "Nobody can be invited to take over this PC through Windows Remote Assistance.",
     "ops": [R(r"HKLM\SYSTEM\CurrentControlSet\Control\Remote Assistance", "fAllowToGetHelp", 0)]},
    {"id": "classicmenu", "group": "safe", "name": "Classic right-click menu (Windows 11)",
     "desc": "Brings back the full right-click menu without having to click “Show more options”.",
     "restart": "explorer",
     "ops": [{"k": "reg", "path": r"HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32",
              "name": "", "value": "", "type": "string",
              "delkey": r"HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32"}]},
    {"id": "ultimate", "group": "safe", "name": "High-performance power plan",
     "desc": "Switches to the Ultimate Performance plan (it is created if needed). Best for desktops; laptops will use more battery.",
     "ops": [{"k": "plan"}]},
    # ---------------- advanced ----------------
    {"id": "telemetry", "group": "adv", "name": "Reduce telemetry to the minimum",
     "desc": "Tells Windows to send as little diagnostic data to Microsoft as it allows. Home editions can only reach “basic”.",
     "ops": [R(POL + r"\DataCollection", "AllowTelemetry", 0)]},
    {"id": "telemsvc", "group": "adv", "name": "Turn off the telemetry services",
     "desc": "Disables “Connected User Experiences and Telemetry” (DiagTrack) and the push-message router. Some Microsoft troubleshooting tools use them.",
     "ops": [S("DiagTrack"), S("dmwappushservice")]},
    {"id": "telemtasks", "group": "adv", "name": "Turn off telemetry scheduled tasks",
     "desc": "Disables the Compatibility Appraiser and Customer Experience Improvement tasks.",
     "ops": [T(r"\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser"),
             T(r"\Microsoft\Windows\Customer Experience Improvement Program\Consolidator"),
             T(r"\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip")]},
    {"id": "wer", "group": "adv", "name": "Turn off Windows Error Reporting",
     "desc": "Windows stops sending crash reports. Makes it harder to get help from Microsoft when something crashes.",
     "ops": [R(r"HKLM\SOFTWARE\Microsoft\Windows\Windows Error Reporting", "Disabled", 1)]},
    {"id": "copilot", "group": "adv", "name": "Turn off Copilot and Recall",
     "desc": "Disables the Windows Copilot sidebar and the AI snapshot feature (Recall) through policy.",
     "ops": [R(r"HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot", "TurnOffWindowsCopilot", 1),
             R(POL + r"\WindowsAI", "DisableAIDataAnalysis", 1)]},
    {"id": "widgets", "group": "adv", "name": "Turn off the Widgets / News feed",
     "desc": "Removes the Widgets panel on the taskbar.",
     "restart": "explorer", "ops": [R(r"HKLM\SOFTWARE\Policies\Microsoft\Dsh", "AllowNewsAndInterests", 0)]},
    {"id": "sysmain", "group": "adv", "name": "Turn off SysMain (Superfetch)",
     "desc": "Stops Windows from pre-loading apps into memory. Can help on very low-memory PCs; can make a hard drive (not SSD) feel slower.",
     "ops": [S("SysMain")]},
    {"id": "wsearch", "group": "adv", "name": "Turn off Windows Search indexing",
     "desc": "Frees some disk and CPU, but Start and Explorer searches get slower and Outlook search may stop working.",
     "ops": [S("WSearch")]},
    {"id": "hibernate", "group": "adv", "name": "Turn off hibernation",
     "desc": "Gives back disk space (about 40% of your RAM size) and also turns off Fast Startup. The PC can no longer hibernate.",
     "restart": "reboot", "ops": [{"k": "hib"}]},
    {"id": "faststart", "group": "adv", "name": "Turn off Fast Startup",
     "desc": "Makes Shut down a true shutdown. Fixes odd problems after shutting down and starting again.",
     "restart": "reboot",
     "ops": [R(r"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power", "HiberbootEnabled", 0)]},
]
BY_ID = {t["id"]: t for t in TWEAKS}

# One-time actions: nothing to undo.
ACTIONS = [
    {"id": "temp", "name": "Delete temporary files", "desc": "Clears your user temp folder. Files in use are skipped."},
    {"id": "restorepoint", "name": "Create a restore point now", "desc": "A safety net you can roll back to from Windows System Restore."},
]


# --------------------------------------------------------------------------
# State
# --------------------------------------------------------------------------

def _snapshot():
    try:
        return json.loads(UNDO_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _save_snapshot(s):
    UNDO_FILE.write_text(json.dumps(s, indent=1), encoding="utf-8")


def _state(t, svc, task, plan, hib):
    """'on' (applied), 'off', or 'partial'."""
    hits = []
    for op in t["ops"]:
        k = op["k"]
        if k == "reg":
            cur = winsys.reg_get(op["path"], op["name"])
            hits.append(cur is not None and str(cur[1]) == str(op["value"]))
        elif k == "svc":
            hits.append(svc.get(op["name"]) in (None, "Disabled"))
        elif k == "task":
            hits.append(task.get(op["path"]) in (None, False))
        elif k == "plan":
            hits.append(plan == winsys.ULTIMATE)
        elif k == "hib":
            hits.append(not hib)
    if all(hits):
        return "on"
    return "partial" if any(hits) else "off"


def list_tweaks():
    names = [op["name"] for t in TWEAKS for op in t["ops"] if op["k"] == "svc"]
    tasks = [op["path"] for t in TWEAKS for op in t["ops"] if op["k"] == "task"]
    try:
        svc, task = winsys.svc_modes(names), winsys.task_states(tasks)
    except Exception as e:
        core.log(f"tweak state read failed: {e!r}")
        svc, task = {}, {}
    plan, hib = winsys.plan_get(), winsys.hib_get()
    snap = _snapshot()
    out = []
    for t in TWEAKS:
        st = _state(t, svc, task, plan, hib)
        out.append({"id": t["id"], "group": t["group"], "name": t["name"], "desc": t["desc"],
                    "restart": t.get("restart", ""), "state": st,
                    "undo": t["id"] in snap and st != "off"})
    return out


# --------------------------------------------------------------------------
# Apply and undo
# --------------------------------------------------------------------------

def _apply(t):
    before = []
    for op in t["ops"]:
        k = op["k"]
        if k == "reg":
            cur = winsys.reg_get(op["path"], op["name"])
            before.append({"k": "reg", "path": op["path"], "name": op["name"],
                           "old": list(cur) if cur else None, "delkey": op.get("delkey")})
            winsys.reg_set(op["path"], op["name"], op["type"], op["value"])
        elif k == "svc":
            old = winsys.svc_modes([op["name"]]).get(op["name"])
            if old is None:
                continue                                  # service not on this PC
            before.append({"k": "svc", "name": op["name"], "old": old})
            winsys.svc_set(op["name"], op["value"])
        elif k == "task":
            old = winsys.task_states([op["path"]]).get(op["path"])
            if old is None:
                continue
            before.append({"k": "task", "path": op["path"], "old": old})
            winsys.task_set(op["path"], False)
        elif k == "plan":
            before.append({"k": "plan", "old": winsys.plan_get()})
            winsys.plan_set(winsys.plan_ultimate())
        elif k == "hib":
            before.append({"k": "hib", "old": winsys.hib_get()})
            winsys.hib_set(False)
    return before


def _undo(rec):
    for b in reversed(rec["ops"]):
        k = b["k"]
        if k == "reg":
            if b["old"] is None:
                winsys.reg_del(b["path"], b["name"])
                if b.get("delkey"):
                    winsys.reg_delkey(b["delkey"])
            else:
                winsys.reg_set(b["path"], b["name"], b["old"][0], b["old"][1])
        elif k == "svc":
            winsys.svc_set(b["name"], b["old"])
        elif k == "task":
            winsys.task_set(b["path"], bool(b["old"]))
        elif k == "plan" and b.get("old"):
            winsys.plan_set(b["old"])
        elif k == "hib":
            winsys.hib_set(bool(b["old"]))


def _finish(restarts):
    if "explorer" in restarts:
        winsys.restart_explorer()


def _job_apply(job, ids, make_point):
    if make_point:
        job.log("Creating a restore point first…")
        job.log("Restore point created." if winsys.restore_point("App Manager tweaks")
                else "Windows would not make a restore point (it may be switched off). Continuing.")
    snap, done, restarts = _snapshot(), 0, set()
    for tid in ids:
        t = BY_ID[tid]
        job.log(f"Applying: {t['name']}")
        try:
            before = _apply(t)
        except ApiError as e:
            job.log(f"   could not apply: {e.msg}")
            activity("tweak", t["name"], "failed", e.msg)
            continue
        except Exception as e:
            job.log(f"   could not apply: {e}")
            activity("tweak", t["name"], "failed", str(e)[:120])
            continue
        snap[tid] = {"when": time.strftime("%Y-%m-%d %H:%M:%S"), "ops": before}
        _save_snapshot(snap)
        activity("tweak", t["name"])
        done += 1
        if t.get("restart"):
            restarts.add(t["restart"])
    _finish(restarts)
    msg = f"{done} of {len(ids)} applied"
    if "reboot" in restarts:
        msg += ". Restart the PC for everything to take effect"
    return msg


def _job_undo(job, ids):
    snap, done, restarts = _snapshot(), 0, set()
    for tid in ids:
        t, rec = BY_ID[tid], snap.get(tid)
        if not rec:
            job.log(f"{t['name']}: nothing saved to restore.")
            continue
        job.log(f"Undoing: {t['name']}")
        try:
            _undo(rec)
        except Exception as e:
            job.log(f"   could not undo: {e}")
            activity("tweak undo", t["name"], "failed", str(e)[:120])
            continue
        snap.pop(tid, None)
        _save_snapshot(snap)
        activity("tweak undo", t["name"])
        done += 1
        if t.get("restart"):
            restarts.add(t["restart"])
    _finish(restarts)
    return f"{done} restored to how they were" + (". Restart the PC to finish" if "reboot" in restarts else "")


def _job_action(job, aid):
    if aid == "restorepoint":
        ok = winsys.restore_point("App Manager restore point")
        activity("restore point", "", "ok" if ok else "failed")
        if not ok:
            raise ApiError("Windows would not create a restore point. System Protection may be off for this drive.")
        return "Restore point created"
    if aid == "temp":
        import os
        import shutil
        base = os.environ.get("TEMP") or "/tmp/appmgr-test-temp"
        n = freed = 0
        if not core.IS_WIN:
            job.log("Test mode: nothing is deleted.")
            return "Test mode: nothing deleted"
        for name in os.listdir(base):
            p = os.path.join(base, name)
            try:
                size = os.path.getsize(p) if os.path.isfile(p) else 0
                shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
                n, freed = n + 1, freed + size
            except OSError:
                pass
        activity("clean temp", base, "ok", f"{n} items")
        return f"Removed {n} items"
    raise ApiError("Unknown action.")


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------

def _ids(body, ok):
    ids = [i for i in body.get("ids", []) if i in BY_ID]
    ids = [i for i in dict.fromkeys(ids)]
    if not ids:
        raise ApiError("Nothing selected.")
    if body.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    return ids


@route("GET", r"/api/tweaks")
def r_list(req):
    return {"items": list_tweaks(), "actions": ACTIONS, "admin": core.is_admin() or not core.IS_WIN}


@route("POST", r"/api/tweaks/apply")
def r_apply(req):
    ids = _ids(req.body, True)
    title = f"Apply {len(ids)} tweak{'s' if len(ids) != 1 else ''}"
    return {"job": core.start_job(title, _job_apply, ids, bool(req.body.get("restore_point"))).id}


@route("POST", r"/api/tweaks/undo")
def r_undo(req):
    ids = _ids(req.body, True)
    return {"job": core.start_job(f"Undo {len(ids)} tweak{'s' if len(ids) != 1 else ''}", _job_undo, ids).id}


@route("POST", r"/api/tweaks/action")
def r_action(req):
    aid = req.body.get("id")
    if aid not in {a["id"] for a in ACTIONS} or req.body.get("confirm") is not True:
        raise ApiError("Invalid request.")
    return {"job": core.start_job(next(a["name"] for a in ACTIONS if a["id"] == aid), _job_action, aid).id}
