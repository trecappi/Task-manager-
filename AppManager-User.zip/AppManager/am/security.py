"""Security: check this PC's protection settings against recommended values, fix them
one at a time, and put any of them back the way they were.

Controlled Folder Access (ransomware protection for Documents, Pictures, Desktop…) has
its own panel: allowed apps, extra protected folders and a "recently blocked" list so an
app that gets blocked can be allowed in one click.
"""

import json
import re
import time

from . import core, winsys
from .core import IS_WIN, ApiError, Lazy, activity, route

UNDO_FILE = core.HOME / "security_undo.json"

# --------------------------------------------------------------------------
# Reading the current state (one PowerShell call for everything Defender-ish)
# --------------------------------------------------------------------------

_READ = r"""
$r=@{}
try{$p=Get-MpPreference; $r.mp=@{cfa=[int]$p.EnableControlledFolderAccess; rtm=[bool]$p.DisableRealtimeMonitoring; maps=[int]$p.MAPSReporting; pua=[int]$p.PUAProtection; np=[int]$p.EnableNetworkProtection; allowed=@($p.ControlledFolderAccessAllowedApplications); folders=@($p.ControlledFolderAccessProtectedFolders)}}catch{}
try{$s=Get-MpComputerStatus; $r.mps=@{tamper=[bool]$s.IsTamperProtected; rt=[bool]$s.RealTimeProtectionEnabled; av=[bool]$s.AntivirusEnabled}}catch{}
try{$r.av=@(Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntivirusProduct | ForEach-Object { [string]$_.displayName })}catch{}
try{$r.fw=@(Get-NetFirewallProfile | ForEach-Object { @{n=[string]$_.Name; e=[bool]("$($_.Enabled)" -eq 'True')} })}catch{}
try{$r.smb1=[bool](Get-SmbServerConfiguration).EnableSMB1Protocol}catch{}
try{$t=Get-Tpm; $r.tpm=@{present=[bool]$t.TpmPresent; ready=[bool]$t.TpmReady}}catch{}
try{$r.bl=@(Get-BitLockerVolume | Where-Object { $_.VolumeType -eq 'OperatingSystem' } | ForEach-Object { [string]$_.ProtectionStatus })}catch{}
try{$r.sb=[bool](Confirm-SecureBootUEFI)}catch{}
$r | ConvertTo-Json -Depth 5 -Compress
"""

FAKE_SEC = {"mp": {"cfa": 0, "rtm": False, "maps": 0, "pua": 0, "np": 0,
                   "allowed": [r"C:\Program Files\Demo\editor.exe"], "folders": [r"D:\Projects"]},
            "mps": {"tamper": True, "rt": True, "av": True}, "av": ["Windows Defender"],
            "fw": [{"n": "Domain", "e": True}, {"n": "Private", "e": True}, {"n": "Public", "e": False}],
            "smb1": True, "tpm": {"present": True, "ready": True}, "bl": ["Off"], "sb": True,
            "events": [
                {"t": "2026-10-22 18:41:07", "id": 1123, "msg": "Path: C:\\Users\\you\\Documents\\budget.xlsx\nProcess Name: C:\\Program Files\\Demo\\sheetsync.exe\nSecurity"},
                {"t": "2026-10-22 18:40:02", "id": 1123, "msg": "Path: C:\\Users\\you\\Pictures\\a.png\nProcess Name: C:\\Program Files\\Demo\\sheetsync.exe\nSecurity"},
                {"t": "2026-10-21 09:12:44", "id": 1124, "msg": "Path: C:\\Users\\you\\Desktop\\notes.txt\nProcess Name: C:\\Tools\\oldtool.exe\nSecurity"}]}


def _read():
    if not IS_WIN:
        return json.loads(json.dumps(FAKE_SEC))
    return core.ps_obj(_READ, timeout=120)


STATE = Lazy(_read, ttl=20)


def _undo_load():
    try:
        return json.loads(UNDO_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _undo_save(s):
    UNDO_FILE.write_text(json.dumps(s, indent=1), encoding="utf-8")


# --------------------------------------------------------------------------
# Items
# --------------------------------------------------------------------------

EXP = r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion"

# kind: mp (Defender preference) | reg | fw | smb1 | info (read-only)
ITEMS = [
    {"id": "cfa", "group": "Protect your files", "kind": "mp", "key": "cfa", "pref": "EnableControlledFolderAccess",
     "name": "Controlled Folder Access",
     "desc": "Ransomware protection. Only trusted programs may change files in Documents, Pictures, Videos, Music and Desktop.",
     "good": {1}, "fix": 1, "audit": {2}},
    {"id": "rtm", "group": "Antivirus", "kind": "mp", "key": "rtm", "pref": "DisableRealtimeMonitoring",
     "name": "Real-time protection",
     "desc": "Windows Security scans files as they are opened or downloaded.",
     "good": {False}, "fix": False, "boolean": True},
    {"id": "maps", "group": "Antivirus", "kind": "mp", "key": "maps", "pref": "MAPSReporting",
     "name": "Cloud-delivered protection",
     "desc": "Lets Windows Security check unknown files against Microsoft's latest threat data in seconds.",
     "good": {1, 2}, "fix": 2},
    {"id": "pua", "group": "Antivirus", "kind": "mp", "key": "pua", "pref": "PUAProtection",
     "name": "Block unwanted apps",
     "desc": "Blocks bundled adware and “potentially unwanted” programs while they are downloaded.",
     "good": {1}, "fix": 1, "audit": {2}},
    {"id": "np", "group": "Antivirus", "kind": "mp", "key": "np", "pref": "EnableNetworkProtection",
     "name": "Network protection",
     "desc": "Blocks programs from connecting to known dangerous websites.",
     "good": {1}, "fix": 1, "audit": {2}},
    {"id": "tamper", "group": "Antivirus", "kind": "info",
     "name": "Tamper protection",
     "desc": "Stops malware from switching security settings off. Windows only lets you change this yourself in Windows Security."},
    {"id": "fw", "group": "Network", "kind": "fw", "name": "Windows Firewall",
     "desc": "The firewall is on for home, work and public networks."},
    {"id": "smb1", "group": "Network", "kind": "smb1", "name": "Old file-sharing protocol (SMB1) is off",
     "desc": "SMB1 is decades old and was used by well-known worms such as WannaCry. Almost nothing needs it today."},
    {"id": "rdp", "group": "Network", "kind": "reg", "path": r"HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server",
     "name": "Remote Desktop is off", "optional": True,
     "desc": "Nobody can connect to this PC over Remote Desktop. Leave it on if you use it to reach this PC.",
     "reg": "fDenyTSConnections", "typ": "dword", "good": {1}, "fix": 1, "missing_ok": True},
    {"id": "smartscreen", "group": "Windows", "kind": "reg", "path": EXP + r"\Explorer",
     "name": "SmartScreen for downloaded programs",
     "desc": "Warns you before you run an unrecognised program from the internet.",
     "reg": "SmartScreenEnabled", "typ": "string", "good": {"warn", "requireadmin"}, "fix": "Warn",
     "missing_ok": True},
    {"id": "uac", "group": "Windows", "kind": "reg", "path": EXP + r"\Policies\System",
     "name": "User Account Control (UAC)",
     "desc": "Windows asks before a program makes system-wide changes.",
     "reg": "EnableLUA", "typ": "dword", "good": {1}, "fix": 1, "missing_ok": True, "restart": True},
    {"id": "autorun", "group": "Windows", "kind": "reg", "path": EXP + r"\Policies\Explorer",
     "name": "No auto-run from USB drives and discs",
     "desc": "Stops programs on a plugged-in drive from starting by themselves.",
     "reg": "NoDriveTypeAutoRun", "typ": "dword", "good": {255}, "fix": 255},
    {"id": "wu", "group": "Windows", "kind": "info", "name": "Windows Update is allowed to run",
     "desc": "Security fixes only help if they are installed."},
    {"id": "sb", "group": "Hardware", "kind": "info", "name": "Secure Boot",
     "desc": "Only trusted software can start before Windows. Changed in the PC's BIOS/UEFI setup, not here."},
    {"id": "tpm", "group": "Hardware", "kind": "info", "name": "TPM security chip",
     "desc": "Needed for BitLocker and Windows 11. Changed in the BIOS/UEFI setup, not here."},
    {"id": "bl", "group": "Hardware", "kind": "info", "name": "Drive encryption (BitLocker)",
     "desc": "Protects your files if the PC is lost or stolen. Turn it on in Windows Settings, because it creates a recovery key you must keep safe."},
]
BY_ID = {i["id"]: i for i in ITEMS}


def _defender_in_charge(s):
    av = [a for a in (s.get("av") or []) if a]
    if not av:
        return True, ""
    ours = any(re.search(r"defender|windows security", a, re.I) for a in av)
    rt = (s.get("mps") or {}).get("rt")
    if ours and rt is not False:
        return True, ""
    if ours:
        return True, ""
    return False, ", ".join(av)


def _evaluate(it, s, other_av):
    """-> (status, detail). status: ok | bad | partial | unknown | na"""
    k = it["kind"]
    if k == "mp":
        if other_av:
            return "na", f"Another antivirus ({other_av}) is in charge, so these Windows settings don't apply."
        mp = s.get("mp")
        if not mp or it["key"] not in mp:
            return "unknown", "Windows would not tell us this setting."
        v = mp[it["key"]]
        if v in it["good"]:
            return "ok", "On"
        if v in it.get("audit", ()):
            return "partial", "Audit mode: it only records what it would block, and blocks nothing."
        return "bad", "Off"
    if k == "reg":
        cur = winsys.reg_get(it["path"], it["reg"])
        if cur is None:
            return ("ok", "Windows default") if it.get("missing_ok") else ("bad", "Not set")
        v = str(cur[1]).lower() if it["typ"] == "string" else cur[1]
        return ("ok", "On") if v in it["good"] else ("bad", f"Currently {cur[1]}")
    if k == "fw":
        fw = s.get("fw")
        if not fw:
            return "unknown", "Could not read the firewall."
        off = [p["n"] for p in fw if not p["e"]]
        return ("ok", "On for all networks") if not off else ("bad", "Off for: " + ", ".join(off))
    if k == "smb1":
        if "smb1" not in s:
            return "unknown", "Could not read this setting."
        return ("bad", "SMB1 is enabled") if s["smb1"] else ("ok", "Off")
    if it["id"] == "tamper":
        if other_av:
            return "na", "Managed by the other antivirus."
        m = s.get("mps")
        if not m:
            return "unknown", "Could not read this."
        return ("ok", "On") if m.get("tamper") else ("bad", "Off. Turn it on in Windows Security → Virus & threat protection settings.")
    if it["id"] == "wu":
        mode = winsys.svc_modes(["wuauserv"]).get("wuauserv")
        return ("bad", "The Windows Update service is disabled") if mode == "Disabled" else ("ok", "Allowed")
    if it["id"] == "sb":
        return ("unknown", "Not reported (BIOS may be in legacy mode)") if "sb" not in s else (
            ("ok", "On") if s["sb"] else ("bad", "Off"))
    if it["id"] == "tpm":
        t = s.get("tpm")
        if not t:
            return "unknown", "Not reported"
        return ("ok", "Present and ready") if t.get("present") and t.get("ready") else (
            "bad", "Not present or not ready")
    if it["id"] == "bl":
        bl = [b for b in (s.get("bl") or []) if b]
        if not bl:
            return "unknown", "Not reported (this Windows edition may not include BitLocker)"
        return ("ok", "On") if any(b in ("On", "1") for b in bl) else ("bad", "Off for the Windows drive")
    return "unknown", ""


def items_view(s):
    in_charge, other = _defender_in_charge(s)
    undo = _undo_load()
    out = []
    for it in ITEMS:
        status, detail = _evaluate(it, s, "" if in_charge else other)
        fixable = it["kind"] != "info"
        out.append({"id": it["id"], "group": it["group"], "name": it["name"], "desc": it["desc"],
                    "status": status, "detail": detail, "optional": bool(it.get("optional")),
                    "can_fix": fixable and status in ("bad", "partial", "unknown") and status != "na",
                    "can_audit": bool(it.get("audit")) and status == "bad",
                    "can_restore": it["id"] in undo, "restart": bool(it.get("restart")),
                    "settings": it["kind"] == "info"})
    return out


# --------------------------------------------------------------------------
# Changing things
# --------------------------------------------------------------------------

def _mp_set(pref, value, boolean=False):
    if not IS_WIN:
        for key, it in ((i["key"], i) for i in ITEMS if i.get("pref") == pref):
            FAKE_SEC["mp"][key] = value
        return
    lit = ("$true" if value else "$false") if boolean else str(int(value))
    core.ps(f"Set-MpPreference -{pref} {lit} -ErrorAction Stop", timeout=60)


def _need_defender():
    s = STATE.get()["data"] or _read()
    ok, other = _defender_in_charge(s)
    if not ok:
        raise ApiError(f"Another antivirus ({other}) is in charge of this PC, so Windows Security settings can't be changed here.")
    mps = s.get("mps") or {}
    if mps.get("rt") is False:
        raise ApiError("Windows Security's real-time protection is off. Turn it on first, then try again.")


def fix(item_id, mode="on"):
    it = BY_ID.get(item_id)
    if not it or it["kind"] == "info":
        raise ApiError("This one can't be changed here.")
    s = _read()
    undo = _undo_load()
    rec = undo.get(item_id) or {"when": time.strftime("%Y-%m-%d %H:%M:%S")}
    k = it["kind"]
    if k == "mp":
        if item_id != "rtm":
            _need_defender()
        old = (s.get("mp") or {}).get(it["key"])
        value = 2 if mode == "audit" and it.get("audit") else it["fix"]
        if old is None:
            raise ApiError("Windows would not tell us the current value, so nothing was changed.")
        rec.setdefault("old", old)
        _mp_set(it["pref"], value, it.get("boolean", False))
    elif k == "reg":
        cur = winsys.reg_get(it["path"], it["reg"])
        rec.setdefault("old", list(cur) if cur else None)
        winsys.reg_set(it["path"], it["reg"], it["typ"], it["fix"])
    elif k == "fw":
        rec.setdefault("old", {p["n"]: p["e"] for p in s.get("fw") or []})
        if IS_WIN:
            core.ps("Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True -ErrorAction Stop")
        else:
            for p in FAKE_SEC["fw"]:
                p["e"] = True
    elif k == "smb1":
        rec.setdefault("old", bool(s.get("smb1")))
        if IS_WIN:
            core.ps("Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force -ErrorAction Stop")
        else:
            FAKE_SEC["smb1"] = False
    undo[item_id] = rec
    _undo_save(undo)
    activity("security fix", it["name"], "ok", "audit mode" if mode == "audit" else "")
    STATE.get(force=True)


def restore(item_id):
    it = BY_ID.get(item_id)
    undo = _undo_load()
    rec = undo.get(item_id)
    if not it or not rec:
        raise ApiError("App Manager did not change this setting, so there is nothing to put back.")
    old, k = rec.get("old"), it["kind"]
    if k == "mp":
        _mp_set(it["pref"], old, it.get("boolean", False))
    elif k == "reg":
        if old is None:
            winsys.reg_del(it["path"], it["reg"])
        else:
            winsys.reg_set(it["path"], it["reg"], old[0], old[1])
    elif k == "fw":
        for name, on in (old or {}).items():
            if re.fullmatch(r"[A-Za-z]+", name):
                if IS_WIN:
                    core.ps(f"Set-NetFirewallProfile -Profile {name} -Enabled {'True' if on else 'False'}")
                else:
                    for p in FAKE_SEC["fw"]:
                        if p["n"] == name:
                            p["e"] = on
    elif k == "smb1":
        if IS_WIN:
            core.ps(f"Set-SmbServerConfiguration -EnableSMB1Protocol ${'true' if old else 'false'} -Force")
        else:
            FAKE_SEC["smb1"] = bool(old)
    undo.pop(item_id, None)
    _undo_save(undo)
    activity("security restore", it["name"])
    STATE.get(force=True)


# --------------------------------------------------------------------------
# Controlled Folder Access: allowed apps, folders, recent blocks
# --------------------------------------------------------------------------

_PATH_OK = re.compile(r"^[A-Za-z]:\\[^\"'`\r\n<>|*?]{1,400}\Z")

_EVENTS = (
    "Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Windows Defender/Operational'; Id=1123,1124} "
    "-MaxEvents 80 | ForEach-Object { [pscustomobject]@{ t=$_.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss'); "
    "id=$_.Id; msg=$_.Message } } | ConvertTo-Json -Compress")


def parse_events(rows):
    """Group events by program: how many times, last file touched, blocked or audit-only."""
    apps = {}
    for r in rows:
        msg = r.get("msg") or ""
        proc = re.search(r"Process Name:\s*(.+)", msg)
        path = re.search(r"^\s*Path:\s*(.+)", msg, re.M)
        if not proc:
            continue
        p = proc.group(1).strip()
        a = apps.setdefault(p.lower(), {"app": p, "count": 0, "last": r.get("t", ""),
                                         "file": path.group(1).strip() if path else "",
                                         "mode": "blocked" if r.get("id") == 1123 else "audit"})
        a["count"] += 1
        if r.get("id") == 1123:
            a["mode"] = "blocked"
    return sorted(apps.values(), key=lambda a: a["last"], reverse=True)


def cfa_info():
    s = STATE.get()
    data = s["data"] or {}
    mp = data.get("mp") or {}
    allowed = [a for a in (mp.get("allowed") or []) if a]
    folders = [a for a in (mp.get("folders") or []) if a]
    try:
        rows = FAKE_SEC["events"] if not IS_WIN else core.ps_json(_EVENTS, timeout=60)
    except Exception:
        rows = []
    recent = [a for a in parse_events(rows) if a["app"].lower() not in {x.lower() for x in allowed}]
    return {"mode": {1: "on", 2: "audit"}.get(mp.get("cfa"), "off"), "allowed": allowed,
            "folders": folders, "recent": recent[:25], "loading": s["loading"], "ready": s["ready"]}


def cfa_app(path, allow):
    if not _PATH_OK.match(path or "") or not path.lower().endswith(".exe"):
        raise ApiError("That is not a full path to a program (.exe).")
    _need_defender()
    if not IS_WIN:
        lst = FAKE_SEC["mp"]["allowed"]
        if allow and path not in lst:
            lst.append(path)
        if not allow:
            FAKE_SEC["mp"]["allowed"] = [p for p in lst if p.lower() != path.lower()]
    else:
        verb = "Add" if allow else "Remove"
        core.ps(f"{verb}-MpPreference -ControlledFolderAccessAllowedApplications {core.ps_quote(path)} -ErrorAction Stop")
    activity("folder access " + ("allow" if allow else "remove"), path)
    STATE.get(force=True)


def cfa_folder(path, add):
    if not _PATH_OK.match(path or ""):
        raise ApiError("That is not a full folder path such as D:\\Projects.")
    _need_defender()
    if not IS_WIN:
        lst = FAKE_SEC["mp"]["folders"]
        if add and path not in lst:
            lst.append(path)
        if not add:
            FAKE_SEC["mp"]["folders"] = [p for p in lst if p.lower() != path.lower()]
    else:
        verb = "Add" if add else "Remove"
        core.ps(f"{verb}-MpPreference -ControlledFolderAccessProtectedFolders {core.ps_quote(path)} -ErrorAction Stop")
    activity("protected folder " + ("add" if add else "remove"), path)
    STATE.get(force=True)


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------

def _need_confirm(b):
    if b.get("confirm") is not True:
        raise ApiError("Please confirm first.")


@route("GET", r"/api/security")
def r_state(req):
    snap = STATE.get(force="refresh" in req.query)
    items = items_view(snap["data"]) if snap["data"] else []
    return {"loading": snap["loading"], "ready": snap["ready"], "error": snap["error"], "items": items,
            "admin": core.is_admin() or not IS_WIN,
            "good": sum(1 for i in items if i["status"] == "ok"), "total": sum(1 for i in items if i["status"] != "na")}


@route("POST", r"/api/security/fix")
def r_fix(req):
    b = req.body
    _need_confirm(b)
    fix(str(b.get("id", "")), "audit" if b.get("mode") == "audit" else "on")
    return {"ok": True}


@route("POST", r"/api/security/fixall")
def r_fixall(req):
    b = req.body
    _need_confirm(b)
    done, failed = 0, []
    for iid in [i for i in b.get("ids", []) if i in BY_ID][:30]:
        try:
            fix(iid)
            done += 1
        except ApiError as e:
            failed.append(f"{BY_ID[iid]['name']}: {e.msg}")
    return {"done": done, "failed": failed}


@route("POST", r"/api/security/restore")
def r_restore(req):
    restore(str(req.body.get("id", "")))
    return {"ok": True}


@route("GET", r"/api/security/cfa")
def r_cfa(req):
    return cfa_info()


@route("POST", r"/api/security/cfa/app")
def r_cfa_app(req):
    cfa_app(str(req.body.get("path", "")), bool(req.body.get("allow", True)))
    return {"ok": True}


@route("POST", r"/api/security/cfa/folder")
def r_cfa_folder(req):
    cfa_folder(str(req.body.get("path", "")), bool(req.body.get("add", True)))
    return {"ok": True}
