"""Diagnostics and cleanup: reclaim disk space, find big files and duplicates, read the
error log.

Safety rules (all enforced here, not just in the screen):
* Cleanup only deletes inside a fixed list of cache/temp folders, never follows
  shortcuts or junctions out of them, and skips files that are in use.
* Large files and duplicates are only ever sent to the Recycle Bin, and only files that
  the scan itself reported can be removed. A duplicate group can never lose its last copy.
"""

import glob
import hashlib
import heapq
import os
import random
import re
import shutil
import time

from . import core
from .core import IS_WIN, ApiError, Lazy, activity, route

LAST = {"large": None, "dups": None}
FAKE_ROOT = core.HOME / "fake_cleanup"


# --------------------------------------------------------------------------
# Cleanup categories
# --------------------------------------------------------------------------

def _env(name):
    return os.environ.get(name, "")


def _categories():
    """[{id, name, desc, roots:[dirs], admin:bool, special?}]"""
    if not IS_WIN:
        return [{"id": k, "name": n, "desc": d, "roots": [str(FAKE_ROOT / k)], "admin": a}
                for k, n, d, a in (
                    ("user_temp", "Temporary files (yours)", "Leftovers from installers and programs.", False),
                    ("browser", "Browser caches", "Saved web pages and images. Passwords and logins are kept.", False),
                    ("crash", "Crash dumps and error reports", "Memory dumps Windows saved after crashes.", True),
                    ("wu", "Windows Update downloads", "Already-installed update files.", True))]
    local, win = _env("LOCALAPPDATA"), _env("WINDIR") or r"C:\Windows"
    browsers = []
    for base in (r"Google\Chrome\User Data", r"Microsoft\Edge\User Data", r"BraveSoftware\Brave-Browser\User Data"):
        for prof in glob.glob(os.path.join(local, base, "*")):
            browsers += [os.path.join(prof, "Cache", "Cache_Data"), os.path.join(prof, "Code Cache")]
    browsers += glob.glob(os.path.join(local, "Mozilla", "Firefox", "Profiles", "*", "cache2"))
    return [
        {"id": "user_temp", "name": "Temporary files (yours)", "desc": "Leftovers from installers and programs.",
         "roots": [_env("TEMP")], "admin": False},
        {"id": "win_temp", "name": "Temporary files (Windows)", "desc": "System-wide temporary files.",
         "roots": [os.path.join(win, "Temp")], "admin": True},
        {"id": "browser", "name": "Browser caches", "desc": "Saved web pages and images for Chrome, Edge, Brave and Firefox. Passwords, cookies and logins are kept. Close the browser first.",
         "roots": browsers, "admin": False},
        {"id": "thumbs", "name": "Thumbnail cache", "desc": "Picture previews. Windows rebuilds them when needed.",
         "roots": [os.path.join(local, "Microsoft", "Windows", "Explorer")], "admin": False,
         "only": r"thumbcache_.*\.db|iconcache_.*\.db"},
        {"id": "crash", "name": "Crash dumps and error reports", "desc": "Memory dumps and reports Windows saved after crashes.",
         "roots": [os.path.join(local, "CrashDumps"), os.path.join(win, "Minidump"),
                   os.path.join(_env("PROGRAMDATA"), "Microsoft", "Windows", "WER", "ReportArchive")],
         "admin": True},
        {"id": "wu", "name": "Windows Update downloads", "desc": "Update files that were already installed.",
         "roots": [os.path.join(win, "SoftwareDistribution", "Download")], "admin": True},
        {"id": "do", "name": "Delivery Optimization cache", "desc": "Update files kept for sharing with other PCs.",
         "roots": [os.path.join(win, "ServiceProfiles", "NetworkService", "AppData", "Local", "Microsoft",
                                "Windows", "DeliveryOptimization", "Cache")], "admin": True},
        {"id": "recycle", "name": "Recycle Bin", "desc": "Files you deleted. They cannot be restored afterwards.",
         "roots": [], "admin": False, "special": "recycle"},
    ]


def _seed_fake():
    if FAKE_ROOT.exists():
        return
    rnd = random.Random(7)
    for cat, n, size in (("user_temp", 6, 400_000), ("browser", 9, 900_000), ("crash", 2, 3_000_000),
                         ("wu", 3, 2_000_000)):
        d = FAKE_ROOT / cat / "sub"
        d.mkdir(parents=True, exist_ok=True)
        for i in range(n):
            (d / f"file{i}.tmp").write_bytes(rnd.randbytes(size + i * 1000))
    (FAKE_ROOT / "user_temp" / "top.tmp").write_bytes(b"x" * 1234)


def _is_link(p):
    return os.path.islink(p) or getattr(os.path, "isjunction", lambda x: False)(p)


def _walk_files(root):
    """Files under root without following links."""
    if not root or not os.path.isdir(root) or _is_link(root):
        return
    for dp, dns, fns in os.walk(root, followlinks=False):
        dns[:] = [d for d in dns if not _is_link(os.path.join(dp, d))]
        for fn in fns:
            p = os.path.join(dp, fn)
            if not _is_link(p):
                yield p


def _cat_files(cat):
    rx = re.compile(cat["only"], re.I) if cat.get("only") else None
    for root in cat["roots"]:
        for p in _walk_files(root):
            if rx and not rx.fullmatch(os.path.basename(p)):
                continue
            yield p


def _recycle_size():
    if not IS_WIN:
        return 0
    try:
        out = core.ps("(New-Object -ComObject Shell.Application).NameSpace(10).Items() | "
                      "ForEach-Object { $_.Size } | Measure-Object -Sum | ForEach-Object { [int64]$_.Sum }", timeout=60)
        return int(out.strip() or 0)
    except Exception:
        return 0


def scan_categories():
    if not IS_WIN:
        _seed_fake()
    out = []
    for c in _categories():
        size = n = 0
        if c.get("special") == "recycle":
            size = _recycle_size()
        else:
            for p in _cat_files(c):
                try:
                    size += os.path.getsize(p)
                    n += 1
                except OSError:
                    pass
        out.append({"id": c["id"], "name": c["name"], "desc": c["desc"], "size": size, "files": n,
                    "admin": c["admin"]})
    return out


CATS = Lazy(scan_categories, ttl=600)


def _clean_job(job, ids):
    if not IS_WIN:
        _seed_fake()
    by_id = {c["id"]: c for c in _categories()}
    total = 0
    for cid in ids:
        c = by_id.get(cid)
        if not c:
            continue
        job.log(f"--- {c['name']} ---")
        freed = skipped = 0
        if c.get("special") == "recycle":
            if IS_WIN:
                try:
                    core.ps("Clear-RecycleBin -Force -ErrorAction Stop", timeout=120)
                    job.log("Recycle Bin emptied.")
                except Exception as e:
                    job.log(f"Could not empty it: {str(e)[:100]}")
            continue
        for p in list(_cat_files(c)):
            if not any(os.path.realpath(p).startswith(os.path.realpath(r) + os.sep) for r in c["roots"] if r):
                continue                                    # safety net: must stay inside its folder
            try:
                size = os.path.getsize(p)
                os.remove(p)
                freed += size
            except OSError:
                skipped += 1                                # in use or no permission
        for root in c["roots"]:                             # tidy up empty folders, keep the root itself
            for dp, dns, fns in os.walk(root, topdown=False, followlinks=False):
                if dp != root and not os.listdir(dp) and not _is_link(dp):
                    try:
                        os.rmdir(dp)
                    except OSError:
                        pass
        total += freed
        job.log(f"Freed {freed / 1048576:.1f} MB" + (f", {skipped} files were in use and skipped" if skipped else ""))
        activity("cleanup", c["name"], "ok", f"{freed / 1048576:.1f} MB")
    CATS.get(force=True)
    return f"Freed {total / 1048576:.1f} MB"


# --------------------------------------------------------------------------
# Large files and duplicates
# --------------------------------------------------------------------------

_SKIP_DIRS = {"$recycle.bin", "system volume information", "windows", "program files", "program files (x86)",
              "programdata", "$windows.~bt", "windows.old", "appdata", "node_modules", ".git"}


def _check_folder(path):
    path = (path or "").strip()
    if not path:
        path = str(core.HOME / "fake_cleanup") if not IS_WIN else os.path.expanduser("~")
    if not os.path.isabs(path) or not os.path.isdir(path):
        raise ApiError("Pick a folder that exists, such as C:\\Users\\you\\Downloads.")
    return path


def _scan_files(root, min_size, job, deadline):
    n = 0
    for dp, dns, fns in os.walk(root, followlinks=False):
        dns[:] = [d for d in dns if d.lower() not in _SKIP_DIRS and not _is_link(os.path.join(dp, d))]
        for fn in fns:
            p = os.path.join(dp, fn)
            try:
                if _is_link(p):
                    continue
                size = os.path.getsize(p)
            except OSError:
                continue
            n += 1
            if n % 20000 == 0:
                job.log(f"{n:,} files looked at…")
            if size >= min_size:
                yield p, size
        if time.time() > deadline:
            job.log("Stopped early: the folder is very large. Results cover what was scanned.")
            return


def _large_job(job, root, min_mb):
    job.log(f"Looking in {root}…")
    heap = []
    for p, size in _scan_files(root, min_mb * 1048576, job, time.time() + 300):
        if len(heap) < 100:
            heapq.heappush(heap, (size, p))
        else:
            heapq.heappushpop(heap, (size, p))
    items = sorted(heap, reverse=True)
    LAST["large"] = {"root": root, "when": time.strftime("%Y-%m-%d %H:%M"),
                     "items": [{"path": p, "size": s, "modified": time.strftime("%Y-%m-%d", time.localtime(os.path.getmtime(p)))
                                if os.path.exists(p) else ""} for s, p in items]}
    activity("large file scan", root, "ok", f"{len(items)} files")
    return f"Found {len(items)} large files"


def _hash(path, limit=None):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        if limit:
            h.update(f.read(limit))
        else:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
    return h.hexdigest()


def _dups_job(job, root, min_mb):
    job.log(f"Looking in {root}…")
    by_size = {}
    for p, size in _scan_files(root, max(int(min_mb * 1048576), 1), job, time.time() + 300):
        by_size.setdefault(size, []).append(p)
    groups, cand = [], [(s, ps) for s, ps in by_size.items() if len(ps) > 1]
    job.log(f"{sum(len(p) for _, p in cand)} files share a size with another file. Comparing contents…")
    for size, paths in cand:
        partial = {}
        for p in paths:
            try:
                partial.setdefault(_hash(p, 65536), []).append(p)
            except OSError:
                pass
        for same in partial.values():
            if len(same) < 2:
                continue
            full = {}
            for p in same:
                try:
                    full.setdefault(_hash(p), []).append(p)
                except OSError:
                    pass
            for ps in full.values():
                if len(ps) > 1:
                    groups.append({"id": hashlib.sha1("|".join(sorted(ps)).encode()).hexdigest()[:10],
                                   "size": size, "files": sorted(ps), "wasted": size * (len(ps) - 1)})
    groups.sort(key=lambda g: g["wasted"], reverse=True)
    LAST["dups"] = {"root": root, "when": time.strftime("%Y-%m-%d %H:%M"), "groups": groups[:150],
                    "wasted": sum(g["wasted"] for g in groups)}
    activity("duplicate scan", root, "ok", f"{len(groups)} groups")
    return f"Found {len(groups)} groups of identical files"


def _blocked_for_trash(p):
    n = os.path.normcase(os.path.abspath(p))
    for var in ("WINDIR", "PROGRAMFILES", "PROGRAMFILES(X86)", "PROGRAMDATA"):
        v = _env(var)
        if v and n.startswith(os.path.normcase(v) + os.sep):
            return True
    return False


def _to_recycle(paths):
    if not IS_WIN:
        d = core.HOME / "fake_recycle"
        d.mkdir(exist_ok=True)
        for p in paths:
            shutil.move(p, str(d / (hashlib.sha1(p.encode()).hexdigest()[:6] + "_" + os.path.basename(p))))
        return
    quoted = ",".join(core.ps_quote(p) for p in paths)
    core.ps("Add-Type -AssemblyName Microsoft.VisualBasic; foreach($p in @(" + quoted + ")){ "
            "[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($p,'OnlyErrorDialogs','SendToRecycleBin') }",
            timeout=300)


def trash(paths):
    """Recycle files that the last scans reported. A duplicate group keeps at least one copy."""
    known_large = {i["path"] for i in (LAST["large"] or {}).get("items", [])}
    groups = {g["id"]: g for g in (LAST["dups"] or {}).get("groups", [])}
    dup_files = {f: g for g in groups.values() for f in g["files"]}
    asked = set(paths)
    for g in {id(dup_files[p]): dup_files[p] for p in asked if p in dup_files}.values():
        if all(f in asked for f in g["files"]):
            raise ApiError("That would remove every copy of a file. Keep at least one copy of each.")
    ok = []
    for p in asked:
        if p not in known_large and p not in dup_files:
            raise ApiError("Only files from the last scan can be removed.")
        if _blocked_for_trash(p):
            raise ApiError("Files in Windows or Program Files folders are not removed here.")
        if os.path.isfile(p) and not _is_link(p):
            ok.append(p)
    if not ok:
        raise ApiError("Those files are already gone.")
    _to_recycle(ok)
    gone = set(ok)
    if LAST["large"]:
        LAST["large"]["items"] = [i for i in LAST["large"]["items"] if i["path"] not in gone]
    if LAST["dups"]:
        for g in LAST["dups"]["groups"]:
            g["files"] = [f for f in g["files"] if f not in gone]
            g["wasted"] = g["size"] * max(len(g["files"]) - 1, 0)
        LAST["dups"]["groups"] = [g for g in LAST["dups"]["groups"] if len(g["files"]) > 1]
    activity("moved to Recycle Bin", f"{len(ok)} files")
    return len(ok)


# --------------------------------------------------------------------------
# Error log
# --------------------------------------------------------------------------

_EV_PS = (
    "$s=(Get-Date).AddDays(-7); Get-WinEvent -FilterHashtable @{LogName='System','Application'; Level=1,2; "
    "StartTime=$s} -MaxEvents 400 -ErrorAction SilentlyContinue | ForEach-Object { [pscustomobject]@{ "
    "t=$_.TimeCreated.ToString('yyyy-MM-dd HH:mm'); log=$_.LogName; src=$_.ProviderName; id=$_.Id; "
    "lvl=$_.LevelDisplayName; msg=(($_.Message -split \"`n\")[0]) } } | ConvertTo-Json -Compress")

_CRASH_SRC = ("application error", "application hang", "bugcheck", "windows error reporting")


def _events():
    if IS_WIN:
        rows = core.ps_json(_EV_PS, timeout=120)
    else:
        rows = [{"t": "2026-10-22 18:41", "log": "System", "src": "Microsoft-Windows-Kernel-Power", "id": 41,
                 "lvl": "Critical", "msg": "The system has rebooted without cleanly shutting down first."},
                {"t": "2026-10-22 14:02", "log": "Application", "src": "Application Error", "id": 1000,
                 "lvl": "Error", "msg": "Faulting application name: demo.exe, version: 1.0.0.0"},
                {"t": "2026-10-21 09:00", "log": "Application", "src": "Application Error", "id": 1000,
                 "lvl": "Error", "msg": "Faulting application name: demo.exe, version: 1.0.0.0"},
                {"t": "2026-10-20 11:11", "log": "System", "src": "Service Control Manager", "id": 7000,
                 "lvl": "Error", "msg": "The Demo Service failed to start."}]
    groups = {}
    for r in rows:
        key = (r.get("src"), r.get("id"))
        g = groups.setdefault(key, {"src": r.get("src") or "", "id": r.get("id"), "count": 0, "log": r.get("log"),
                                    "lvl": r.get("lvl"), "last": r.get("t"), "msg": (r.get("msg") or "")[:300],
                                    "crash": ((r.get("src") or "").lower() in _CRASH_SRC
                                              or (r.get("id") == 41 and "Kernel-Power" in (r.get("src") or "")))})
        g["count"] += 1
    return sorted(groups.values(), key=lambda g: (not g["crash"], -g["count"]))


EVENTS = Lazy(_events, ttl=300)


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------

def _need(b):
    if b.get("confirm") is not True:
        raise ApiError("Please confirm first.")


@route("GET", r"/api/cleanup")
def r_cats(req):
    s = CATS.get(force="refresh" in req.query)
    return {"loading": s["loading"], "ready": s["ready"], "error": s["error"], "items": s["data"] or [],
            "admin": core.is_admin() or not IS_WIN}


@route("POST", r"/api/cleanup/run")
def r_clean(req):
    _need(req.body)
    valid = {c["id"] for c in _categories()}
    ids = [i for i in req.body.get("ids", []) if i in valid]
    if not ids:
        raise ApiError("Nothing selected.")
    return {"job": core.start_job("Clean up disk space", _clean_job, ids).id}


@route("POST", r"/api/cleanup/large")
def r_large(req):
    root = _check_folder(req.body.get("folder"))
    mb = max(1, min(int(req.body.get("min_mb") or 100), 100000))
    return {"job": core.start_job("Find large files", _large_job, root, mb).id}


@route("POST", r"/api/cleanup/dups")
def r_dups(req):
    root = _check_folder(req.body.get("folder"))
    mb = max(0.1, min(float(req.body.get("min_mb") or 1), 100000))
    return {"job": core.start_job("Find duplicate files", _dups_job, root, mb).id}


@route("GET", r"/api/cleanup/results")
def r_results(req):
    return {"large": LAST["large"], "dups": LAST["dups"]}


@route("POST", r"/api/cleanup/trash")
def r_trash(req):
    _need(req.body)
    paths = [p for p in req.body.get("paths", []) if isinstance(p, str)][:500]
    if not paths:
        raise ApiError("Nothing selected.")
    return {"moved": trash(paths)}


@route("POST", r"/api/cleanup/reveal")
def r_reveal(req):
    p = str(req.body.get("path", ""))
    known = {i["path"] for i in (LAST["large"] or {}).get("items", [])} | {
        f for g in (LAST["dups"] or {}).get("groups", []) for f in g["files"]}
    if p not in known:
        raise ApiError("Unknown file.")
    from .backend import BACKEND
    BACKEND.open_folder(os.path.dirname(p))
    return {"ok": True}


@route("GET", r"/api/events")
def r_events(req):
    s = EVENTS.get(force="refresh" in req.query)
    return {"loading": s["loading"], "ready": s["ready"], "error": s["error"], "items": s["data"] or []}
