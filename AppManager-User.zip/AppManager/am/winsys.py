"""Small Windows settings layer (registry, services, scheduled tasks, power plan).

Tweaks and Security both use this, so they can record "what it was before" and undo.
On non-Windows systems an in-memory stand-in is used, so the whole flow is testable
and never touches the real machine.
"""

import re

from . import core
from .core import IS_WIN, ApiError

try:
    import winreg
except ImportError:                         # not Windows
    winreg = None

_HIVES = {"HKLM": "HKEY_LOCAL_MACHINE", "HKCU": "HKEY_CURRENT_USER", "HKCR": "HKEY_CLASSES_ROOT"}
_TYPES = {"dword": "REG_DWORD", "string": "REG_SZ"}

# test-mode stand-ins -------------------------------------------------------
FAKE = {"reg": {}, "svc": {}, "task": {}, "plan": "381b4222-f694-41f0-9685-ff5bb260df2e",
        "hib": True, "log": []}


def _split(path):
    hive, _, sub = path.partition("\\")
    return hive, sub


def _k(path, name):
    return (path.lower(), name.lower())


# registry ------------------------------------------------------------------

def reg_get(path, name):
    """-> (type, value) or None."""
    if not IS_WIN:
        return FAKE["reg"].get(_k(path, name))
    hive, sub = _split(path)
    try:
        with winreg.OpenKey(getattr(winreg, _HIVES[hive].replace("HKEY", "HKEY")), sub, 0,
                            winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
            v, t = winreg.QueryValueEx(k, name)
    except OSError:
        return None
    return ("dword" if t == winreg.REG_DWORD else "string", v)


def reg_set(path, name, typ, value):
    if not IS_WIN:
        FAKE["reg"][_k(path, name)] = (typ, value)
        return
    hive, sub = _split(path)
    with winreg.CreateKeyEx(getattr(winreg, _HIVES[hive]), sub, 0,
                            winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY) as k:
        winreg.SetValueEx(k, name, 0, getattr(winreg, _TYPES[typ]), value)


def reg_del(path, name):
    if not IS_WIN:
        FAKE["reg"].pop(_k(path, name), None)
        return
    hive, sub = _split(path)
    try:
        with winreg.OpenKey(getattr(winreg, _HIVES[hive]), sub, 0,
                            winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY) as k:
            winreg.DeleteValue(k, name)
    except OSError:
        pass


def reg_delkey(path):
    """Delete a key that holds no sub-keys (used for keys we created ourselves)."""
    if not IS_WIN:
        for k in [k for k in FAKE["reg"] if k[0] == path.lower()]:
            FAKE["reg"].pop(k)
        return
    hive, sub = _split(path)
    try:
        winreg.DeleteKeyEx(getattr(winreg, _HIVES[hive]), sub, winreg.KEY_WOW64_64KEY, 0)
    except OSError:
        pass


# services ------------------------------------------------------------------

_SVC = re.compile(r"[A-Za-z0-9_.\-]+\Z")
_MODES = {"Automatic": "Automatic", "Manual": "Manual", "Disabled": "Disabled",
          "Auto": "Automatic", "Boot": "Automatic", "System": "Automatic"}


def svc_modes(names):
    """-> {name: 'Automatic'|'Manual'|'Disabled'|None} in one PowerShell call."""
    if not IS_WIN:
        return {n: FAKE["svc"].get(n.lower(), "Automatic") for n in names}
    if not names:
        return {}
    flt = " -or ".join(f"$_.Name -eq {core.ps_quote(n)}" for n in names)
    rows = core.ps_json("Get-CimInstance Win32_Service | Where-Object { " + flt +
                        " } | ForEach-Object { [pscustomobject]@{ n=$_.Name; m=$_.StartMode } } | ConvertTo-Json -Compress")
    got = {r["n"].lower(): _MODES.get(r["m"], r["m"]) for r in rows}
    return {n: got.get(n.lower()) for n in names}


def svc_set(name, mode):
    if not _SVC.match(name) or mode not in ("Automatic", "Manual", "Disabled"):
        raise ApiError("Invalid service request.")
    if not IS_WIN:
        FAKE["svc"][name.lower()] = mode
        return
    core.ps(f"Set-Service -Name {core.ps_quote(name)} -StartupType {mode} -ErrorAction Stop; "
            + (f"Stop-Service -Name {core.ps_quote(name)} -Force -ErrorAction SilentlyContinue" if mode == "Disabled" else
               ""), timeout=60)


# scheduled tasks -----------------------------------------------------------

def task_states(paths):
    """-> {full task path: True (enabled) | False | None (missing)}"""
    if not IS_WIN:
        return {p: FAKE["task"].get(p, True) for p in paths}
    out = {}
    for p in paths:
        folder, _, name = p.rpartition("\\")
        rows = core.ps_json(f"Get-ScheduledTask -TaskPath {core.ps_quote(folder + chr(92))} -TaskName "
                            f"{core.ps_quote(name)} | ForEach-Object {{ [pscustomobject]@{{ e=($_.State -ne 'Disabled') }} }}"
                            " | ConvertTo-Json -Compress")
        out[p] = rows[0]["e"] if rows else None
    return out


def task_set(path, enabled):
    if not path.startswith("\\") or '"' in path or "'" in path:
        raise ApiError("Invalid task path.")
    if not IS_WIN:
        FAKE["task"][path] = enabled
        return
    r = core.run(["schtasks", "/Change", "/TN", path, "/ENABLE" if enabled else "/DISABLE"], timeout=30)
    if r.returncode != 0:
        raise ApiError((r.stderr or r.stdout).strip()[:200] or "Could not change the scheduled task.")


# power ---------------------------------------------------------------------

ULTIMATE = "e9a42b02-d5df-448d-aa00-03f14749eb61"


def plan_get():
    if not IS_WIN:
        return FAKE["plan"]
    m = re.search(r"([0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12})",
                  core.run(["powercfg", "/getactivescheme"]).stdout, re.I)
    return m.group(1).lower() if m else None


def plan_set(guid):
    if not re.fullmatch(r"[0-9a-f\-]{36}", guid or ""):
        raise ApiError("Invalid power plan.")
    if not IS_WIN:
        FAKE["plan"] = guid
        return
    r = core.run(["powercfg", "/setactive", guid])
    if r.returncode != 0:
        raise ApiError("Windows would not switch to that power plan.")


def plan_ultimate():
    """Make sure the Ultimate Performance plan exists, return its GUID."""
    if not IS_WIN:
        return ULTIMATE
    out = core.run(["powercfg", "/list"]).stdout.lower()
    if ULTIMATE in out:
        return ULTIMATE
    r = core.run(["powercfg", "/duplicatescheme", ULTIMATE])
    m = re.search(r"([0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12})", r.stdout, re.I)
    if not m:
        raise ApiError("This PC does not offer the Ultimate Performance plan.")
    return m.group(1).lower()


def hib_get():
    if not IS_WIN:
        return FAKE["hib"]
    v = reg_get(r"HKLM\SYSTEM\CurrentControlSet\Control\Power", "HibernateEnabled")
    return bool(v and v[1])


def hib_set(on):
    if not IS_WIN:
        FAKE["hib"] = bool(on)
        return
    r = core.run(["powercfg", "/hibernate", "on" if on else "off"])
    if r.returncode != 0:
        raise ApiError("Could not change hibernation.")


def restart_explorer():
    if IS_WIN:
        core.run(["taskkill", "/f", "/im", "explorer.exe"])
        import subprocess
        subprocess.Popen(["explorer.exe"], creationflags=core.NO_WINDOW)


def restore_point(desc):
    if not IS_WIN:
        return True
    try:
        core.ps(f"Checkpoint-Computer -Description {core.ps_quote(desc)} -RestorePointType MODIFY_SETTINGS",
                timeout=120)
        return True
    except Exception as e:
        core.log(f"restore point failed: {e!r}")
        return False
