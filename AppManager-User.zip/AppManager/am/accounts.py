"""Technician accounts: sign-in, and what each technician is allowed to see and change.

Until the first account is created, App Manager works as it always did: whoever opens it has
full control. Creating the first account (always an administrator) turns on sign-in.

Each technician gets a username, a password and, per tab, one of: no access, view only, or
view and change. Administrators can do everything and manage the other accounts. Passwords are
stored only as salted PBKDF2 hashes. If the administrator password is ever lost, start
App Manager once with --reset-logins to switch sign-in off again.
"""

import hashlib
import hmac
import json
import re
import secrets
import threading
import time

from . import core
from .core import ApiError, activity, route

FILE = core.HOME / "techs.json"
ITER = 240_000
SESSION_IDLE = 4 * 3600
MAX_FAILS, LOCK_SECONDS = 5, 60

# Tabs a technician can be given access to (Settings is handled separately).
_ALL_AREAS = [("overview", "Overview"), ("programs", "Programs"), ("myapps", "My apps"), ("startup", "Startup"),
         ("updates", "Updates"), ("install", "Install"), ("tweaks", "Tweaks"), ("security", "Security"),
         ("monitor", "Monitor"), ("tools", "Tools"), ("profiles", "Profiles"), ("backup", "Backup"),
         ("hub", "Hub"), ("devices", "Devices"), ("activity", "Activity")]
HUB_AREAS = ["hub", "profiles", "activity"]                    # the Hub app has only these
AREAS = [a for a in _ALL_AREAS if (a[0] in HUB_AREAS if core.ROLE == "hub" else a[0] != "hub")]
if core.ROLE == "hub":
    AREAS = [("hub", "Devices") if a[0] == "hub" else a for a in AREAS]
AREA_IDS = [a for a, _ in AREAS]
LEVELS = ("view", "change")

# Ready-made access sets the editor offers as a starting point.
PRESETS = {
    "viewer": {a: "view" for a in AREA_IDS},
    "helpdesk": {"overview": "view", "programs": "view", "myapps": "change", "startup": "change", "updates": "view",
                 "monitor": "view", "tools": "change", "devices": "change", "activity": "view"},
    "technician": dict({a: "change" for a in AREA_IDS if a not in ("backup", "profiles", "hub")}, profiles="view", backup="view", hub="view"),
    "full": {a: "change" for a in AREA_IDS},
}

PRESETS = {k: {a: v for a, v in d.items() if a in AREA_IDS} for k, d in PRESETS.items()}

# Which tab(s) own each part of the API. First match wins. A request is allowed when the technician
# has the needed level on any listed tab (GET needs "view", anything else needs "change").
ACCESS = [
    (r"/api/devices/(fix|fixall)", ["devices"]),
    (r"/api/(hardware|devices)", ["devices", "overview"]),
    (r"/api/drivers", ["devices"]),
    (r"/api/drivercheck", ["updates"]),
    (r"/api/updates", ["updates", "overview"]),
    (r"/api/programs", ["programs", "overview"]),
    (r"/api/startup", ["startup", "overview"]),
    (r"/api/(apps|running)", ["myapps", "overview"]),
    (r"/api/(block|app|kill)", ["myapps"]),
    (r"/api/install", ["install"]),
    (r"/api/tweaks", ["tweaks"]),
    (r"/api/security", ["security"]),
    (r"/api/monitor", ["monitor"]),
    (r"/api/(cleanup|events|tech)", ["tools"]),
    (r"/api/profiles", ["profiles"]),
    (r"/api/backup", ["backup"]),
    (r"/api/hub", ["hub"]),
    (r"/api/remote", ["tools", "hub"]),
    (r"/api/activity", ["activity"]),
]
PUBLIC_ANON = {"/api/session", "/api/login", "/api/ping"}                      # no sign-in needed
PUBLIC_USER = {"/api/meta", "/api/jobs", "/api/search", "/api/logout", "/api/me/password", "/api/pick",
               "/api/pickfolder", "/api/shortcut", "/api/errors"}                              # any signed-in technician
LOCK = threading.RLock()
SESSIONS = {}                                                                   # id -> {"user", "t"}
FAILS = {}                                                                      # username -> [count, locked_until]
OPEN_USER = {"username": None, "admin": True, "access": {a: "change" for a in AREA_IDS}, "open": True}


# --------------------------------------------------------------------------
# Storage and passwords
# --------------------------------------------------------------------------

def _load():
    try:
        return json.loads(FILE.read_text(encoding="utf-8")).get("techs", [])
    except (OSError, json.JSONDecodeError):
        return []


def _store(techs):
    tmp = FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps({"techs": techs}, indent=1), encoding="utf-8")
    tmp.replace(FILE)


def enabled():
    """True once at least one account exists (sign-in is then required)."""
    return bool(_load())


def _hash(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), ITER).hex()


def _check_password(t, password):
    return hmac.compare_digest(_hash(password, t["salt"]), t["hash"])


def _new_secret(password):
    salt = secrets.token_hex(16)
    return {"salt": salt, "hash": _hash(password, salt)}


def _find(username):
    u = str(username or "").strip().lower()
    return next((t for t in _load() if t["username"].lower() == u), None)


def _valid_username(u):
    if not re.fullmatch(r"[A-Za-z0-9._-]{3,32}", u):
        raise ApiError("A username is 3 to 32 letters, numbers, dots, dashes or underscores.")


def _valid_password(p):
    if not isinstance(p, str) or len(p) < 8:
        raise ApiError("A password needs at least 8 characters.")
    if len(p) > 128:
        raise ApiError("That password is too long (128 characters at most).")


def _clean_access(a):
    out = {}
    for k, v in (a if isinstance(a, dict) else {}).items():
        if k in AREA_IDS and v in LEVELS:
            out[k] = "view" if k == "overview" else v          # Overview only shows things; it never changes them
    return out


def _public(t):
    return {"username": t["username"], "admin": bool(t.get("admin")), "disabled": bool(t.get("disabled")),
            "access": {a: "change" for a in AREA_IDS} if t.get("admin") else t.get("access", {}),
            "created": t.get("created", ""), "last_login": t.get("last_login", "")}


def _admins_left(techs, skip=None):
    return [t for t in techs if t.get("admin") and not t.get("disabled") and t["username"] != skip]


def reset_logins():
    """Switch sign-in off (used by --reset-logins)."""
    try:
        FILE.unlink()
        return True
    except OSError:
        return False


# --------------------------------------------------------------------------
# Sessions and the gate every request passes through
# --------------------------------------------------------------------------

def _new_session(username):
    sid = secrets.token_urlsafe(32)
    with LOCK:
        SESSIONS[sid] = {"user": username, "t": time.time()}
    return sid


def _drop_sessions(username):
    with LOCK:
        for k in [k for k, v in SESSIONS.items() if v["user"].lower() == username.lower()]:
            SESSIONS.pop(k, None)


def current(cookie_sid):
    """The signed-in technician (public form), OPEN_USER when sign-in is off, or None."""
    techs = _load()
    if not techs:
        return OPEN_USER
    with LOCK:
        s = SESSIONS.get(cookie_sid or "")
        if s and time.time() - s["t"] > SESSION_IDLE:
            SESSIONS.pop(cookie_sid, None)
            s = None
        if s:
            s["t"] = time.time()
    if not s:
        return None
    t = next((x for x in techs if x["username"].lower() == s["user"].lower()), None)
    if not t or t.get("disabled"):
        with LOCK:
            SESSIONS.pop(cookie_sid, None)
        return None
    return _public(t)


def level(user, area):
    if user.get("admin"):
        return "change"
    return user.get("access", {}).get(area)


def can(user, area, write=False):
    lv = level(user, area)
    return lv == "change" or (lv == "view" and not write)


def gate(method, path, user, launcher_ok=False):
    """Raise ApiError unless this technician may make this request."""
    if path in PUBLIC_ANON or (path == "/api/quit" and launcher_ok):
        return
    if user is None:
        raise ApiError("Please sign in.", 401)
    if user.get("admin"):
        return
    if path in PUBLIC_USER or (path == "/api/ui" and method == "GET"):
        return
    for rx, areas in ACCESS:
        if re.match(rx + r"(?:/|$)", path):          # whole path segment only: /api/tech must not match /api/techs
            write = method != "GET"
            if any(can(user, a, write) for a in areas):
                return
            if any(can(user, a) for a in areas):
                raise ApiError("Your account can look at this but not change it. Ask an administrator.", 403)
            raise ApiError("Your account does not have access to this part. Ask an administrator.", 403)
    raise ApiError("Only an administrator can do that.", 403)


def launcher_proof(token):
    """What the launcher sends to replace an older copy of App Manager (browser pages never know the token)."""
    return hashlib.sha256(("launcher:" + token).encode()).hexdigest()


def require_areas(user, areas):
    """Used where one request touches several tabs (applying a profile)."""
    lacking = [dict(AREAS)[a] for a in areas if not can(user, a, True)]
    if lacking:
        raise ApiError("Your account cannot change: " + ", ".join(lacking) + ". Ask an administrator.", 403)


# --------------------------------------------------------------------------
# Routes: session, sign-in, own password
# --------------------------------------------------------------------------

def _me(user):
    return {"username": user.get("username"), "admin": bool(user.get("admin")), "open": bool(user.get("open")),
            "access": user.get("access", {})}


@route("GET", r"/api/session")
def r_session(req):
    user = core.CTX.user
    return {"open": not enabled(), "user": _me(user) if user else None, "areas": AREAS}


@route("POST", r"/api/login")
def r_login(req):
    name = str(req.body.get("username", "")).strip().lower()
    password = str(req.body.get("password", ""))
    with LOCK:
        count, until = FAILS.get(name, [0, 0])
        if until > time.time():
            raise ApiError(f"Too many wrong passwords. Try again in {int(until - time.time()) + 1} seconds.", 429)
    t = _find(name)
    ok = bool(t) and not t.get("disabled") and len(password) <= 128 and _check_password(t, password)
    if not t:
        _hash(password[:128], "00" * 16)                        # same work for unknown names
    if not ok:
        with LOCK:
            count += 1
            FAILS[name] = [count, time.time() + LOCK_SECONDS if count >= MAX_FAILS else 0]
            if count >= MAX_FAILS:
                FAILS[name][0] = 0
        activity("sign-in failed", name[:40], "failed")
        raise ApiError("That username or password is not right." if not (t and t.get("disabled"))
                       else "That account is switched off. Ask an administrator.", 401)
    with LOCK:
        FAILS.pop(name, None)
    techs = _load()
    for x in techs:
        if x["username"] == t["username"]:
            x["last_login"] = time.strftime("%Y-%m-%d %H:%M")
    _store(techs)
    core.CTX.user = _public(t)
    activity("signed in", t["username"])
    return {"user": _me(_public(t)), "_session": _new_session(t["username"])}


@route("POST", r"/api/logout")
def r_logout(req):
    u = core.CTX.user
    if u and u.get("username"):
        activity("signed out", u["username"])
    return {"ok": True, "_session": ""}


@route("POST", r"/api/me/password")
def r_mypassword(req):
    u = core.CTX.user
    if not u or not u.get("username"):
        raise ApiError("There is no account signed in.")
    t = _find(u["username"])
    if not t or not _check_password(t, str(req.body.get("current", ""))):
        raise ApiError("Your current password is not right.")
    new = req.body.get("new")
    _valid_password(new)
    techs = _load()
    for x in techs:
        if x["username"] == t["username"]:
            x.update(_new_secret(new))
    _store(techs)
    activity("changed own password", t["username"])
    return {"ok": True}


# --------------------------------------------------------------------------
# Routes: managing accounts (administrators only; open to anyone while sign-in is still off)
# --------------------------------------------------------------------------

@route("GET", r"/api/techs")
def r_list(req):
    return {"open": not enabled(), "items": [_public(t) for t in _load()], "areas": AREAS, "presets": PRESETS}


@route("POST", r"/api/techs/save")
def r_save(req):
    b = req.body
    techs = _load()
    original = str(b.get("original") or "").strip().lower()
    username = str(b.get("username", "")).strip()
    _valid_username(username)
    first = not techs
    cur = next((t for t in techs if t["username"].lower() == original), None) if original else None
    if original and not cur:
        raise ApiError("That account no longer exists.", 404)
    if any(t["username"].lower() == username.lower() and t is not cur for t in techs):
        raise ApiError("That username is already taken.")
    password = b.get("password") or ""
    if password or not cur:
        _valid_password(password)
    admin = True if first else bool(b.get("admin"))
    rec = dict(cur or {"created": time.strftime("%Y-%m-%d %H:%M")})
    rec.update({"username": username, "admin": admin, "access": {} if admin else _clean_access(b.get("access")),
                "disabled": False if first else bool(b.get("disabled"))})
    if password:
        rec.update(_new_secret(password))
    if cur:
        rest = [t for t in techs if t is not cur]
        if (cur.get("admin") and not cur.get("disabled")) and (not rec["admin"] or rec["disabled"]) \
                and not _admins_left(rest):
            raise ApiError("There must be at least one administrator who is switched on.")
        techs = [rec if t is cur else t for t in techs]
        if password or rec["disabled"] or username.lower() != cur["username"].lower():
            _drop_sessions(cur["username"])
    else:
        techs.append(rec)
    _store(techs)
    activity("saved technician" if cur else "added technician", username, "ok", "administrator" if admin else "")
    out = {"item": _public(rec), "first": first}
    if first:                                                 # sign-in just turned on: keep this browser signed in
        out["_session"] = _new_session(username)
    return out


@route("POST", r"/api/techs/delete")
def r_delete(req):
    name = str(req.body.get("username", "")).strip().lower()
    techs = _load()
    t = next((x for x in techs if x["username"].lower() == name), None)
    if not t:
        raise ApiError("That account no longer exists.", 404)
    rest = [x for x in techs if x is not t]
    if rest and t.get("admin") and not t.get("disabled") and not _admins_left(rest):
        raise ApiError("There must be at least one administrator who is switched on.")
    _store(rest)
    _drop_sessions(t["username"])
    activity("deleted technician", t["username"])
    return {"ok": True, "open": not rest}
