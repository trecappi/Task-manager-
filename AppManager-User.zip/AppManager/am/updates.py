"""Software updates through Windows Package Manager (winget)."""

import re
import shutil
import subprocess
import time

from . import core
from .core import IS_WIN, ApiError, Lazy, activity, route, run

_COMMON = ["--accept-source-agreements", "--disable-interactivity"]


def winget_available():
    return True if not IS_WIN else bool(shutil.which("winget"))


def parse_winget_table(text):
    """Parse the text table printed by `winget upgrade` into a list of dicts."""
    lines = [l.rstrip() for l in text.splitlines()]
    lines = [l for l in lines if len(l.strip()) > 1]          # drop spinner characters
    items, explicit, i = [], False, 0
    while i < len(lines):
        ln = lines[i]
        if "explicit targeting" in ln.lower():
            explicit = True
        if i > 0 and re.fullmatch(r"-{5,}", ln.strip()):
            header = lines[i - 1]
            pos = {k: header.find(k) for k in ("Name", "Id", "Version", "Available", "Source")}
            if min(pos["Name"], pos["Id"], pos["Version"], pos["Available"]) >= 0:
                j = i + 1
                while j < len(lines) and not re.match(r"^\d+ upgrades? available", lines[j].strip()):
                    row = lines[j]
                    end_avail = pos["Source"] if pos["Source"] > pos["Available"] else None
                    item = {"name": row[pos["Name"]:pos["Id"]].strip(),
                            "id": row[pos["Id"]:pos["Version"]].strip(),
                            "version": row[pos["Version"]:pos["Available"]].strip(),
                            "available": row[pos["Available"]:end_avail].strip(),
                            "source": row[pos["Source"]:].strip() if end_avail else "",
                            "explicit": explicit}
                    if item["id"] and " " not in item["id"]:
                        items.append(item)
                    j += 1
                i = j
                continue
        i += 1
    return items


def _load():
    if not IS_WIN:
        from . import fake
        return [u for u in fake.UPDATES if u["id"] not in fake.UPDATED]
    if not winget_available():
        return []
    r = run(["winget", "upgrade", "--include-unknown"] + _COMMON, timeout=240)
    return parse_winget_table(r.stdout)


UPDATES = Lazy(_load, ttl=900)


@route("GET", r"/api/updates")
def r_list(req):
    snap = UPDATES.get(force="refresh" in req.query)
    return {"loading": snap["loading"], "error": snap["error"], "ready": snap["ready"],
            "winget": winget_available(), "items": snap["data"] or []}


def _log_line(job, raw):
    line = raw.strip()
    if len(re.findall(r"[A-Za-z0-9]", line)) >= 3 and not re.search(r"[█▒░]", line):
        job.log(line)


def _install_job(job, ids, everything):
    if not IS_WIN:
        from . import fake
        for pid in (ids or [u["id"] for u in fake.UPDATES if not u["explicit"]]):
            job.log(f"--- {pid} ---")
            job.log("Test mode: pretending to download and install…")
            time.sleep(1.0)
            fake.UPDATED.add(pid)
            activity("update", pid)
        UPDATES.get(force=True)
        return "Updated (test mode)"
    jobs = [("all available updates", ["upgrade", "--all", "--include-unknown"])] if everything else \
        [(i, ["upgrade", "--id", i, "--exact"]) for i in ids]
    ok = bad = 0
    for label, args in jobs:
        job.log(f"--- {label} ---")
        proc = subprocess.Popen(["winget"] + args + ["--silent", "--accept-package-agreements"] + _COMMON,
                                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, creationflags=core.NO_WINDOW)
        buf = b""
        for chunk in iter(lambda: proc.stdout.read(256), b""):
            buf += chunk
            parts = re.split(rb"[\r\n]+", buf)
            buf = parts.pop()
            for part in parts:
                _log_line(job, part.decode("utf-8", "replace"))
        _log_line(job, buf.decode("utf-8", "replace"))
        code = proc.wait()
        if code == 0:
            ok += 1
            activity("update", label)
        else:
            bad += 1
            job.log(f"winget reported a problem (code {code}).")
            activity("update", label, "failed", f"code {code}")
    UPDATES.get(force=True)
    return f"{ok} finished" + (f", {bad} had problems" if bad else "")


@route("POST", r"/api/updates/install")
def r_install(req):
    b = req.body
    if not winget_available():
        raise ApiError("Windows Package Manager (winget) was not found on this PC.")
    if b.get("confirm") is not True:
        raise ApiError("Please confirm first.")
    everything = bool(b.get("all"))
    ids = [i for i in b.get("ids", []) if isinstance(i, str) and re.fullmatch(r"[\w.\-+]+", i)][:50]
    if not everything and not ids:
        raise ApiError("Nothing selected.")
    title = "Install all updates" if everything else (
        f"Update {ids[0]}" if len(ids) == 1 else f"Update {len(ids)} programs")
    return {"job": core.start_job(title, _install_job, ids, everything).id}
