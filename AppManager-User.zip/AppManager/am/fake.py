"""Test data for non-Windows systems, so every screen can be exercised anywhere.

Nothing here touches the real system: "uninstalling" only hides a demo entry.
"""

import os
import platform
import re
import shutil
import subprocess
import time

REMOVED = set()

# --------------------------------------------------------------------------
# Programs
# --------------------------------------------------------------------------

_STORE_DEMO = [
    ("Windows Calculator", "11.2408.1.0", "Microsoft Corporation"),
    ("Spotify Music", "1.2.45.0", "Spotify AB"),
    ("Photos", "2024.11090.1", "Microsoft Corporation"),
]


def programs():
    items = []
    try:
        out = subprocess.run(
            ["dpkg-query", "-W", "-f=${Package}\t${Version}\t${Maintainer}\t${Installed-Size}\n"],
            capture_output=True, text=True, timeout=20).stdout
    except (OSError, subprocess.SubprocessError):
        out = ""
    for line in out.splitlines()[:600]:
        parts = line.split("\t")
        if len(parts) < 4 or parts[0] in REMOVED:
            continue
        name, version, maint, size = parts[:4]
        exe = shutil.which(name) or ""
        items.append({
            "id": _id("deb", name), "kind": "desktop", "name": name, "version": version,
            "publisher": re.sub(r"\s*<.*", "", maint) or "Unknown",
            "installed": "", "size_kb": int(size) if size.isdigit() else None,
            "location": os.path.dirname(exe) if exe else "", "exe": exe,
            "icon": "", "uninstall": f"apt remove {name}", "quiet": f"apt remove -y {name}",
            "can_uninstall": True, "scope": "machine", "arch": "", "reg": None})
    for name, version, pub in _STORE_DEMO:
        if name in REMOVED:
            continue
        items.append({
            "id": _id("store", name), "kind": "store", "name": name, "version": version,
            "publisher": pub, "installed": "", "size_kb": None, "location": "", "exe": "",
            "icon": "", "uninstall": "", "quiet": "", "can_uninstall": True,
            "scope": "user", "arch": "x64", "reg": None, "store": {"full": name}})
    return items


def _id(*parts):
    import hashlib
    return hashlib.sha1("|".join(parts).encode()).hexdigest()[:10]


def fake_uninstall(job, p):
    job.log(f"Test mode: pretending to uninstall {p['name']} (nothing is changed).")
    time.sleep(1.2)
    REMOVED.add(p["name"])
    return True


# --------------------------------------------------------------------------
# Startup
# --------------------------------------------------------------------------

STARTUP = [
    {"name": "Demo Chat Client", "command": r"C:\Program Files\DemoChat\chat.exe --minimized",
     "where": "Registry, only you", "enabled": True, "src": "demo", "ref": "chat"},
    {"name": "Demo Cloud Sync", "command": r"C:\Program Files\DemoSync\sync.exe",
     "where": "Registry, everyone", "enabled": True, "src": "demo", "ref": "sync"},
    {"name": "Demo Updater", "command": r"C:\ProgramData\Demo\updater.exe /silent",
     "where": "Scheduled task", "enabled": False, "src": "demo", "ref": "upd"},
    {"name": "Demo Launcher", "command": r"C:\Users\you\AppData\Local\Launcher\launch.exe",
     "where": "Startup folder, only you", "enabled": True, "src": "demo", "ref": "launch"},
]

# --------------------------------------------------------------------------
# Updates
# --------------------------------------------------------------------------

UPDATES = [
    {"name": "Mozilla Firefox", "id": "Mozilla.Firefox", "version": "131.0", "available": "132.0",
     "source": "winget", "explicit": False},
    {"name": "7-Zip", "id": "7zip.7zip", "version": "23.01", "available": "24.08",
     "source": "winget", "explicit": False},
    {"name": "VLC media player", "id": "VideoLAN.VLC", "version": "3.0.20", "available": "3.0.21",
     "source": "winget", "explicit": False},
    {"name": "Some Pinned Tool", "id": "Vendor.PinnedTool", "version": "1.0", "available": "2.0",
     "source": "winget", "explicit": True},
]
UPDATED = set()

# --------------------------------------------------------------------------
# Hardware, devices, drivers
# --------------------------------------------------------------------------


def _cpu_name():
    try:
        for line in open("/proc/cpuinfo", encoding="utf-8", errors="ignore"):
            if line.startswith("model name"):
                return line.split(":", 1)[1].strip()
    except OSError:
        pass
    return platform.processor() or "Unknown CPU"


def _mem_total():
    try:
        for line in open("/proc/meminfo", encoding="utf-8"):
            if line.startswith("MemTotal"):
                return int(line.split()[1]) * 1024
    except OSError:
        pass
    return 0


def hardware():
    du = shutil.disk_usage("/")
    up = 0
    try:
        up = int(float(open("/proc/uptime").read().split()[0]))
    except OSError:
        pass
    return {
        "system": {"manufacturer": "Test mode", "model": platform.node() or "Test machine",
                   "os": platform.platform(), "version": platform.release(),
                   "build": "", "arch": platform.machine(), "installed": "", "uptime": up,
                   "name": platform.node()},
        "bios": {"vendor": "", "version": "", "date": ""},
        "board": {"maker": "", "product": ""},
        "cpu": [{"name": _cpu_name(), "cores": os.cpu_count() or 1,
                 "threads": os.cpu_count() or 1, "mhz": 0}],
        "gpu": [{"name": "Demo graphics adapter", "vram": 4 * 1024 ** 3,
                 "driver": "31.0.101.5333", "date": "2024-09-30"}],
        "ram": {"total": _mem_total(), "modules": [
            {"slot": "DIMM A1", "size": 8 * 1024 ** 3, "speed": 3200, "maker": "Demo", "part": "D4-3200"},
            {"slot": "DIMM B1", "size": 8 * 1024 ** 3, "speed": 3200, "maker": "Demo", "part": "D4-3200"}]},
        "disks": [{"name": "Demo NVMe SSD 1TB", "type": "SSD", "bus": "NVMe",
                   "size": 1000 * 1000 ** 3, "health": "Healthy"},
                  {"name": "Demo HDD 2TB", "type": "HDD", "bus": "SATA",
                   "size": 2000 * 1000 ** 3, "health": "Warning"}],
        "volumes": [{"drive": "C:", "label": "System", "fs": "NTFS", "size": du.total, "free": du.free},
                    {"drive": "D:", "label": "Games", "fs": "NTFS", "size": 2000 * 1000 ** 3,
                     "free": 150 * 1000 ** 3}],
        "secureboot": True,
    }


_DEVICES = [
    ("Demo Graphics Adapter", "Display", "DemoVendor", 0, True),
    ("Demo Ethernet Controller", "Net", "DemoVendor", 0, True),
    ("Demo Wi-Fi 6 Adapter", "Net", "DemoVendor", 0, True),
    ("Bluetooth Radio", "Bluetooth", "DemoVendor", 0, True),
    ("USB Root Hub (USB 3.0)", "USB", "(Standard USB HUBs)", 0, True),
    ("USB Composite Device", "USB", "(Standard USB Host Controller)", 0, True),
    ("HID Keyboard Device", "Keyboard", "(Standard keyboards)", 0, True),
    ("HID-compliant mouse", "Mouse", "Microsoft", 0, True),
    ("Generic Monitor", "Monitor", "(Standard monitor types)", 0, True),
    ("Speakers (Demo Audio)", "AudioEndpoint", "", 0, True),
    ("Demo High Definition Audio", "MEDIA", "DemoVendor", 0, True),
    ("Demo NVMe SSD", "DiskDrive", "(Standard disk drives)", 0, True),
    ("Unknown device", "Other", "", 28, True),
    ("Demo Card Reader", "USB", "DemoVendor", 22, True),
    ("Old Printer", "Printer", "DemoVendor", 45, False),
    ("Demo CPU", "Processor", "DemoVendor", 0, True),
]


FIXED = set()


def devices():
    return [{"name": n, "raw_cls": c, "maker": m, "status": "OK" if code == 0 else "Error",
             "code": 0 if f"DEMO\\{i:04d}" in FIXED else code, "present": present, "id": f"DEMO\\{i:04d}",
             "service": ""}
            for i, (n, c, m, code, present) in enumerate(_DEVICES)]


def drivers():
    rows = [("Demo Graphics Adapter", "Display", "DemoVendor", "31.0.101.5333", "2024-09-30"),
            ("Demo Ethernet Controller", "Net", "DemoVendor", "10.65.1215.2023", "2023-12-15"),
            ("Demo Wi-Fi 6 Adapter", "Net", "DemoVendor", "22.250.1.2", "2022-03-02"),
            ("Bluetooth Radio", "Bluetooth", "DemoVendor", "22.80.0.3", "2021-06-11"),
            ("Demo High Definition Audio", "MEDIA", "DemoVendor", "6.0.9549.1", "2020-04-20"),
            ("USB Root Hub (USB 3.0)", "USB", "Microsoft", "10.0.22621.2506", "2023-10-05"),
            ("Demo NVMe SSD", "DiskDrive", "Microsoft", "10.0.22621.2506", "2023-10-05")]
    return [{"device": d, "raw_cls": c, "provider": p, "version": v, "date": dt,
             "inf": f"oem{i}.inf", "signed": True, "signer": "Microsoft Windows Hardware Compatibility Publisher",
             "id": f"DEMO\\{i:04d}"} for i, (d, c, p, v, dt) in enumerate(rows)]


# --------------------------------------------------------------------------
# Driver check, Install apps
# --------------------------------------------------------------------------

INSTALLED_IDS = {"mozilla.firefox", "7zip.7zip", "videolan.vlc", "git.git"}


def identity():
    return {"maker": "ASUSTeK COMPUTER INC.", "model": "ROG Zephyrus G15 GA503QM_GA503QM",
            "board_maker": "ASUSTeK COMPUTER INC.", "board_product": "GA503QM",
            "board_serial": "BSN12345678901", "product_serial": "NBN0CX123456789",
            "bios_serial": "NBN0CX123456789", "sku": "", "bios_version": "GA503QM.412", "build": 22631}


def local_drivers():
    return [
        {"name": "NVIDIA GeForce RTX 3060 Laptop GPU", "cls": "Display", "maker": "NVIDIA",
         "provider": "NVIDIA", "version": "31.0.15.3623", "date": "2023-07-10",
         "hwid": ["PCI\\VEN_10DE&DEV_2560&SUBSYS_20431043&REV_A1", "PCI\\VEN_10DE&DEV_2560"]},
        {"name": "Realtek PCIe GbE Family Controller", "cls": "Net", "maker": "Realtek",
         "provider": "Realtek", "version": "10.62.0.0", "date": "2022-05-20",
         "hwid": ["PCI\\VEN_10EC&DEV_8168&SUBSYS_20431043&REV_15"]},
        {"name": "MediaTek Wi-Fi 6 MT7921", "cls": "Net", "maker": "MediaTek", "provider": "MediaTek",
         "version": "3.1.0.1100", "date": "2024-01-08",
         "hwid": ["PCI\\VEN_14C3&DEV_7961&SUBSYS_E0CD1A3B&REV_00"]},
        {"name": "AMD Ryzen Chipset", "cls": "System", "maker": "AMD", "provider": "AMD",
         "version": "5.8.0.13", "date": "2024-02-01", "hwid": ["PCI\\VEN_1022&DEV_1630"]},
    ]


import json as _json  # noqa: E402

CATALOG_HTML = """
<html><body><span id="ctl00_catalogBody_searchDuration">Updates: 1 - 3 of 3 (page 1 of 1)</span>
<table id="ctl00_catalogBody_updateMatches">
<tr id="headerRow"><td>sel</td><th>Title</th><th>Products</th><th>Classification</th><th>Last Updated</th><th>Version</th><th>Size</th><th></th></tr>
<tr id="AAA-111_R0"><td></td><td><a id="AAA-111_link">NVIDIA - Display - 31.0.15.5222</a></td><td>Windows 10 and later drivers, Windows 11</td><td>Drivers (Display)</td><td>9/12/2024</td><td>31.0.15.5222</td><td><span>600 MB</span></td><td><input id="AAA-111" type="button" value="Download"></td></tr>
<tr id="BBB-222_R1"><td></td><td><a>NVIDIA - Display - 31.0.15.4601</a></td><td>Windows 10 and later drivers, Windows 11</td><td>Drivers (Display)</td><td>1/3/2024</td><td>31.0.15.4601</td><td><span>500 MB</span></td><td><input id="BBB-222" type="button"></td></tr>
<tr id="CCC-333_R2"><td></td><td><a>Security Update for Something</a></td><td>Windows 11</td><td>Security Updates</td><td>2/2/2024</td><td>n/a</td><td><span>1 MB</span></td><td><input id="CCC-333" type="button"></td></tr>
</table></body></html>"""

ASUS_JSON = {"Result": {"Obj": [
    {"Name": "Graphics", "Files": [
        {"Title": "NVIDIA Graphics Driver", "Version": "V31.0.15.5222", "ReleaseDate": "2024/09/12",
         "DownloadUrl": {"Global": "https://dlcdnets.asus.com/x.zip"},
         "HardwareInfoList": [{"hardwareid": "PCI\\VEN_10DE&DEV_2560&REV_A1"}]}]},
    {"Name": "LAN", "Files": [
        {"Title": "Realtek LAN Driver", "Version": "V10.62.0.0", "ReleaseDate": "2024/01/01",
         "DownloadUrl": {"Global": "https://dlcdnets.asus.com/y.zip"},
         "HardwareInfoList": [{"hardwareid": "PCI\\VEN_10EC&DEV_8168"}]},
        {"Title": "Realtek LAN Driver", "Version": "V10.62.0.0", "ReleaseDate": "2024/01/01",
         "DownloadUrl": {"Global": ""}, "HardwareInfoList": []}]},
    {"Name": "Audio", "Files": [
        {"Title": "Some Absent Audio", "Version": "V1.0", "ReleaseDate": "2024/01/01",
         "DownloadUrl": {"Global": ""}, "HardwareInfoList": [{"hardwareid": "HDAUDIO\\VEN_XXXX"}]}]}]}}



def http(url):
    """Stand-in for the internet in test mode (the real parsers still run on this text)."""
    if "catalog.update.microsoft.com" in url:
        return CATALOG_HTML if "10DE" in url.upper() else "<html><body>No results</body></html>"
    if "GetPDDrivers" in url:
        return _json.dumps(ASUS_JSON) if "model=GA503" in url else _json.dumps({"Result": ""})
    raise OSError("offline test mode")
