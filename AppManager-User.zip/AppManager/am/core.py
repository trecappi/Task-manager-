"""Shared plumbing: paths, settings, logging, helpers, web routes, background jobs."""

import base64
import hashlib
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

VERSION = "0.9.0"
_R = os.environ.get("APPMGR_ROLE")
ROLE = _R if _R in ("hub", "client") else "user"      # which app this is: hub (technician), client (managed PC) or user (full local app)
PRODUCT = {"hub": "App Manager Hub", "client": "App Manager Client"}.get(ROLE, "App Manager")
ENTRY = {"hub": "app_hub.py", "client": "app_client.py"}.get(ROLE, "app_manager.py")
APP_ID = {"hub": "appmgr-hub", "client": "appmgr-client"}.get(ROLE, "appmgr")       # what /api/ping answers
IS_WIN = os.name == "nt"
NO_WINDOW = 0x08000000 if IS_WIN else 0
FROZEN = bool(getattr(sys, "frozen", False))                 # running as a PyInstaller .exe
ROOT = Path(sys._MEIPASS) if FROZEN else Path(__file__).resolve().parent.parent
WEB = ROOT / "web"
LOCK = threading.RLock()


# --------------------------------------------------------------------------
# Folders and files
# --------------------------------------------------------------------------

def _home_dir():
    env = os.environ.get("APPMGR_HOME")
    if env:
        base = Path(env)
    elif IS_WIN:
        base = Path(os.environ.get("APPDATA", str(Path.home()))) / APP_ID
    else:
        base = Path.home() / ".config" / APP_ID
    base.mkdir(parents=True, exist_ok=True)
    return base


HOME = _home_dir()
STATE_FILE = HOME / "gui.json"
TOKEN_FILE = HOME / "token.txt"
LOG_FILE = HOME / "gui.log"
ACTIVITY_FILE = HOME / "activity.jsonl"
APP_DIR = HOME / "app"


def log(msg):
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except OSError:
        pass


def get_token():
    try:
        t = TOKEN_FILE.read_text().strip()
        if len(t) >= 32:
            return t
    except OSError:
        pass
    t = secrets.token_urlsafe(32)
    TOKEN_FILE.write_text(t)
    return t


def load_state():
    try:
        s = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        s = {}
    s.setdefault("apps", {})
    s.setdefault("blocked", {})
    s.setdefault("favorites", [])
    return s


def save_state(s):
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(s, indent=2), encoding="utf-8")
    os.replace(tmp, STATE_FILE)


# --------------------------------------------------------------------------
# Activity log (what App Manager did, and when)
# --------------------------------------------------------------------------

class _Ctx(threading.local):
    user = None                  # the technician making the current request (None when unknown)


CTX = _Ctx()


def activity(action, target="", result="ok", detail=""):
    rec = {"t": time.strftime("%Y-%m-%d %H:%M:%S"), "action": action,
           "target": target, "result": result, "detail": detail}
    who = (getattr(CTX, "user", None) or {}).get("username")
    if who:
        rec["by"] = who
    with LOCK:
        try:
            with open(ACTIVITY_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec) + "\n")
            if ACTIVITY_FILE.stat().st_size > 2_000_000:
                lines = ACTIVITY_FILE.read_text(encoding="utf-8").splitlines()[-1000:]
                ACTIVITY_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
        except OSError:
            pass


def recent_activity(n=300):
    try:
        lines = ACTIVITY_FILE.read_text(encoding="utf-8").splitlines()[-n:]
    except OSError:
        return []
    out = []
    for line in reversed(lines):
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return out


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------

class ApiError(Exception):
    def __init__(self, msg, code=400, confirm=None):
        super().__init__(msg)
        self.msg, self.code, self.confirm = msg, code, confirm


def norm(path):
    p = os.path.abspath(path)
    return os.path.normcase(p if IS_WIN else os.path.realpath(p))


def file_id(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8", "replace")).hexdigest()[:10]


def rule_name(exe):
    return f"appmgr:{os.path.basename(exe)}:{file_id(norm(exe))[:6]}"


def is_system_path(path):
    if not IS_WIN or not path:
        return False
    win = os.path.normcase(os.environ.get("WINDIR", r"C:\Windows"))
    return os.path.normcase(os.path.abspath(path)).startswith(win + os.sep)


def pretty_name(exe):
    base = os.path.splitext(os.path.basename(exe))[0]
    return base.replace("_", " ").replace("-", " ").title() if base.islower() else base


def is_admin():
    if not IS_WIN:
        return os.geteuid() == 0
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def python_exe(windowless=False):
    exe = sys.executable
    if IS_WIN:
        d = os.path.dirname(exe)
        cand = os.path.join(d, "pythonw.exe" if windowless else "python.exe")
        return cand if os.path.exists(cand) else exe
    return exe


def run(cmd, timeout=30):
    return subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=timeout, creationflags=NO_WINDOW)


# --------------------------------------------------------------------------
# PowerShell (scripts are passed encoded, so quoting can never break them)
# --------------------------------------------------------------------------

_PS_PRELUDE = ("[Console]::OutputEncoding=[Text.Encoding]::UTF8;"
               "$ProgressPreference='SilentlyContinue';$ErrorActionPreference='SilentlyContinue';")


def ps(script, timeout=60):
    enc = base64.b64encode((_PS_PRELUDE + script).encode("utf-16-le")).decode()
    r = run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
             "-EncodedCommand", enc], timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout).strip()[:500] or "PowerShell failed")
    return r.stdout.lstrip("﻿")          # PowerShell may prepend a byte-order mark


def ps_json(script, timeout=60):
    """Run a script that prints JSON; always return a list."""
    out = ps(script, timeout).strip()
    if not out:
        return []
    data = json.loads(out)
    return data if isinstance(data, list) else [data]


def ps_obj(script, timeout=60):
    out = ps(script, timeout).strip()
    return json.loads(out) if out else {}


def ps_quote(text):
    return "'" + str(text).replace("'", "''") + "'"


# --------------------------------------------------------------------------
# Self-install (so "Start with Windows" and the desktop shortcut survive the
# download folder being moved or deleted)
# --------------------------------------------------------------------------

def installed_entry():
    return APP_DIR / (Path(sys.executable).name if FROZEN else ENTRY)


def self_command(windowless=True):
    """(program, [leading arguments]) that starts this app again: the .exe itself, or python plus the script."""
    if FROZEN:
        return str(install_self()), []
    return python_exe(windowless), [str(install_self())]


def install_self():
    if FROZEN:
        APP_DIR.mkdir(parents=True, exist_ok=True)
        dst = installed_entry()
        if Path(sys.executable).resolve() != dst.resolve():
            shutil.copy2(sys.executable, dst)
        return dst
    if ROOT.resolve() != APP_DIR.resolve():
        APP_DIR.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / ENTRY, APP_DIR / ENTRY)
        for d in ("am", "web"):
            shutil.copytree(ROOT / d, APP_DIR / d, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns("__pycache__"))
    return APP_DIR / ENTRY


# --------------------------------------------------------------------------
# Web routes
# --------------------------------------------------------------------------

ROUTES = []
ROLE_ALLOW = None                # compiled regex: the only paths this app answers (None = all)


def set_allowed(pattern):
    global ROLE_ALLOW
    ROLE_ALLOW = re.compile(pattern + r"\Z") if pattern else None


class Raw:
    """A non-JSON response (downloads)."""
    def __init__(self, body, ctype, headers=None, code=200):
        self.body, self.ctype, self.headers, self.code = body, ctype, headers or {}, code


class Req:
    def __init__(self, query, body, groups):
        self.query, self.body, self.groups = query, body, groups


def route(method, pattern):
    rx = re.compile(pattern + r"\Z")

    def deco(fn):
        ROUTES.append((method, rx, fn))
        return fn
    return deco


def dispatch(method, path, query, body):
    if ROLE_ALLOW is not None and not ROLE_ALLOW.match(path):
        return False, None
    for m, rx, fn in ROUTES:
        if m == method:
            mm = rx.match(path)
            if mm:
                return True, fn(Req(query, body, mm.groups()))
    return False, None


# --------------------------------------------------------------------------
# Slow data that loads in the background
# --------------------------------------------------------------------------

class Lazy:
    """Holds the result of a slow function; refreshes it in a thread."""

    def __init__(self, loader, ttl=300):
        self.loader, self.ttl = loader, ttl
        self.data, self.error, self.t, self.loading = None, None, 0.0, False
        self._lock = threading.Lock()

    def get(self, force=False):
        with self._lock:
            stale = self.t == 0 or time.time() - self.t > self.ttl
            if (force or stale) and not self.loading:
                self.loading = True
                threading.Thread(target=self._work, daemon=True).start()
            return {"loading": self.loading, "ready": self.data is not None,
                    "error": self.error, "data": self.data}

    def _work(self):
        try:
            data, err = self.loader(), None
        except Exception as e:
            log(f"load failed ({self.loader.__name__}): {e!r}")
            data, err = None, str(e)
        with self._lock:
            if err is None:
                self.data = data            # on failure, keep any older data
            self.error, self.t, self.loading = err, time.time(), False

    def peek(self):
        return self.data


# --------------------------------------------------------------------------
# Background jobs (uninstalls, updates...)
# --------------------------------------------------------------------------

JOBS = {}


class Job:
    def __init__(self, title):
        self.id = secrets.token_hex(4)
        self.title, self.status = title, "running"
        self.lines, self.result = [], ""
        self.started, self.finished = time.time(), None

    def log(self, line):
        line = str(line).rstrip()
        if line:
            self.lines.append(line)
            del self.lines[:-400]

    def to_dict(self):
        return {"id": self.id, "title": self.title, "status": self.status,
                "result": self.result, "log": self.lines[-200:],
                "started": self.started, "finished": self.finished}


def start_job(title, fn, *args):
    job = Job(title)
    JOBS[job.id] = job
    user = getattr(CTX, "user", None)

    def work():
        CTX.user = user                      # keep "who did this" for the activity log
        try:
            job.result = fn(job, *args) or "Done"
            job.status = "done"
        except ApiError as e:
            job.result, job.status = e.msg, "error"
        except Exception as e:
            log(f"job '{title}' crashed: {e!r}")
            job.result, job.status = f"Something went wrong: {e}", "error"
        job.finished = time.time()
        for k in sorted(JOBS, key=lambda k: JOBS[k].started)[:-30]:
            JOBS.pop(k, None)
    threading.Thread(target=work, daemon=True).start()
    return job


def list_jobs():
    return [j.to_dict() for j in sorted(JOBS.values(), key=lambda j: -j.started)]
