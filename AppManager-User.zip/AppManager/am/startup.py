"""Startup manager: programs that launch when Windows starts, and turning them on/off.

Turning an item off uses the same switch Windows' Task Manager uses
("StartupApproved"), so nothing is deleted and it can always be turned back on.
"""

import os
import time
from pathlib import Path

from . import core
from .core import IS_WIN, LOCK, ApiError, Lazy, activity, route

_RUN = r"Software\Microsoft\Windows\CurrentVersion\Run"
_APPR = r"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved"


def _sources():
    """id -> (label, hive, view flag for the Run key, folder or None, approved-key path)."""
    import winreg
    user_folder = Path(os.environ.get("APPDATA", "")) / "Microsoft/Windows/Start Menu/Programs/Startup"
    all_folder = Path(os.environ.get("ProgramData", "")) / "Microsoft/Windows/Start Menu/Programs/StartUp"
    H, U = winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER
    return {
        "hkcu_run": ("Registry, only you", U, 0, None, _APPR + r"\Run"),
        "hklm_run": ("Registry, everyone", H, winreg.KEY_WOW64_64KEY, None, _APPR + r"\Run"),
        "hklm_run32": ("Registry, everyone (32-bit)", H, winreg.KEY_WOW64_32KEY, None, _APPR + r"\Run32"),
        "folder_user": ("Startup folder, only you", U, 0, user_folder, _APPR + r"\StartupFolder"),
        "folder_all": ("Startup folder, everyone", H, 0, all_folder, _APPR + r"\StartupFolder"),
    }


def _is_disabled(winreg, hive, path, name):
    try:
        with winreg.OpenKey(hive, path, 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
            data = winreg.QueryValueEx(k, name)[0]
        return bool(data) and data[0] % 2 == 1          # 02/06 = on, 03/07 = off
    except (OSError, TypeError, IndexError):
        return False


def _win_entries():
    import winreg
    out = []
    for sid, (label, hive, flag, folder, appr) in _sources().items():
        if folder is None:
            try:
                key = winreg.OpenKey(hive, _RUN, 0, winreg.KEY_READ | flag)
            except OSError:
                continue
            with key:
                i = 0
                while True:
                    try:
                        name, value, _t = winreg.EnumValue(key, i)
                    except OSError:
                        break
                    i += 1
                    out.append(_entry(sid, label, name, str(value),
                                      not _is_disabled(winreg, hive, appr, name)))
        elif folder.is_dir():
            for f in sorted(folder.iterdir()):
                if f.is_file() and f.name.lower() != "desktop.ini":
                    out.append(_entry(sid, label, f.name, str(f),
                                      not _is_disabled(winreg, hive, appr, f.name)))
    try:
        rows = core.ps_json(
            "Get-ScheduledTask | Where-Object { $_.TaskPath -notlike '\\Microsoft\\*' -and "
            "($_.Triggers | Where-Object { $_.CimClass.CimClassName -eq 'MSFT_TaskLogonTrigger' }) } | "
            "ForEach-Object { [pscustomobject]@{ name=$_.TaskName; path=$_.TaskPath; "
            "state=[string]$_.State; cmd=(($_.Actions | ForEach-Object { ([string]$_.Execute + ' ' + "
            "[string]$_.Arguments).Trim() }) -join ' && ') } } | ConvertTo-Json -Compress", timeout=60)
        for r in rows:
            e = _entry("task", "Scheduled task", r["name"], r.get("cmd") or "",
                       r.get("state") != "Disabled")
            e["ref"] = {"name": r["name"], "path": r.get("path") or "\\"}
            out.append(e)
    except Exception as e:
        core.log(f"scheduled task scan failed: {e!r}")
    return out


def _entry(sid, where, name, command, enabled):
    return {"id": core.file_id("startup", sid, name), "name": name, "command": command,
            "where": where, "enabled": enabled, "src": sid, "ref": name,
            "ours": "appmgr" in command.lower() or name == "AppManager"}


def _load():
    if not IS_WIN:
        from . import fake
        return [dict(e, id=core.file_id("startup", e["src"], e["name"]), ours=False)
                for e in fake.STARTUP]
    return sorted(_win_entries(), key=lambda e: e["name"].lower())


STARTUP = Lazy(_load, ttl=60)


@route("GET", r"/api/startup")
def r_list(req):
    snap = STARTUP.get(force="refresh" in req.query)
    return {"loading": snap["loading"], "error": snap["error"], "ready": snap["ready"],
            "items": snap["data"] or []}


def _set_approved(entry, enabled):
    import winreg
    label, hive, flag, folder, appr = _sources()[entry["src"]]
    data = (b"\x02\x00\x00\x00" + b"\x00" * 8) if enabled else \
        (b"\x03\x00\x00\x00" + int((time.time() + 11644473600) * 10 ** 7).to_bytes(8, "little"))
    try:
        with winreg.CreateKeyEx(hive, appr, 0, winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY) as k:
            winreg.SetValueEx(k, entry["ref"], 0, winreg.REG_BINARY, data)
    except PermissionError:
        raise ApiError("Windows says this change needs administrator permission. Close App "
                       "Manager, open it again, and choose Yes when Windows asks.", 403)


@route("POST", r"/api/startup/([0-9a-f]{10})/toggle")
def r_toggle(req):
    want = bool(req.body.get("enabled"))
    with LOCK:
        entry = next((e for e in STARTUP.get()["data"] or [] if e["id"] == req.groups[0]), None)
        if not entry:
            raise ApiError("That startup item is no longer in the list. Refresh and try again.", 404)
        if IS_WIN:
            if entry["src"] == "task":
                verb = "Enable" if want else "Disable"
                try:
                    core.ps(f"{verb}-ScheduledTask -TaskName {core.ps_quote(entry['ref']['name'])} "
                            f"-TaskPath {core.ps_quote(entry['ref']['path'])} -ErrorAction Stop")
                except RuntimeError as e:
                    raise ApiError(f"Windows would not change that task: {e}", 500)
            else:
                _set_approved(entry, want)
        entry["enabled"] = want
    activity("enable startup item" if want else "disable startup item", entry["name"])
    return {"ok": True}
