"""Small shared endpoints: app info, background tasks, activity log."""

import os
import threading
import time

from . import core
from .backend import BACKEND
from .core import activity, route


@route("GET", r"/api/meta")
def r_meta(req):
    winget = False
    if core.ROLE != "hub":
        from . import updates
        winget = updates.winget_available()
    return {"os": BACKEND.name, "windows": core.IS_WIN, "admin": core.is_admin(),
            "firewall": BACKEND.supports_firewall, "winget": winget,
            "version": core.VERSION, "role": core.ROLE, "product": core.PRODUCT}


@route("GET", r"/api/jobs")
def r_jobs(req):
    return {"items": core.list_jobs()}


@route("GET", r"/api/activity")
def r_activity(req):
    return {"items": core.recent_activity(300)}


@route("POST", r"/api/shortcut")
def r_shortcut(req):
    BACKEND.make_shortcut()
    activity("create desktop shortcut")
    return {"ok": True}


@route("POST", r"/api/quit")
def r_quit(req):
    threading.Thread(target=lambda: (time.sleep(0.3), os._exit(0)), daemon=True).start()
    return {"ok": True}
