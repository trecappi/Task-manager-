"""App Manager: feature modules. Importing a module registers its web routes."""
