# App Manager (User app)

This is the app for a single PC. The matching **App Manager Hub** is a separate download that manages many PCs.

A local dashboard for managing the programs and hardware of a Windows PC.
Standard-library Python only (3.8+). No installs, no accounts, no internet needed
(except for the Updates tab, which asks Windows Package Manager).

## Run it

Double-click **Start App Manager.bat** (or run `python app_manager.py`).
Windows asks for permission once, then the dashboard opens in your browser.

App Manager runs a small web server on `127.0.0.1` only, so nothing is reachable
from the network. Every request must carry a secret that only this computer has.

## What is in it

| Tab | What it does |
| --- | --- |
| Overview | Hardware summary and things that need attention (full drives, device problems, updates). |
| Programs | Every installed program with version, publisher, install date and size. Search, filter, sort, favorites, details panel, uninstall (one or many), export to CSV or HTML. |
| My apps | Programs App Manager starts, stops and keeps running. Per-app internet block (Windows Firewall), "Start with Windows", and a list of everything blocked. |
| Startup | Everything that starts with Windows (registry, startup folders, scheduled tasks) with an on/off switch. Nothing is deleted. |
| Updates | Two side tabs. Programs: updates from `winget`, one at a time or all at once. Drivers: the driver check. It reads this PC's serial, model and hardware IDs, looks for newer drivers in the Microsoft Update Catalog and (ASUS laptops) ASUS's support service, and compares versions. It never downloads or installs a driver. |
| Install | Curated list of common programs (browsers, tools, runtimes, dev, gaming) installed silently through winget. Quick-pick presets. Installed ones are marked. **+ Add program** adds your own entries (search the winget catalog, or point to a downloaded .exe/.msi with silent switches). Any entry can be removed from the list, and removed built-ins can be restored. |
| Tweaks | Privacy and tidy-up settings in two groups: Recommended and Advanced (clearly marked). Each change records the old value, so Undo restores it. Optional restore point first. |
| Security | Checks protections against recommended values (Controlled Folder Access, real-time and cloud protection, firewall, SMB1, UAC and more). Turn on one at a time, with Audit mode where Windows offers it and Restore previous. Controlled Folder Access has allowed apps, extra folders and a "recently blocked" list. |
| Monitor | Live graphs for processor, memory and network, the busiest programs, drive health (wear, errors, temperature), firmware temperatures and battery. Sampling only runs while this tab is open. |
| Tools | Cleanup (temp, browser caches, crash dumps, update downloads, Recycle Bin), Large files, Duplicates (by content), Error log (last 7 days, crashes first), Network (ping, DNS, port, trace route, adapters, quick fixes), Repair (SFC, DISM, chkdsk read-only, Windows Update status, shortcuts to Windows consoles) and a downloadable PC health report. **Remote support** shows whether AnyDesk, UltraViewer, AnyViewer and Remote Utilities are installed on this PC and the ID of each (AnyDesk's is read automatically; type the others in), and can install them with winget. |
| Settings → Managed by a hub | Lets a hub (the separate **App Manager Hub** app) see this PC and send it orders. You paste a one-time enrollment code; this PC calls the hub, so no ports are opened here. You choose which kinds of order are allowed (profiles, repair, cleanup, install) and can leave at any time. |
| Profiles | A profile is a saved set-up (the builder has a section list with counts, filters, select all, your own programs found through winget, and can start blank, from this PC's current settings, or from a copy of any profile): tweaks, security protections, programs to install, startup items to switch off and cleanup to run. Built-in profiles (Safe baseline, Office, Gaming, Technician) plus your own; capture one from this PC, duplicate, edit, export and import as .json. Applying shows a preview of exactly what will change, and offers a restore point first. |
| Backup | **Full system image** (Windows' own wbadmin: Windows drive plus any internal drives you tick, saved to another drive or a network folder, checks space and format first, can be stopped, with restore steps), restore-point list and creation, **Undo everything App Manager changed**, export/import of App Manager's own settings (profiles, install list, look), and a driver backup. |
| Settings | **Technicians**: each has a username, password and, per tab, no access / view only / view and change (presets: View only, Help desk, Technician, Everything), or is an administrator. Until the first account exists nothing asks for a login. Administrators manage accounts; everyone can change their own password; the Activity tab shows who did what. Also: theme (match Windows, light, dark), Simple or Technician mode, show/hide and reorder tabs. A search box in the header finds programs, tweaks, protections, tools and devices. |
| Devices | Hardware details, a Device Manager style tree with problem detection and a **Diagnose & fix** button per device (turn on, restart, rescan; optional reinstall with a restore point first), and driver versions and dates. |
| Activity | A log of what App Manager did and when. |

## Safety

* Uninstall asks first and can create a restore point beforehand.
* It refuses to block or stop anything inside the Windows folder.
* Shared programs such as `python.exe` or `java.exe` get an extra warning before blocking.
* Startup items are switched off the same way Task Manager does it, so they can always be switched back on.
* Programs started from App Manager inherit its administrator rights (see *Known limits*).

## Layout

```
app_manager.py     launcher: permission prompt, single instance, starts the server
am/core.py         paths, settings, activity log, PowerShell helper, routes, background tasks
am/backend.py      Windows layer (processes, firewall, scheduled task) + test-mode stand-in
am/myapps.py       My apps, internet block, running programs, keep-running supervisor
am/programs.py     inventory, details, uninstall, export, favorites
am/startup.py      startup manager
am/updates.py      winget updates
am/hardware.py     hardware overview, device tree, drivers
am/drivercheck.py  identity, Update Catalog + vendor lookup, version comparison
am/installer.py    curated winget install list and presets
am/tweaks.py       tweak definitions, apply and undo
am/security.py     security checks, fixes, Controlled Folder Access
am/monitor.py      live sampler and drive health
am/cleanup.py      disk cleanup, large files, duplicates, error log
am/tech.py         network tools, repair, Windows Update status, health report
am/devfix.py       device doctor: diagnose and fix devices with problems
am/profiles.py     profiles: build, preview, apply, export, import
am/backup.py       restore points, undo all, settings export/import, driver backup
am/proto.py        signed hub/controller protocol (enrollment, signatures)
am/hub.py          the hub: devices, enrollment codes, orders, listener
am/agent.py        the controller: enroll, check in, carry out orders
am/accounts.py     technician accounts, sign-in, access rules
am/ui.py           look settings and global search
am/winsys.py       registry, services, tasks and power helpers (with test-mode stand-in)
tests/             offline tests: python -m unittest discover -s tests
am/fake.py         sample data used on non-Windows systems (test mode)
am/server.py       local web server, authentication, static files
web/               the dashboard (index.html, app.css, app.js)
```

Each feature module registers its own web routes with `@route(...)`, so a new feature
is one new file under `am/` plus an `import` line in `app_manager.py`.

On Windows, settings live in `%APPDATA%\appmgr` (`gui.json`, `activity.jsonl`, `gui.log`).
Set `APPMGR_HOME` to use another folder. Setting `APPMGR_FAKE_FW=1` in test mode
pretends firewall rules work, which is useful when developing the UI.

## Known limits

* **Driver check is unverified against the live services.** The Catalog page layout and the ASUS
  JSON service were implemented from open-source references and tested only on saved samples.
  If a lookup returns nothing, send `%APPDATA%\appmgr\gui.log`. ASUS lookup covers laptops;
  desktop boards and other makers get a support link for now (adapter slots exist for more).
* Monitor's network and CPU readings use Windows system calls (ctypes) and drive health uses Windows' storage counters. Neither has run on real Windows yet; if a card shows a dash, tell me.
* Cleanup, Large files and Duplicates only ever delete inside fixed temp/cache folders or send scanned files to the Recycle Bin. A duplicate group always keeps one copy.
* Tweaks and Security were tested with a simulated Windows layer, not on real Windows yet.
  Try on one PC, with the restore point box ticked.

* Programs started from here run as administrator, because App Manager itself does.
  A later version should split the admin work into a small helper and run the window
  with normal rights.
* Windows blocking is per program file, so helper programs a blocked app launches can
  still connect.
* Windows Firewall rules for Microsoft Store apps are not supported yet.
* Temperatures, fans and drive SMART data are not read yet (planned: optional helpers).
* "Start with Windows" and "Keep running" only work while App Manager is running.

## Developing without Windows

On Linux or macOS the app starts in *test mode* with sample data. Uninstall, updates
and startup changes only simulate their effect. The Windows-specific code paths are
only exercised on Windows.


## Technician accounts (v0.7.0)

* Settings, Technicians, "Create the administrator account" turns sign-in on. From then on every browser must sign in.
* Each technician: username (3 to 32 characters), password (8 or more, stored only as a salted hash), and an access level per tab. Overview is always view only. Settings, accounts and "Quit" are administrator-only. Anything not listed in the access table is administrator-only by default.
* Access is enforced on the server for every request, not just by hiding tabs. Applying a profile also needs "change" on every tab the profile touches (Tweaks, Security, Install, Startup, Tools).
* Five wrong passwords lock that username for a minute. Sessions end after 4 idle hours or when the account is edited, switched off or deleted. There must always be one switched-on administrator.
* Lost the administrator password? Run `app_manager.py --reset-logins` on the PC. It deletes `techs.json` and sign-in is off again.
* This is a safeguard between people sharing one PC's App Manager, not a defence against someone who already has administrator rights on the PC itself.


## Hub and controller (v0.8.0)

**Hub.** Hub tab, "Turn on hub". It starts a second small web server (default port 8766) that speaks only the signed protocol below. On Windows it adds a firewall rule for private and domain networks only. The dashboard itself still listens on 127.0.0.1 only.

**Controller (managed PC).** Settings, "Managed by a hub", paste the enrollment code. This PC then calls the hub; nothing on it is opened to the network. An idle PC keeps one request open with the hub, so an order reaches it at once. The owner of the PC chooses which kinds of order it accepts (apply profiles; install and update programs; repairs, device fixes and restore points; disk cleanup). Reading status is always on. Orders are checked again on the PC and can only be one of the fixed kinds, so the hub can never run arbitrary commands.

**How it is protected**
* The enrollment code holds a one-time secret and expires (1 hour, 1 day or 7 days). It is never sent over the network: the PC and the hub prove they both know it and each derive the same long-term key from it and two random numbers.
* Every later message is signed with that key (HMAC-SHA256) with a timestamp and a one-time number, so messages cannot be forged, changed or replayed. Replies are signed too, so nobody on the network can give a PC orders.
* Messages are signed but **not encrypted**. Status reports (installed programs and so on) can be read by someone who can watch the network. Use a network you trust or a VPN. Adding TLS would need a certificate; it is a good next step.
* The hub keeps each device's key in `hub.json` in its data folder, so protect that folder like any credential. Removing a device from the hub cancels its key.
* Both ends need roughly correct clocks (within 5 minutes).
