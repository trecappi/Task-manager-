@echo off
rem Switches technician sign-in off again (removes all accounts). Close App Manager first (press Quit in it).
cd /d "%~dp0"
where python >nul 2>nul && (python app_manager.py --reset-logins --no-elevate) || (py app_manager.py --reset-logins --no-elevate)
pause
